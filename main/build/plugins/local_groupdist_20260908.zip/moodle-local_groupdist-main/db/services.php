<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Web service function declarations.
 *
 * @package    local_groupdist
 * @copyright  2026 Anderson Blaine
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$functions = [
    'local_groupdist_get_audit_sections' => [
        'classname' => 'local_groupdist\external\get_audit_sections',
        'description' => 'One page of group sections of an applied distribution run (searchable).',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => 'local/groupdist:viewauditlog',
    ],
    'local_groupdist_get_audit_members' => [
        'classname' => 'local_groupdist\external\get_audit_members',
        'description' => 'One window of participants inside a section of an applied distribution run.',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => 'local/groupdist:viewauditlog',
    ],
    'local_groupdist_get_preview' => [
        'classname' => 'local_groupdist\external\get_preview',
        'description' => 'Compute a deterministic distribution preview page. Nothing is written.',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => 'local/groupdist:distribute',
    ],
    'local_groupdist_search_cohorts' => [
        'classname' => 'local_groupdist\external\search_cohorts',
        'description' => 'Search the cohorts available as affinity rule sources (visibility rules applied).',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => 'local/groupdist:distribute',
    ],
    'local_groupdist_search_groups' => [
        'classname' => 'local_groupdist\external\search_groups',
        'description' => 'Search the course groups available as affinity rule sources (visibility rules applied).',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => 'local/groupdist:distribute',
    ],
    'local_groupdist_save_group_fields' => [
        'classname' => 'local_groupdist\external\save_group_fields',
        'description' => 'Save changed group custom field cells from the bulk edit table (chunked, max 200 per call).',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'moodle/course:managegroups',
    ],
];

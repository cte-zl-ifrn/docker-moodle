<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Grace period applied before a removed block's data is discarded.
 *
 * @package    block_feedback_tracker
 * @copyright  2026 Anderson Blaine <anderson@blaine.com.br>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace block_feedback_tracker\local\sla;

/**
 * How long a course's measured history survives after the block is removed.
 *
 * Moodle's convention is to delete a block's data immediately, in
 * `instance_delete()`. That fits data owned by the instance (`block_html`
 * deleting its own files), not this block: it is a gate, the data belongs to
 * the course, removing the block is an easy mistake, and by default a course
 * backup does not carry the plugin's tables (`backup_ledger`), so what was
 * measured could not be restored. Hence a grace period.
 *
 * By default the window follows the site's recycle-bin retention, the period
 * in which administrators already expect to be able to undo things: the
 * longest enabled window wins, floored at the plugin's own setting.
 *
 * A recycle bin that never expires (`expiry <= 0`, which `tool_recyclebin`'s
 * cleanup tasks read as "keep forever") is deliberately not treated as an
 * infinite grace, which would silently disable the cleanup altogether.
 */
final class removal_grace {
    /** Fallback window when nothing is configured: one week. */
    public const DEFAULT_SECONDS = 604800;

    /** Floor on the configured window. Below this, an accident is unrecoverable. */
    public const MIN_SECONDS = 3600;

    /**
     * Set while the whole plugin is being uninstalled.
     *
     * @var bool
     */
    private static $uninstalling = false;

    /**
     * Set while a bulk removal discards the history itself.
     *
     * @var bool
     */
    private static $discardinginline = false;

    /**
     * Record that every block instance is being deleted by an uninstall.
     *
     * Static because the two halves of the signal reach different objects:
     * core's block uninstall calls `before_delete()` on an instance-less object,
     * then `instance_delete()` on a new object per instance, so an instance
     * property would never be seen.
     *
     * It lives here rather than on the block class also because
     * `moodle-plugin-ci validate` dies with a PHP fatal on Moodle 5.2 when
     * `block_feedback_tracker.php` declares a member with two modifiers
     * (`private static`); that file must keep single-modifier members.
     *
     * @return void
     */
    public static function mark_uninstalling(): void {
        self::$uninstalling = true;
    }

    /**
     * Whether the current request is uninstalling the plugin.
     *
     * @return bool
     */
    public static function is_uninstalling(): bool {
        return self::$uninstalling;
    }

    /**
     * Clear the uninstall flag.
     *
     * Production never needs this: a request either uninstalls the plugin or
     * does not. A PHPUnit process runs many tests, and a test exercising the
     * uninstall path would otherwise leave the flag set for every later test,
     * disabling the queuing they check.
     *
     * @return void
     */
    public static function reset_uninstalling(): void {
        self::$uninstalling = false;
    }

    /**
     * Run a block deletion whose course history the caller discards at once.
     *
     * instance_delete() then schedules no deferred discard, which would only
     * find the history already gone. Static for the reason given at
     * {@see self::mark_uninstalling()}: core builds a new block object per
     * instance it deletes.
     *
     * @param callable $deletion Deletes the block instance.
     * @return void
     */
    public static function delete_discarding_inline(callable $deletion): void {
        self::$discardinginline = true;
        try {
            $deletion();
        } finally {
            self::$discardinginline = false;
        }
    }

    /**
     * Whether the block being deleted has its history discarded by the caller.
     *
     * @return bool
     */
    public static function is_discarding_inline(): bool {
        return self::$discardinginline;
    }

    /**
     * Schedule the discard of a course's history once the grace period ends.
     *
     * A course whose block is removed, put back and removed again inside one
     * window keeps one task, moved to the latest removal's deadline:
     * queue_adhoc_task() with its duplicate check would keep the first
     * removal's run time, which core reserves that check for ASAP tasks.
     *
     * @param int $courseid
     * @return void
     */
    public static function schedule_discard(int $courseid): void {
        $task = new \block_feedback_tracker\task\discard_course_data();
        $task->set_custom_data(['courseid' => $courseid]);
        $task->set_next_run_time(time() + self::seconds());
        \core\task\manager::reschedule_or_queue_adhoc_task($task);
    }

    /**
     * Seconds a removed block's data is kept before it may be discarded.
     *
     * @return int
     */
    public static function seconds(): int {
        $explicit = (int) (get_config('block_feedback_tracker', 'removal_grace_seconds')
            ?: self::DEFAULT_SECONDS);
        if ($explicit < self::MIN_SECONDS) {
            $explicit = self::MIN_SECONDS;
        }

        // Default ON: an unset key (false, as after a web upgrade before the new
        // settings are saved) follows the recycle bin; only an explicit '0' does not.
        $follow = get_config('block_feedback_tracker', 'removal_grace_follow_recyclebin');
        if ($follow !== false && $follow !== null && (string) $follow === '0') {
            return $explicit;
        }

        $windows = [$explicit];
        foreach (['course', 'category'] as $bin) {
            // An unset key reads as disabled, as {@see \tool_recyclebin\course_bin::is_enabled()} reads it.
            if ((int) (get_config('tool_recyclebin', $bin . 'binenable') ?: 0) !== 1) {
                continue;
            }
            $expiry = (int) (get_config('tool_recyclebin', $bin . 'binexpiry') ?: 0);
            if ($expiry > 0) {
                $windows[] = $expiry;
            }
        }
        return max($windows);
    }

    /**
     * Whether the delayed cleanup runs at all.
     *
     * Off by default: an upgrade must never start discarding a site's history
     * because a new version shipped a policy. While off, removing the block
     * simply stops the course being processed, which is the behaviour every
     * existing installation already has.
     *
     * @return bool
     */
    public static function is_active(): bool {
        return (int) (get_config('block_feedback_tracker', 'removal_cleanup_active') ?: 0) === 1;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Finds courses carrying the block, for bulk administration.
 *
 * @package    block_feedback_tracker
 * @copyright  2026 Anderson Blaine <anderson@blaine.com.br>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace block_feedback_tracker\local\sla;

/**
 * The candidate list behind the bulk block-removal tool.
 *
 * Deliberately does not go through {@see course_access::is_processable()}:
 * that method excludes hidden courses, and archived courses are usually
 * hidden, so the tool would be blind to the courses it exists to clear.
 *
 * Every filter is optional. The three date filters are OR-ed with each other
 * and the result AND-ed with the rest. `enddate` is optional in Moodle and
 * often 0 on older courses, so "started before" and "has no end date" are
 * explicit filters rather than a silent fallback for a missing end date,
 * which would either miss most of an old archive or sweep in running courses.
 *
 * A course already waiting in a bulk removal ({@see bulk_removal_queue}) is no
 * longer a candidate: it still carries the block until cron runs, and offering
 * it again would let it be queued twice and keep the next batch out of reach.
 */
final class course_finder {
    /** Rows revealed at a time by the "load more" control. */
    public const PAGE_SIZE = 25;

    /**
     * Hard ceiling on one selection.
     *
     * Four pages' worth. Past this the tool asks for a narrower filter rather
     * than paginating: with pages, "select all" could mean this page or every
     * match; with a ceiling it has one meaning.
     */
    public const MAX_RESULTS = 100;

    /**
     * Whether at least one filter question is answered.
     *
     * The form refuses an empty filter so the tool never offers the whole site;
     * the removal request repeats the check on the server. Each value is read
     * as {@see self::build_filter()} reads it: a date or category of 0 or less
     * adds no clause there, so it does not count as an answer here.
     *
     * @param array $filters Same keys as {@see self::candidates()}.
     * @return bool
     */
    public static function has_filter(array $filters): bool {
        return (int) ($filters['endedbefore'] ?? 0) > 0
            || (int) ($filters['startedbefore'] ?? 0) > 0
            || (int) ($filters['categoryid'] ?? 0) > 0
            || !empty($filters['noenddate'])
            || !empty($filters['hiddenonly']);
    }

    /**
     * Courses carrying the block that match the given filters.
     *
     * Recognised filter keys, all optional:
     *  - `endedbefore`   (int) course ended strictly before this instant
     *  - `startedbefore` (int) course started strictly before this instant
     *  - `noenddate`     (bool) include courses with no end date set
     *  - `categoryid`    (int) that category or any descendant of it
     *  - `hiddenonly`    (bool) only courses hidden from students
     *
     * @param array $filters See the description for the recognised keys.
     * @return array Rows of id, fullname, shortname, category, visible,
     *               startdate, enddate, categoryname and ledgerrows, keyed by
     *               course id. Names are stored values, not yet formatted
     *               ({@see \block_feedback_tracker\local\output\bulk_remove_rows}).
     */
    public static function candidates(array $filters): array {
        global $DB;

        [$wheresql, $params] = self::build_filter($filters, bulk_removal_queue::course_ids());
        if ($wheresql === null) {
            return [];
        }

        $sql = "SELECT c.id, c.fullname, c.shortname, c.category, c.visible, c.startdate, c.enddate,
                       cat.name AS categoryname
                  FROM {course} c
                  JOIN {course_categories} cat ON cat.id = c.category
                  JOIN {context} ctx ON ctx.instanceid = c.id AND ctx.contextlevel = :ctxlevel
                  JOIN {block_instances} bi ON bi.parentcontextid = ctx.id
                                           AND bi.blockname = :blockname
                 WHERE $wheresql
              GROUP BY c.id, c.fullname, c.shortname, c.category, c.visible, c.startdate, c.enddate, cat.name
              ORDER BY c.fullname ASC";
        $rows = $DB->get_records_sql($sql, $params, 0, self::MAX_RESULTS);
        if (empty($rows)) {
            return [];
        }

        /* The ledger count is what makes the confirmation informed: an
         * administrator should see how much measured history each course would
         * eventually lose, not just how many courses they ticked. It is counted
         * for the listed rows only, not for every course the filter matches. */
        [$insql, $inparams] = $DB->get_in_or_equal(array_keys($rows), SQL_PARAMS_NAMED, 'lc');
        $counts = $DB->get_records_sql_menu(
            "SELECT courseid, COUNT(1)
               FROM {block_feedback_tracker_sub}
              WHERE courseid $insql
           GROUP BY courseid",
            $inparams
        );
        foreach ($rows as $id => $row) {
            $row->ledgerrows = (int) ($counts[$id] ?? 0);
        }
        return $rows;
    }

    /**
     * Which of the given courses the filter still offers.
     *
     * Validates a removal request: unlike {@see self::candidates()} it has no
     * row ceiling, so a course that moved past the first {@see self::MAX_RESULTS}
     * by name while the page was open is still recognised.
     *
     * @param array $filters Same keys as {@see self::candidates()}.
     * @param array $courseids Course ids to check.
     * @return int[] The ids that match, carry the block and are not queued.
     */
    public static function matching_ids(array $filters, array $courseids): array {
        global $DB;

        $courseids = array_values(array_unique(array_map('intval', $courseids)));
        if (empty($courseids)) {
            return [];
        }
        [$wheresql, $params] = self::build_filter($filters, bulk_removal_queue::course_ids());
        if ($wheresql === null) {
            return [];
        }
        [$insql, $inparams] = $DB->get_in_or_equal($courseids, SQL_PARAMS_NAMED, 'only');
        $sql = "SELECT DISTINCT c.id
                  FROM {course} c
                  JOIN {course_categories} cat ON cat.id = c.category
                  JOIN {context} ctx ON ctx.instanceid = c.id AND ctx.contextlevel = :ctxlevel
                  JOIN {block_instances} bi ON bi.parentcontextid = ctx.id
                                           AND bi.blockname = :blockname
                 WHERE $wheresql AND c.id $insql";
        $found = array_map('intval', $DB->get_fieldset_sql($sql, $params + $inparams));
        sort($found);
        return $found;
    }

    /**
     * How many courses match, ignoring the ceiling; queued courses excluded.
     *
     * Reported beside the visible rows so an administrator can tell a complete
     * selection from one truncated at {@see self::MAX_RESULTS}.
     *
     * @param array $filters Same keys as {@see self::candidates()}.
     * @return int
     */
    public static function count_candidates(array $filters): int {
        global $DB;

        [$wheresql, $params] = self::build_filter($filters, bulk_removal_queue::course_ids());
        if ($wheresql === null) {
            return 0;
        }
        $sql = "SELECT COUNT(DISTINCT c.id)
                  FROM {course} c
                  JOIN {course_categories} cat ON cat.id = c.category
                  JOIN {context} ctx ON ctx.instanceid = c.id AND ctx.contextlevel = :ctxlevel
                  JOIN {block_instances} bi ON bi.parentcontextid = ctx.id
                                           AND bi.blockname = :blockname
                 WHERE $wheresql";
        return (int) $DB->count_records_sql($sql, $params);
    }

    /**
     * Build the shared WHERE clause and its parameters.
     *
     * Shared by the list and its total so the two can never disagree.
     *
     * @param array $filters Same keys as {@see self::candidates()}.
     * @param array $excludeids Course ids to leave out: the queued ones.
     * @return array{0:string|null, 1:array} Null clause when the filter can
     *                                       match nothing at all.
     */
    private static function build_filter(array $filters, array $excludeids = []): array {
        global $DB;

        $where = ['c.id <> :siteid'];
        $params = ['siteid' => SITEID, 'blockname' => 'feedback_tracker'];
        if (!empty($excludeids)) {
            [$exsql, $exparams] = $DB->get_in_or_equal($excludeids, SQL_PARAMS_NAMED, 'ex', false);
            $where[] = "c.id $exsql";
            $params += $exparams;
        }

        $endedbefore = (int) ($filters['endedbefore'] ?? 0);
        $startedbefore = (int) ($filters['startedbefore'] ?? 0);
        $noenddate = !empty($filters['noenddate']);

        /* The date filters are OR-ed: "ended before July, or never had an end
         * date" is one set of courses, not two searches. */
        $dateclauses = [];
        if ($endedbefore > 0) {
            $dateclauses[] = '(c.enddate > 0 AND c.enddate < :endedbefore)';
            $params['endedbefore'] = $endedbefore;
        }
        if ($startedbefore > 0) {
            $dateclauses[] = '(c.startdate > 0 AND c.startdate < :startedbefore)';
            $params['startedbefore'] = $startedbefore;
        }
        if ($noenddate) {
            $dateclauses[] = '(c.enddate = 0)';
        }
        if (!empty($dateclauses)) {
            $where[] = '(' . implode(' OR ', $dateclauses) . ')';
        }

        if (!empty($filters['hiddenonly'])) {
            $where[] = 'c.visible = 0';
        }

        $categoryid = (int) ($filters['categoryid'] ?? 0);
        if ($categoryid > 0) {
            [$catsql, $catparams] = self::category_subtree_clause($categoryid);
            if ($catsql === null) {
                // A category that does not exist matches nothing, not everything.
                return [null, []];
            }
            $where[] = $catsql;
            $params += $catparams;
        }

        $params['ctxlevel'] = CONTEXT_COURSE;
        return [implode(' AND ', $where), $params];
    }

    /**
     * A predicate matching one category and every descendant of it.
     *
     * `{course_categories}.path` looks like `/1/3/17`. Descendants are matched
     * on the target's full path plus a trailing slash (`/1/3/%`); without the
     * slash `/1/3%` would also match `/1/30`. The target's own path has no
     * trailing slash, hence the separate id test.
     *
     * @param int $categoryid
     * @return array{0:string|null, 1:array} Clause and params; clause null when
     *                                       the category does not exist.
     */
    private static function category_subtree_clause(int $categoryid): array {
        global $DB;

        $path = $DB->get_field('course_categories', 'path', ['id' => $categoryid], IGNORE_MISSING);
        if ($path === false) {
            return [null, []];
        }
        $like = $DB->sql_like('cat.path', ':catpath');
        return [
            "(cat.id = :catid OR $like)",
            ['catid' => $categoryid, 'catpath' => $DB->sql_like_escape($path) . '/%'],
        ];
    }
}

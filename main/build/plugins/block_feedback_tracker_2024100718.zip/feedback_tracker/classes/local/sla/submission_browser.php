<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Shared submission browser — filtered / sorted / paginated reads of the
 * ledger that back the report page's pending and graded tables.
 *
 * @package    block_feedback_tracker
 * @copyright  2026 Anderson Blaine <anderson@blaine.com.br>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace block_feedback_tracker\local\sla;

use block_feedback_tracker\local\grading\grader_filters;

/**
 * One query family powering the report page's submission tables. Both the
 * pending (`get_pending_submissions`) and graded (`get_graded_submissions`)
 * web services delegate here so the visibility scoping, search, sort, paging,
 * and band-distribution counts live in a single place.
 *
 * Read-time only: the SUBMITTED-only SLA scope is applied here (graded =
 * submitted work that now carries a timegraded; pending = submitted work that
 * does not). Drafts are a separate, de-emphasised mode and never count toward
 * the SLA.
 */
class submission_browser {
    /** Pending mode: submitted work awaiting feedback (timegraded IS NULL). */
    public const MODE_PENDING = 'pending';
    /**
     * Graded mode: submitted work already returned (timegraded IS NOT NULL).
     *
     * All-time on purpose, unlike the windowed graded stats in rollup_service:
     * this tab is an audit of everything a teacher returned, while the windowed
     * stats feed the score and must stay comparable across groups.
     */
    public const MODE_GRADED = 'graded';
    /** Draft mode: saved-but-not-submitted work (never counts toward the SLA). */
    public const MODE_DRAFT = 'draft';

    /** Hard upper bound on a page size to discourage all-the-things reads. */
    public const MAX_PAGE_SIZE = 200;

    /**
     * Which of these rows currently have a grade the gradebook hides from the
     * student, keyed by ledger row id.
     *
     * One bounded query for the whole page rather than a join on the row
     * query, which is also used for the count and would carry the cost twice.
     * The over-fetch is deliberate: matching item ids against user ids
     * separately admits a few pairs that are not on this page, and discarding
     * those in PHP is cheaper than a composite predicate.
     *
     * @param array $rows Rows from the page query; each needs id, iteminstance, userid.
     * @return array Ledger row id => 1, for the hidden ones only.
     */
    private static function hidden_from_student(array $rows): array {
        global $CFG, $DB;

        // See gradebook_response::for_assign_user() — the same constant, the
        // same reason: gradelib is not loaded on every request that gets here.
        require_once($CFG->libdir . '/grade/constants.php');
        if (empty($rows)) {
            return [];
        }
        $assignids = [];
        $userids = [];
        foreach ($rows as $r) {
            $assignids[(int) $r->iteminstance] = true;
            $userids[(int) $r->userid] = true;
        }
        [$asql, $aparams] = $DB->get_in_or_equal(array_keys($assignids), SQL_PARAMS_NAMED, 'ga');
        [$usql, $uparams] = $DB->get_in_or_equal(array_keys($userids), SQL_PARAMS_NAMED, 'gu');
        $now = time();
        $grades = $DB->get_records_sql(
            "SELECT gg.id, gi.iteminstance, gg.userid, gg.hidden AS gradehidden, gi.hidden AS itemhidden
               FROM {grade_items} gi
               JOIN {grade_grades} gg ON gg.itemid = gi.id
              WHERE gi.itemtype = :itemtype
                AND gi.itemmodule = :itemmodule
                AND gi.itemnumber = 0
                AND gi.gradetype <> :nograde
                AND (gg.finalgrade IS NOT NULL OR " . $DB->sql_isnotempty('gg', 'gg.feedback', true, true) . ")
                AND gi.iteminstance $asql
                AND gg.userid $usql",
            $aparams + $uparams + [
                'itemtype' => 'mod',
                'itemmodule' => 'assign',
                'nograde' => GRADE_TYPE_NONE,
            ]
        );
        $hidden = [];
        foreach ($grades as $g) {
            $ishidden = self::flag_hides((int) $g->gradehidden, $now)
                || self::flag_hides((int) $g->itemhidden, $now);
            if ($ishidden) {
                $hidden[(int) $g->iteminstance . ':' . (int) $g->userid] = true;
            }
        }
        $out = [];
        foreach ($rows as $r) {
            $key = (int) $r->iteminstance . ':' . (int) $r->userid;
            if (isset($hidden[$key])) {
                $out[(int) $r->id] = 1;
            }
        }
        return $out;
    }

    /**
     * Whether one of core's overloaded `hidden` flags is hiding right now.
     *
     * 1 means hidden outright; anything larger is a hide-until instant that
     * stops hiding once it passes.
     *
     * @param int $flag
     * @param int $now
     * @return bool
     */
    private static function flag_hides(int $flag, int $now): bool {
        return $flag === 1 || ($flag > 1 && $flag > $now);
    }

    /**
     * Browse the ledger for one course as seen by one user.
     *
     * Callers (web services) are responsible for context validation and the
     * viewresponsiveness capability check before invoking this. Group-level
     * visibility (separate groups / accessallgroups) is applied here.
     *
     * @param int $courseid Course id.
     * @param int $userid   Viewing user (for group visibility scoping).
     * @param array $opts Filter / sort / page options: mode, groupid, search,
     *              bucket, band, sort, order, page, perpage.
     * @return array{total:int, counts:array<string, int>, rows:array<int, array<string, mixed>>}
     */
    public static function browse(int $courseid, int $userid, array $opts): array {
        global $DB;

        $mode = ($opts['mode'] ?? self::MODE_PENDING);
        if (!in_array($mode, [self::MODE_PENDING, self::MODE_GRADED, self::MODE_DRAFT], true)) {
            $mode = self::MODE_PENDING;
        }
        $groupid = max(0, (int) ($opts['groupid'] ?? 0));
        $search = trim((string) ($opts['search'] ?? ''));
        $bucket = trim((string) ($opts['bucket'] ?? ''));
        $band = trim((string) ($opts['band'] ?? ''));
        $sort = (string) ($opts['sort'] ?? '');
        $order = strtolower((string) ($opts['order'] ?? '')) === 'asc' ? 'ASC' : 'DESC';
        $page = max(0, (int) ($opts['page'] ?? 0));
        $perpage = max(1, min((int) ($opts['perpage'] ?? 25), self::MAX_PAGE_SIZE));
        // One reference time for the counts, the filter, the order and the badges.
        $now = time();

        // Respect Moodle group mode: SEPARATEGROUPS without accessallgroups
        // must not leak rows from groups the user can't see.
        $visibleids = group_access::visible_group_ids($courseid, $userid);
        if ($visibleids !== null && empty($visibleids)) {
            return ['total' => 0, 'counts' => self::zero_counts($mode), 'rows' => []];
        }

        // Shared FROM + JOINs. The assign join lets the activity name be both
        // searched and selected directly; groups is LEFT so the ungrouped
        // bucket (groupid 0) still returns rows.
        $from = "FROM {block_feedback_tracker_sub} sub
                  JOIN {user} u ON u.id = sub.userid
                  JOIN {course_modules} cm ON cm.id = sub.cmid
                  JOIN {assign} a ON a.id = cm.instance
             LEFT JOIN {groups} g ON g.id = sub.groupid";

        // Base predicate: course + mode + visibility + group + search. The
        // band/bucket filter is layered on top separately so the distribution
        // counts can ignore it (and stay switchable).
        [$basewhere, $baseparams] = self::base_where(
            $courseid,
            $mode,
            $visibleids,
            $groupid,
            $search
        );

        // Distribution counts over the base set (band/bucket filter excluded).
        $counts = self::counts($from, $basewhere, $baseparams, $mode, $now);

        // Graded results use a three-band set (Excellent / Good / Regular):
        // critical results are rare and fold into Regular, mirroring the
        // academic-days strip. The critical band is kept (as zero) so the WS
        // return shape is unchanged.
        if ($mode === self::MODE_GRADED) {
            $counts[bucket::REGULAR] += $counts[bucket::CRITICAL];
            $counts[bucket::CRITICAL] = 0;
        }

        // Layer the band/bucket filter for the displayed rows + their total.
        [$rowswhere, $rowsparams] = self::apply_band_filter($basewhere, $baseparams, $mode, $band, $bucket, $now);

        $total = (int) $DB->count_records_sql("SELECT COUNT(1) $from WHERE $rowswhere", $rowsparams);

        /* The row query alone also joins the module context, whose columns
         * preload the contexts the activity names are formatted in; the name
         * fields are the ones fullname() reads. */
        $ctxfields = \context_helper::get_preload_record_columns_sql('ctx');
        $namefields = \core_user\fields::for_name()->get_sql('u')->selects;
        $select = "SELECT sub.id, sub.cmid, sub.userid, sub.iteminstance, sub.groupid, sub.timesubmitted,
                          sub.attemptnumber, sub.cycle,
                          sub.timegraded, sub.timemarked, sub.timeclosed,
                          sub.closedsource,
                          sub.queuehours, sub.allochours,
                          sub.waitinghours, sub.effectivehours, sub.effectivedays,
                          sub.slabucket, sub.submissionstatus,
                          a.name AS activityname, g.name AS groupname,
                          cm.groupmode AS cmgroupmode, c.groupmode AS coursegroupmode,
                          c.groupmodeforce AS coursegroupmodeforce,
                          $ctxfields
                          $namefields";
        $ctxjoin = "JOIN {course} c ON c.id = cm.course
               LEFT JOIN {context} ctx ON ctx.instanceid = sub.cmid AND ctx.contextlevel = :bftctxmodule";
        $orderby = self::order_by($mode, $sort, $order, $now);
        $rows = $DB->get_records_sql(
            "$select $from $ctxjoin WHERE $rowswhere ORDER BY $orderby",
            $rowsparams + ['bftctxmodule' => CONTEXT_MODULE],
            $page * $perpage,
            $perpage
        );
        foreach ($rows as $r) {
            if ($r->ctxid !== null) {
                \context_helper::preload_from_record($r);
            }
        }
        $names = self::display_names($rows, $courseid);

        [$goal, $crit] = self::band_bounds();
        // Banding follows the global display unit: business-days mode
        // classifies by the stored elapsed-day count against the day ruler
        // (same comparisons as the filter + distribution counts), hours mode
        // keeps the stored slabucket + hour bounds.
        $usedays = bucket::use_day_thresholds();
        [$daygoal, $daycrit] = self::band_bounds_days();
        $hiddennow = self::hidden_from_student($rows);
        $previousmarks = resubmission::previous_marks($rows);
        $out = [];
        foreach ($rows as $r) {
            $eff = $r->effectivehours !== null ? (float) $r->effectivehours : 0.0;
            $gradedrow = $r->timegraded !== null;
            // Date-based elapsed days for the "business days" display unit;
            // pending rows (timegraded null) elapse up to now.
            $t2 = $gradedrow ? (int) $r->timegraded : $now;
            $days = \block_feedback_tracker\local\calendar\day_counter::between((int) $r->timesubmitted, $t2);
            $storeddays = $r->effectivedays !== null ? (float) $r->effectivedays : null;
            /* A row not yet backfilled is banded on the estimate the counts
             * and the band filter fall back to, so its badge sits in the band
             * that counts it. */
            $bandingdays = $storeddays ?? self::estimated_days($r, $mode, $now);
            // Displayed result band. When a graded row's stored value still
            // resolves to the "pending" sentinel (a legacy row: effectivedays
            // never backfilled, or slabucket left at its column default), it is
            // reclassified so a graded row never shows "pending": from its
            // effective hours, or in business-days mode from the day estimate
            // the graded counts use for it.
            $slabucket = $usedays
                ? bucket::for_effective_days($storeddays)
                : (string) $r->slabucket;
            if ($gradedrow && $slabucket === bucket::PENDING) {
                $slabucket = $usedays
                    ? bucket::for_effective_days($bandingdays)
                    : bucket::for_effective($eff);
            }
            // Critical graded results fold into Regular — the three-band result
            // set (Excellent / Good / Regular) the academic-days strip uses.
            if ($mode === self::MODE_GRADED && $slabucket === bucket::CRITICAL) {
                $slabucket = bucket::REGULAR;
            }
            $out[] = [
                'submissionid'     => (int) $r->id,
                'cmid'             => (int) $r->cmid,
                'userid'           => (int) $r->userid,
                'studentname'      => fullname($r),
                'activityname'     => $names['activities'][(int) $r->cmid] ?? '',
                'groupid'          => (int) $r->groupid,
                'groupname'        => $names['groups'][(int) $r->groupid] ?? '',
                'gradergate'       => (int) grader_filters::row_needs_gate(
                    $courseid,
                    (int) $r->cmgroupmode,
                    (int) $r->coursegroupmode,
                    (int) $r->coursegroupmodeforce,
                    \context_module::instance((int) $r->cmid)
                ),
                'timesubmitted'    => (int) $r->timesubmitted,
                'timegraded'       => $r->timegraded !== null ? (int) $r->timegraded : 0,
                'waitinghours'     => $r->waitinghours !== null ? (float) $r->waitinghours : 0.0,
                'effectivehours'   => $eff,
                'effective_days'   => $days['business'],
                'perceived_days'   => $days['calendar'],
                'slabucket'        => $slabucket,
                // Pending band using the same bounds and the same day measure as
                // the distribution counts + band filter, so the per-row Status
                // badge cannot disagree with the bar.
                'pendingband'      => $usedays
                    ? self::pending_band_days($bandingdays, $daygoal, $daycrit)
                    : self::pending_band($eff, $goal, $crit),
                'submissionstatus' => (string) $r->submissionstatus,
                /* closedsource and gradehidden are disclosed like awaitingrelease:
                 * a cycle closed from the gradebook leaves nothing on the
                 * activity's grading screen to explain it, and a grade the
                 * gradebook hides has not reached the student yet. */
                'closedsource'     => (string) ($r->closedsource ?? ''),
                /* Read live from the gradebook, never stored in the ledger: core
                 * fires no event when a grade is hidden or un-hidden, and a
                 * hide-until date expires by itself. */
                'gradehidden'      => (int) ($hiddennow[(int) $r->id] ?? 0),
                /* A mark the marking workflow has not released is invisible to
                 * the student, and releasing often needs a capability the marker
                 * lacks (mod/assign:releasegrades), so it is flagged rather than
                 * shown as plain "graded". */
                'awaitingrelease'  => (int) (
                    $r->timemarked !== null && $r->timeclosed === null
                ),
                /* Core's "Graded - resubmitted": the attempt already carried a
                 * mark when this work was handed in, so the wait is measured
                 * from the re-save and the teacher is looking at it again. */
                'resubmitted'      => (int) array_key_exists((int) $r->id, $previousmarks),
                'previousmarktime' => (int) ($previousmarks[(int) $r->id] ?? 0),
                /* The response interval split by owner: hand-in to first
                 * allocation, then the current marker's turnaround. Null where
                 * the row has no measurement. */
                'queuehours'       => $r->queuehours !== null ? (float) $r->queuehours : null,
                'allochours'       => $r->allochours !== null ? (float) $r->allochours : null,
            ];
        }

        return ['total' => $total, 'counts' => $counts, 'rows' => $out];
    }

    /**
     * Activity and group names of a page of rows, each formatted once.
     *
     * Names are filtered (multilang and other string filters) but not escaped:
     * the PARAM_TEXT fields of the web services, the report's text nodes and
     * the drilldown's double stashes all escape for themselves. An activity
     * name is formatted in its module context, where filters can be switched
     * off per activity, and a group name in the course context.
     *
     * @param array $rows Page rows; each needs cmid, activityname, groupid and groupname.
     * @param int $courseid The course every row belongs to.
     * @return array{activities: array<int, string>, groups: array<int, string>} Plain
     *         names keyed by course module id and by group id.
     */
    private static function display_names(array $rows, int $courseid): array {
        $activities = [];
        $groups = [];
        $courseoptions = null;
        foreach ($rows as $r) {
            $cmid = (int) $r->cmid;
            if (!isset($activities[$cmid])) {
                $activities[$cmid] = format_string(
                    (string) ($r->activityname ?? ''),
                    true,
                    ['context' => \context_module::instance($cmid), 'escape' => false]
                );
            }
            $groupid = (int) $r->groupid;
            if ($r->groupname !== null && !isset($groups[$groupid])) {
                $courseoptions ??= ['context' => \context_course::instance($courseid), 'escape' => false];
                $groups[$groupid] = format_string((string) $r->groupname, true, $courseoptions);
            }
        }
        return ['activities' => $activities, 'groups' => $groups];
    }

    /**
     * SQL expression for a row's elapsed-day count, with a fallback for rows
     * whose `effectivedays` was never backfilled.
     *
     * Without a fallback every day-mode predicate compares against NULL, so an
     * un-backfilled row leaves every band while still counting in the total.
     *
     * The fallback measures the same interval the stored column would have:
     * submission to grading for graded rows, submission to now for pending
     * ones (which is what `pending_recomputer` writes). It counts calendar
     * days, because the business-day engine has no SQL equivalent; calendar
     * days are always >= business days, so a row can only land in a worse
     * band, never be reported as better than it is.
     *
     * Once the `backfill_effectivedays` task completes no row reaches the
     * fallback. {@see self::estimated_days()} is its PHP twin, which the row
     * badges use, and the two must stay in step.
     *
     * @param string $mode Browse mode.
     * @param int $now Reference timestamp for pending rows.
     * @return string SQL expression usable anywhere sub.effectivedays was.
     */
    private static function days_expr(string $mode, int $now): string {
        /* Clamped at zero: a legacy row written before the cycle model can hold
         * timegraded < timesubmitted. CASE rather than GREATEST, which core
         * never uses and SQL Server lacks before 2022. */
        if ($mode === self::MODE_GRADED) {
            $raw = 'COALESCE(sub.effectivedays, (sub.timegraded - sub.timesubmitted) / 86400.0)';
        } else {
            // The reference time is server-generated, so inlining it keeps the
            // expression free of parameters the four call sites would each rebind.
            $raw = sprintf('COALESCE(sub.effectivedays, (%d - sub.timesubmitted) / 86400.0)', $now);
        }
        return sprintf('(CASE WHEN %s < 0 THEN 0 ELSE %s END)', $raw, $raw);
    }

    /**
     * The fallback of {@see self::days_expr()} for one row, in PHP: elapsed
     * calendar days from hand-in to grading in graded mode, or to now
     * otherwise, clamped at zero.
     *
     * @param \stdClass $r Row carrying timesubmitted and timegraded.
     * @param string $mode Browse mode.
     * @param int $now The reference time days_expr() was given.
     * @return float
     */
    private static function estimated_days(\stdClass $r, string $mode, int $now): float {
        $end = $mode === self::MODE_GRADED ? (int) $r->timegraded : $now;
        return max(0.0, ($end - (int) $r->timesubmitted) / 86400.0);
    }

    /**
     * Build the base WHERE (course + mode + visibility + group + search) and
     * its bound params. Excludes the band/bucket filter so it can be reused by
     * both the distribution counts and the row query.
     *
     * @param int $courseid Course id.
     * @param string $mode One of MODE_PENDING|MODE_GRADED|MODE_DRAFT.
     * @param int[]|null $visibleids Visible group ids, or null when unrestricted.
     * @param int $groupid Single-group filter, 0 = all visible.
     * @param string $search Free-text needle over student + activity name.
     * @return array{0:string, 1:array<string, mixed>}
     */
    private static function base_where(
        int $courseid,
        string $mode,
        ?array $visibleids,
        int $groupid,
        string $search
    ): array {
        global $DB;

        $where = 'sub.courseid = :courseid';
        $params = ['courseid' => $courseid];

        /* Open work (pending, draft) is gated on the live state of the attempt:
         * `islatest` mirrors assign_submission.latest, on which core gates its
         * own needs-grading reads, and `iscurrent` keeps one live observation
         * per attempt once a resubmission opened a later cycle. The graded side
         * keeps every cycle: each is a genuine response event. */
        if ($mode === self::MODE_DRAFT) {
            $where .= ' AND sub.submissionstatus = :substatus';
            $where .= ' AND sub.islatest = 1 AND sub.iscurrent = 1';
            $params['substatus'] = submission_status::DRAFT;
        } else {
            $where .= ' AND sub.submissionstatus = :substatus';
            $params['substatus'] = submission_status::SUBMITTED;
            $where .= $mode === self::MODE_GRADED
                ? ' AND sub.timegraded IS NOT NULL'
                : ' AND sub.timegraded IS NULL AND sub.islatest = 1 AND sub.iscurrent = 1';
        }

        if ($visibleids !== null) {
            [$gsql, $gparams] = $DB->get_in_or_equal($visibleids, SQL_PARAMS_NAMED, 'gv');
            $where .= " AND sub.groupid $gsql";
            $params += $gparams;
        }
        if ($groupid > 0) {
            $where .= ' AND sub.groupid = :groupid';
            $params['groupid'] = $groupid;
        }
        if ($search !== '') {
            // The student name is matched as fullname() displays it, so a needle copied from the table finds its row.
            [$fullname, $fullnameparams] = \core_user\fields::get_sql_fullname('u');
            $like = $DB->sql_like_escape($search);
            $where .= ' AND (' . $DB->sql_like($fullname, ':searchname', false)
                . ' OR ' . $DB->sql_like('a.name', ':searchact', false) . ')';
            $params += $fullnameparams;
            $params['searchname'] = '%' . $like . '%';
            $params['searchact'] = '%' . $like . '%';
        }

        return [$where, $params];
    }

    /**
     * Layer the band (pending effective-hours ranges) or bucket (graded
     * slabucket) filter on top of the base WHERE.
     *
     * @param string $basewhere Base predicate from base_where().
     * @param array $baseparams Base params.
     * @param string $mode Browse mode.
     * @param string $band aguardando|atencao|prioridade (pending/draft only).
     * @param string $bucket excellent|good|regular|critical (slabucket).
     * @param int $now Reference time for the day measure of open rows.
     * @return array{0:string, 1:array<string, mixed>}
     */
    private static function apply_band_filter(
        string $basewhere,
        array $baseparams,
        string $mode,
        string $band,
        string $bucket,
        int $now
    ): array {
        $where = $basewhere;
        $params = $baseparams;

        $usedays = bucket::use_day_thresholds();

        if ($mode === self::MODE_GRADED) {
            // Graded result band: the stored slabucket in hours mode, or the
            // day-ruler ranges over the stored elapsed-day count in
            // business-days mode (inclusive bounds, mirroring
            // bucket::for_effective_days).
            if ($bucket !== '') {
                if ($usedays) {
                    [$d1, $d2] = bucket::parse_thresholds_days();
                    $days = self::days_expr(self::MODE_GRADED, $now);
                    if ($bucket === bucket::EXCELLENT) {
                        $where .= " AND $days <= :bktda";
                        $params['bktda'] = $d1;
                    } else if ($bucket === bucket::GOOD) {
                        $where .= " AND $days > :bktda AND $days <= :bktdb";
                        $params['bktda'] = $d1;
                        $params['bktdb'] = $d2;
                    } else if ($bucket === bucket::REGULAR || $bucket === bucket::CRITICAL) {
                        // Regular folds in critical: everything past the Good ceiling.
                        $where .= " AND $days > :bktda";
                        $params['bktda'] = $d2;
                    }
                } else if ($bucket === bucket::REGULAR || $bucket === bucket::CRITICAL) {
                    // Regular folds in critical (three-band graded result).
                    $where .= ' AND sub.slabucket IN (:bucketr, :bucketc)';
                    $params['bucketr'] = bucket::REGULAR;
                    $params['bucketc'] = bucket::CRITICAL;
                } else {
                    $where .= ' AND sub.slabucket = :bucket';
                    $params['bucket'] = $bucket;
                }
            }
            return [$where, $params];
        }

        // Pending / draft: the wait band takes precedence over the slabucket
        // filter (matches the block's aguardando/atencao/prioridade tiles).
        // Business-days mode ranges over the stored elapsed-day count with
        // inclusive bounds; hours mode keeps the effective-hours ranges.
        if ($band !== '') {
            if ($usedays) {
                [$dgoal, $dcrit] = self::band_bounds_days();
                $days = self::days_expr($mode, $now);
                if ($band === 'prioridade') {
                    $where .= " AND $days > :bandcrit";
                    $params['bandcrit'] = $dcrit;
                } else if ($band === 'atencao') {
                    $where .= " AND $days > :bandgoal AND $days <= :bandcrit";
                    $params['bandgoal'] = $dgoal;
                    $params['bandcrit'] = $dcrit;
                } else if ($band === 'aguardando') {
                    $where .= " AND $days <= :bandgoal";
                    $params['bandgoal'] = $dgoal;
                }
            } else {
                [$goal, $crit] = self::band_bounds();
                if ($band === 'prioridade') {
                    $where .= ' AND sub.effectivehours >= :bandcrit';
                    $params['bandcrit'] = $crit;
                } else if ($band === 'atencao') {
                    $where .= ' AND sub.effectivehours > :bandgoal AND sub.effectivehours < :bandcrit';
                    $params['bandgoal'] = $goal;
                    $params['bandcrit'] = $crit;
                } else if ($band === 'aguardando') {
                    $where .= ' AND sub.effectivehours <= :bandgoal';
                    $params['bandgoal'] = $goal;
                }
            }
        } else if ($bucket !== '') {
            $where .= ' AND sub.slabucket = :bucket';
            $params['bucket'] = $bucket;
        }

        return [$where, $params];
    }

    /**
     * Distribution counts over the base (band-unfiltered) set. Pending / draft
     * count the wait bands (aguardando/atencao/prioridade); graded counts the
     * result bands. Hours mode uses effective hours and the stored slabucket,
     * business-days mode the day ruler over days_expr().
     *
     * @param string $from Shared FROM + JOIN clause.
     * @param string $basewhere Base predicate.
     * @param array $baseparams Base params.
     * @param string $mode Browse mode.
     * @param int $now Reference time for the day measure of open rows.
     * @return array<string, int>
     */
    private static function counts(string $from, string $basewhere, array $baseparams, string $mode, int $now): array {
        global $DB;

        $usedays = bucket::use_day_thresholds();

        if ($mode === self::MODE_GRADED) {
            if ($usedays) {
                // Day-ruler result bands over the stored elapsed-day count
                // (inclusive bounds, mirroring bucket::for_effective_days).
                [$d1, $d2, $d3] = bucket::parse_thresholds_days();
                $days = self::days_expr(self::MODE_GRADED, $now);
                $sql = "SELECT
                            SUM(CASE WHEN $days <= :d1a THEN 1 ELSE 0 END) AS excellent,
                            SUM(CASE WHEN $days > :d1b AND $days <= :d2a THEN 1 ELSE 0 END)
                                AS good,
                            SUM(CASE WHEN $days > :d2b AND $days <= :d3a THEN 1 ELSE 0 END)
                                AS regular,
                            SUM(CASE WHEN $days > :d3b THEN 1 ELSE 0 END) AS critical
                          $from WHERE $basewhere";
                $params = $baseparams
                    + ['d1a' => $d1, 'd1b' => $d1, 'd2a' => $d2, 'd2b' => $d2, 'd3a' => $d3, 'd3b' => $d3];
                $agg = $DB->get_record_sql($sql, $params);
                return [
                    'excellent' => $agg ? (int) $agg->excellent : 0,
                    'good'      => $agg ? (int) $agg->good : 0,
                    'regular'   => $agg ? (int) $agg->regular : 0,
                    'critical'  => $agg ? (int) $agg->critical : 0,
                ];
            }
            $sql = "SELECT sub.slabucket AS bucket, COUNT(1) AS n $from WHERE $basewhere GROUP BY sub.slabucket";
            $rows = $DB->get_records_sql($sql, $baseparams);
            $counts = self::zero_counts($mode);
            foreach ($rows as $r) {
                $key = (string) $r->bucket;
                if (array_key_exists($key, $counts)) {
                    $counts[$key] = (int) $r->n;
                }
            }
            return $counts;
        }

        if ($usedays) {
            [$dgoal, $dcrit] = self::band_bounds_days();
            $days = self::days_expr($mode, $now);
            $sql = "SELECT
                        SUM(CASE WHEN $days <= :goala THEN 1 ELSE 0 END) AS aguardando,
                        SUM(CASE WHEN $days > :goalb AND $days <= :critb THEN 1 ELSE 0 END)
                            AS atencao,
                        SUM(CASE WHEN $days > :crita THEN 1 ELSE 0 END) AS prioridade
                      $from WHERE $basewhere";
            $params = $baseparams + ['goala' => $dgoal, 'goalb' => $dgoal, 'crita' => $dcrit, 'critb' => $dcrit];
            $agg = $DB->get_record_sql($sql, $params);
            return [
                'aguardando' => $agg ? (int) $agg->aguardando : 0,
                'atencao'    => $agg ? (int) $agg->atencao : 0,
                'prioridade' => $agg ? (int) $agg->prioridade : 0,
            ];
        }

        [$goal, $crit] = self::band_bounds();
        $sql = "SELECT
                    SUM(CASE WHEN sub.effectivehours <= :goala THEN 1 ELSE 0 END) AS aguardando,
                    SUM(CASE WHEN sub.effectivehours > :goalb AND sub.effectivehours < :critb THEN 1 ELSE 0 END)
                        AS atencao,
                    SUM(CASE WHEN sub.effectivehours >= :crita THEN 1 ELSE 0 END) AS prioridade
                  $from WHERE $basewhere";
        $params = $baseparams + ['goala' => $goal, 'goalb' => $goal, 'crita' => $crit, 'critb' => $crit];
        $agg = $DB->get_record_sql($sql, $params);
        return [
            'aguardando' => $agg ? (int) $agg->aguardando : 0,
            'atencao'    => $agg ? (int) $agg->atencao : 0,
            'prioridade' => $agg ? (int) $agg->prioridade : 0,
        ];
    }

    /**
     * Cross-DB ORDER BY for a (mode, sort, order) tuple. Always tie-breaks on
     * sub.id so pagination is stable. The legacy longestwait / recent keys and
     * the per-column keys both resolve here.
     *
     * @param string $mode Browse mode.
     * @param string $sort Column key or legacy sort key.
     * @param string $order 'ASC' or 'DESC' (already normalised).
     * @param int $now Reference time for the day measure of open rows.
     * @return string ORDER BY clause without the leading keyword.
     */
    private static function order_by(string $mode, string $sort, string $order, int $now): string {
        if ($mode === self::MODE_DRAFT) {
            // Drafts have no SLA clock; most-recently-saved first.
            return 'sub.timesubmitted DESC, sub.id ASC';
        }
        switch ($sort) {
            case 'student':
                return "u.lastname $order, u.firstname $order, sub.id ASC";
            case 'activity':
                return "a.name $order, sub.id ASC";
            case 'class':
                return "COALESCE(g.name, '') $order, sub.id ASC";
            case 'submitted':
                return "sub.timesubmitted $order, sub.id ASC";
            case 'effective':
                return "sub.effectivehours $order, sub.id ASC";
            case 'perceived':
                return "sub.waitinghours $order, sub.id ASC";
            case 'status':
                /* Status severity tracks the measure the badge is banded on:
                 * the day count in business-days mode, effective hours
                 * otherwise. Ordering by it groups same-status rows together. */
                if (bucket::use_day_thresholds()) {
                    return self::days_expr($mode, $now) . " $order, sub.id ASC";
                }
                return "sub.effectivehours $order, sub.id ASC";
            case 'graded':
                return "sub.timegraded $order, sub.id ASC";
            case 'recent':
                return 'sub.timesubmitted DESC, sub.id ASC';
            case 'longestwait':
            default:
                return $mode === self::MODE_GRADED
                    ? 'sub.timegraded DESC, sub.id ASC'
                    : 'sub.effectivehours DESC, sub.timesubmitted ASC, sub.id ASC';
        }
    }

    /**
     * Classify one row's effective hours into the pending band shown on the
     * Status badge: aguardando (within goal) | atencao (over goal) | prioridade
     * (critical), with the bounds and comparisons of the hours-mode
     * distribution counts and band filter.
     *
     * @param float $eff Effective hours.
     * @param float $goal Target time in hours.
     * @param float $crit Critical-min hours.
     * @return string
     */
    private static function pending_band(float $eff, float $goal, float $crit): string {
        if ($eff >= $crit) {
            return 'prioridade';
        }
        if ($eff > $goal) {
            return 'atencao';
        }
        return 'aguardando';
    }

    /**
     * Day-ruler pending band — inclusive bounds, mirroring
     * bucket::for_effective_days: prioridade > crit | atencao goal..crit |
     * aguardando <= goal. The same comparisons the business-days counts and
     * band filter run over {@see self::days_expr()}.
     *
     * @param float $days Stored elapsed business days, or for a row not yet
     *                    backfilled the {@see self::estimated_days()} estimate.
     * @param float $goal Target time in days ("within goal" upper bound).
     * @param float $crit Third day threshold (critical cutoff).
     * @return string
     */
    private static function pending_band_days(float $days, float $goal, float $crit): string {
        if ($days > $crit) {
            return 'prioridade';
        }
        if ($days > $goal) {
            return 'atencao';
        }
        return 'aguardando';
    }

    /**
     * The (goal, critical-min) effective-hours bounds that partition pending
     * work into aguardando / atencao / prioridade.
     *
     * @return array{0:float, 1:float}
     */
    private static function band_bounds(): array {
        $goal = (float) (get_config('block_feedback_tracker', 'sla_goal_hours') ?: 24);
        $thresholds = bucket::parse_thresholds_eff();
        return [$goal, (float) $thresholds[2]];
    }

    /**
     * The (goal, critical) elapsed-day bounds that partition pending work in
     * business-days mode, the day-ruler twin of band_bounds(): the target time in
     * days and the third day threshold. {@see rollup_service} bands the
     * block's over-goal and critical day counts on the same pair.
     *
     * @return array{0:float, 1:float}
     */
    private static function band_bounds_days(): array {
        $goal = (float) (get_config('block_feedback_tracker', 'sla_goal_days') ?: 2);
        $thresholds = bucket::parse_thresholds_days();
        return [$goal, (float) $thresholds[2]];
    }

    /**
     * Zeroed counts map for a mode (the distribution vocabulary differs
     * between pending/draft and graded).
     *
     * @param string $mode Browse mode.
     * @return array<string, int>
     */
    private static function zero_counts(string $mode): array {
        if ($mode === self::MODE_GRADED) {
            return ['excellent' => 0, 'good' => 0, 'regular' => 0, 'critical' => 0];
        }
        return ['aguardando' => 0, 'atencao' => 0, 'prioridade' => 0];
    }
}

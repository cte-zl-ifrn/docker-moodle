<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External: cross-course "Grade Now" prioritised list.
 *
 * @package    block_feedback_tracker
 * @copyright  2026 Anderson Blaine <anderson@blaine.com.br>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace block_feedback_tracker\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;
use block_feedback_tracker\local\calendar\day_counter;
use block_feedback_tracker\local\grading\grader_filters;

/**
 * Returns the top-N pending submissions by effective wait across every course
 * the caller can view the dashboard for: the dashboard's "Grade Now" panel, in
 * one query instead of a get_pending_submissions call per course.
 *
 * Authorisation and scope are get_dashboard's, from {@see \block_feedback_tracker\local\sla\dashboard_scope}.
 * On an activity with marker allocation a row is listed for its allocated marker
 * or for everybody when nobody is allocated
 * ({@see \block_feedback_tracker\local\sla\allocation_scope::pending_for_viewer_sql()}).
 */
class get_grader_priority_list extends external_api {
    /** Default number of submissions to return. */
    public const DEFAULT_LIMIT = 10;
    /** Maximum allowed limit — keeps the SQL bounded. */
    public const MAX_LIMIT = 50;

    /**
     * Parameters.
     *
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'limit' => new external_value(
                PARAM_INT,
                'Max submissions to return (1..50)',
                VALUE_DEFAULT,
                self::DEFAULT_LIMIT
            ),
            'bucket' => new external_value(
                PARAM_ALPHA,
                'Optional bucket filter ("" = any)',
                VALUE_DEFAULT,
                ''
            ),
        ]);
    }

    /**
     * Run.
     *
     * @param int $limit
     * @param string $bucket
     * @return array
     */
    public static function execute(int $limit = self::DEFAULT_LIMIT, string $bucket = ''): array {
        global $DB, $USER;

        $params = self::validate_parameters(self::execute_parameters(), [
            'limit'  => $limit,
            'bucket' => $bucket,
        ]);
        $limit = max(1, min((int) $params['limit'], self::MAX_LIMIT));
        $bucket = trim((string) $params['bucket']);

        $sysctx = \context_system::instance();
        self::validate_context($sysctx);

        // Same rules as get_dashboard, since the priority list is a slice of
        // the same data. A user with no visible course has no access.
        $userid = (int) $USER->id;
        $scope = \block_feedback_tracker\local\sla\dashboard_scope::visible_course_ids($userid);
        if ($scope !== null && empty($scope)) {
            throw new \required_capability_exception(
                $sysctx,
                'block/feedback_tracker:viewdashboard',
                'nopermissions',
                'error'
            );
        }
        [$viswhere, $sqlparams] = \block_feedback_tracker\local\sla\dashboard_scope::sql_visibility(
            $userid,
            'sub.courseid',
            'sub.groupid',
            'pc'
        );
        if ($viswhere === \block_feedback_tracker\local\sla\dashboard_scope::MATCH_NONE) {
            return [
                'success'     => true,
                'lastsynced'  => time(),
                'limit'       => $limit,
                'returned'    => 0,
                'submissions' => [],
            ];
        }
        /* islatest / iscurrent keep superseded attempts and closed cycles off
         * the grade-now list: neither is anybody's outstanding task, and both
         * would otherwise sit at the top with an ever-growing clock. */
        $where = 'sub.timegraded IS NULL AND sub.submissionstatus = :substatus'
            . ' AND sub.islatest = 1 AND sub.iscurrent = 1'
            . ' AND ' . $viswhere;
        $sqlparams['substatus'] = \block_feedback_tracker\local\sla\submission_status::SUBMITTED;
        // Marker allocation: decided here, before the LIMIT, so hidden rows never use it up.
        [$allocsql, $allocparams] = \block_feedback_tracker\local\sla\allocation_scope::pending_for_viewer_sql(
            $userid,
            'sub.iteminstance',
            'sub.userid',
            'sub.attemptnumber'
        );
        $where .= ' AND ' . $allocsql;
        $sqlparams += $allocparams;
        $usedays = \block_feedback_tracker\local\sla\bucket::use_day_thresholds();
        if ($bucket !== '') {
            if ($usedays) {
                // Day-ruler bucket ranges over the stored elapsed-day count
                // (inclusive bounds, mirroring bucket::for_effective_days).
                [$d1, $d2, $d3] = \block_feedback_tracker\local\sla\bucket::parse_thresholds_days();
                /* Rows still awaiting the effectivedays backfill would compare
                 * against NULL and drop out of every bucket — which on a
                 * priority list silently hides the most overdue work. Fall back
                 * to elapsed calendar days, always >= business days, so a row
                 * is never filed as less urgent than it is. */
                $days = sprintf(
                    'COALESCE(sub.effectivedays, (%d - sub.timesubmitted) / 86400.0)',
                    time()
                );
                if ($bucket === 'excellent') {
                    $where .= " AND $days <= :bktda";
                    $sqlparams['bktda'] = $d1;
                } else if ($bucket === 'good') {
                    $where .= " AND $days > :bktda AND $days <= :bktdb";
                    $sqlparams['bktda'] = $d1;
                    $sqlparams['bktdb'] = $d2;
                } else if ($bucket === 'regular') {
                    $where .= " AND $days > :bktda AND $days <= :bktdb";
                    $sqlparams['bktda'] = $d2;
                    $sqlparams['bktdb'] = $d3;
                } else if ($bucket === 'critical') {
                    $where .= " AND $days > :bktda";
                    $sqlparams['bktda'] = $d3;
                }
            } else {
                $where .= ' AND sub.slabucket = :bucket';
                $sqlparams['bucket'] = $bucket;
            }
        }

        // Top-N by effective wait descending; ties go to the oldest submission.
        // The course context columns preload the contexts the names are formatted in.
        $sqlparams['bftctxcourse'] = CONTEXT_COURSE;
        $ctxfields = \context_helper::get_preload_record_columns_sql('ctx');
        $namefields = \core_user\fields::for_name()->get_sql('u')->selects;
        $sql = "SELECT sub.id, sub.cmid, sub.userid, sub.courseid, sub.groupid,
                       sub.iteminstance, sub.attemptnumber, sub.cycle, sub.submissionstatus,
                       sub.timesubmitted, sub.waitinghours, sub.effectivehours,
                       sub.effectivedays, sub.slabucket,
                       c.fullname AS coursename,
                       cm.groupmode AS cmgroupmode, c.groupmode AS coursegroupmode,
                       c.groupmodeforce AS coursegroupmodeforce,
                       $ctxfields
                       $namefields
                  FROM {block_feedback_tracker_sub} sub
                  JOIN {user} u ON u.id = sub.userid
                  JOIN {course} c ON c.id = sub.courseid
                  JOIN {context} ctx ON ctx.instanceid = c.id AND ctx.contextlevel = :bftctxcourse
                  JOIN {course_modules} cm ON cm.id = sub.cmid
                 WHERE $where
              ORDER BY sub.effectivehours DESC, sub.timesubmitted ASC";

        $rows = $DB->get_records_sql($sql, $sqlparams, 0, $limit);
        foreach ($rows as $r) {
            \context_helper::preload_from_record($r);
        }

        /* Names are filtered (multilang and other string filters) but not
         * escaped: PARAM_TEXT and the text nodes the dashboard renders them
         * into escape for themselves. One query each for activity and group
         * names, over at most $limit rows. */
        $activitynames = self::activity_names(array_map(static fn($r) => (int) $r->cmid, $rows));
        $groupids = array_unique(array_filter(array_map(static fn($r) => (int) $r->groupid, $rows)));
        $groupnames = [];
        if (!empty($groupids)) {
            [$ginsql, $ginparams] = $DB->get_in_or_equal($groupids, SQL_PARAMS_NAMED);
            foreach ($DB->get_records_select('groups', "id $ginsql", $ginparams, '', 'id, courseid, name') as $g) {
                $groupnames[(int) $g->id] = format_string(
                    (string) $g->name,
                    true,
                    ['context' => \context_course::instance((int) $g->courseid), 'escape' => false]
                );
            }
        }

        $previousmarks = \block_feedback_tracker\local\sla\resubmission::previous_marks($rows);
        $submissions = [];
        foreach ($rows as $r) {
            // Pending-only list (timegraded IS NULL): elapsed days run up to now.
            $days = day_counter::between((int) $r->timesubmitted, time());
            $coursename = format_string(
                (string) $r->coursename,
                true,
                ['context' => \context_course::instance((int) $r->courseid), 'escape' => false]
            );
            $submissions[] = [
                'submissionid'   => (int) $r->id,
                'cmid'           => (int) $r->cmid,
                'userid'         => (int) $r->userid,
                'studentname'    => fullname($r),
                'courseid'       => (int) $r->courseid,
                'coursename'     => $coursename,
                'groupid'        => (int) $r->groupid,
                'groupname'      => (string) ($groupnames[(int) $r->groupid] ?? ''),
                'gradergate'     => (int) grader_filters::row_needs_gate(
                    (int) $r->courseid,
                    (int) $r->cmgroupmode,
                    (int) $r->coursegroupmode,
                    (int) $r->coursegroupmodeforce,
                    \context_module::instance((int) $r->cmid)
                ),
                'activityname'   => (string) ($activitynames[(int) $r->cmid] ?? ''),
                'timesubmitted'  => (int) $r->timesubmitted,
                'waitinghours'   => (float) $r->waitinghours,
                'effectivehours' => (float) $r->effectivehours,
                'effective_days' => $days['business'],
                'perceived_days' => $days['calendar'],
                'slabucket'      => $usedays
                    ? \block_feedback_tracker\local\sla\bucket::for_effective_days(
                        $r->effectivedays !== null ? (float) $r->effectivedays : null
                    )
                    : (string) $r->slabucket,
                'resubmitted'    => (int) array_key_exists((int) $r->id, $previousmarks),
                'previousmarktime' => (int) ($previousmarks[(int) $r->id] ?? 0),
            ];
        }

        return [
            'success'     => true,
            'lastsynced'  => time(),
            'limit'       => $limit,
            'returned'    => count($submissions),
            'submissions' => $submissions,
        ];
    }

    /**
     * Assignment names keyed by course module id, formatted in each module's
     * context (filters can be switched off per activity).
     *
     * The activity is resolved through {course_modules} and {modules}, not
     * from the instance id alone, so a module of another type never lends its
     * instance id to an unrelated assignment.
     *
     * @param int[] $cmids Course module ids; duplicates are ignored.
     * @return array<int, string> Plain (unescaped) names keyed by cmid.
     */
    private static function activity_names(array $cmids): array {
        global $DB;
        $cmids = array_values(array_unique($cmids));
        if (empty($cmids)) {
            return [];
        }
        [$insql, $params] = $DB->get_in_or_equal($cmids, SQL_PARAMS_NAMED, 'bftcm');
        $params['bftmodname'] = 'assign';
        $params['bftctxmodule'] = CONTEXT_MODULE;
        $ctxfields = \context_helper::get_preload_record_columns_sql('ctx');
        $sql = "SELECT cm.id AS cmid, a.name, $ctxfields
                  FROM {course_modules} cm
                  JOIN {modules} m ON m.id = cm.module AND m.name = :bftmodname
                  JOIN {assign} a ON a.id = cm.instance
                  JOIN {context} ctx ON ctx.instanceid = cm.id AND ctx.contextlevel = :bftctxmodule
                 WHERE cm.id $insql";
        $names = [];
        foreach ($DB->get_records_sql($sql, $params) as $r) {
            \context_helper::preload_from_record($r);
            $names[(int) $r->cmid] = format_string(
                (string) $r->name,
                true,
                ['context' => \context_module::instance((int) $r->cmid), 'escape' => false]
            );
        }
        return $names;
    }

    /**
     * Returns.
     *
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'success'    => new external_value(PARAM_BOOL, ''),
            'lastsynced' => new external_value(PARAM_INT, ''),
            'limit'      => new external_value(PARAM_INT, ''),
            'returned'   => new external_value(PARAM_INT, ''),
            'submissions' => new external_multiple_structure(new external_single_structure([
                'submissionid'   => new external_value(PARAM_INT, ''),
                'cmid'           => new external_value(PARAM_INT, ''),
                'userid'         => new external_value(PARAM_INT, ''),
                'studentname'    => new external_value(PARAM_TEXT, ''),
                'courseid'       => new external_value(PARAM_INT, ''),
                'coursename'     => new external_value(PARAM_TEXT, ''),
                'groupid'        => new external_value(PARAM_INT, ''),
                'groupname'      => new external_value(PARAM_TEXT, ''),
                'gradergate'     => new external_value(
                    PARAM_INT,
                    '1 when the grade link must pass through pages/open_grader.php: the activity is in a group mode '
                        . 'and the viewer cannot access all groups'
                ),
                'activityname'   => new external_value(PARAM_TEXT, ''),
                'timesubmitted'  => new external_value(PARAM_INT, ''),
                'waitinghours'   => new external_value(PARAM_FLOAT, ''),
                'effectivehours' => new external_value(PARAM_FLOAT, ''),
                'effective_days' => new external_value(PARAM_INT, 'Elapsed business days (date-based)'),
                'perceived_days' => new external_value(PARAM_INT, 'Elapsed calendar days (date-based)'),
                'slabucket'      => new external_value(PARAM_ALPHA, ''),
                'resubmitted'    => new external_value(
                    PARAM_INT,
                    '1 when the attempt already carried a mark when this work was handed in (core\'s Graded - resubmitted)'
                ),
                'previousmarktime' => new external_value(
                    PARAM_INT,
                    'When the attempt was marked before this hand-in; 0 when the time is no longer known'
                ),
            ])),
        ]);
    }
}

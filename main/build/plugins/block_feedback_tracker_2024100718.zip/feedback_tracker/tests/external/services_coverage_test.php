<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Drift-check covering every entry in db/services.php.
 *
 * @package    block_feedback_tracker
 * @copyright  2026 Anderson Blaine <anderson@blaine.com.br>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace block_feedback_tracker\external;

/**
 * For every function declared in db/services.php, asserts:
 *   - the class exists,
 *   - it extends \core_external\external_api,
 *   - execute_parameters() / execute() / execute_returns() are defined,
 *   - the listed capability exists: in db/access.php for the plugin's own
 *     namespace, in the installed capabilities table for any other,
 *   - a test file exists for it and claims coverage of the class,
 *   - and, when the function is capability-gated, that test file exercises a
 *     refusal.
 *
 * It also asserts that every scheduled task in db/tasks.php is claimed by a
 * test under tests/task/.
 *
 * Registering a web service without a test, or without a test of its
 * capability refusal, therefore fails the build. The checks also catch a
 * class renamed without updating services.php and a capability deleted while
 * still referenced.
 *
 * @coversNothing
 */
final class services_coverage_test extends \advanced_testcase {
    public function test_every_declared_service_has_a_valid_class(): void {
        $functions = self::load_functions();
        $this->assertNotEmpty($functions, 'db/services.php should declare at least one function.');

        foreach ($functions as $name => $def) {
            $msg = "WS function `{$name}`: ";
            $this->assertArrayHasKey(
                'classname',
                $def,
                $msg . 'missing classname'
            );
            $classname = (string) $def['classname'];
            $this->assertTrue(
                class_exists($classname),
                $msg . "class `{$classname}` does not exist"
            );
            $this->assertTrue(
                is_subclass_of($classname, \core_external\external_api::class),
                $msg . "{$classname} does not extend external_api"
            );
            $this->assertTrue(
                method_exists($classname, 'execute_parameters'),
                $msg . "{$classname}::execute_parameters() missing"
            );
            $this->assertTrue(
                method_exists($classname, 'execute_returns'),
                $msg . "{$classname}::execute_returns() missing"
            );
            $this->assertTrue(
                method_exists($classname, 'execute'),
                $msg . "{$classname}::execute() missing"
            );
        }
    }

    public function test_every_listed_capability_exists(): void {
        $functions = self::load_functions();
        $declaredcaps = self::load_capabilities();

        foreach ($functions as $name => $def) {
            if (!isset($def['capabilities']) || $def['capabilities'] === '') {
                continue;
            }
            $caps = preg_split('/\s*,\s*/', (string) $def['capabilities']);
            foreach ($caps as $cap) {
                if ($cap === '') {
                    continue;
                }
                $this->assertTrue(
                    self::capability_exists($cap, $declaredcaps),
                    "WS function `{$name}` references unknown capability `{$cap}`"
                );
            }
        }
    }

    /**
     * The existence check tells real capabilities from misspelt ones on both
     * sides of the plugin namespace. db/services.php lists no capability from
     * outside the plugin today, so this is what shows that branch works.
     *
     * @return void
     */
    public function test_capability_check_rejects_unknown_names(): void {
        $declaredcaps = self::load_capabilities();

        $this->assertTrue(self::capability_exists('block/feedback_tracker:viewresponsiveness', $declaredcaps));
        $this->assertFalse(self::capability_exists('block/feedback_tracker:nosuchcapability', $declaredcaps));
        $this->assertTrue(self::capability_exists('moodle/site:config', $declaredcaps));
        $this->assertFalse(self::capability_exists('moodle/site:nosuchcapability', $declaredcaps));
    }

    /**
     * Every declared web service has a test file that claims coverage of it.
     *
     * @return void
     */
    public function test_every_declared_service_has_a_test_file(): void {
        foreach (self::load_functions() as $name => $def) {
            $classname = (string) $def['classname'];
            $short = substr($classname, (int) strrpos($classname, '\\') + 1);
            $path = __DIR__ . '/' . $short . '_test.php';

            $this->assertFileExists(
                $path,
                "WS function `{$name}` has no test file — expected tests/external/{$short}_test.php"
            );
            $this->assertStringContainsString(
                '@covers \\' . $classname,
                (string) file_get_contents($path),
                "tests/external/{$short}_test.php must declare @covers \\{$classname}"
            );
        }
    }

    /**
     * Every capability-gated web service has a test that exercises the
     * refusal, not just the happy path.
     *
     * The check is textual: the test file must mention
     * required_capability_exception. Without it a gate could be deleted with
     * every test still green.
     *
     * @return void
     */
    public function test_every_gated_service_has_a_refusal_test(): void {
        foreach (self::load_functions() as $name => $def) {
            if (!isset($def['capabilities']) || $def['capabilities'] === '') {
                continue;
            }
            $classname = (string) $def['classname'];
            $short = substr($classname, (int) strrpos($classname, '\\') + 1);
            $path = __DIR__ . '/' . $short . '_test.php';
            if (!file_exists($path)) {
                // The previous test already reports this; do not double-fail.
                continue;
            }
            $this->assertStringContainsString(
                'required_capability_exception',
                (string) file_get_contents($path),
                "WS function `{$name}` is capability-gated but tests/external/{$short}_test.php "
                    . 'never asserts a refusal'
            );
        }
    }

    /**
     * Every scheduled task declared in db/tasks.php is claimed by a test file.
     *
     * Several tasks share one file (scheduled_tasks_test covers the service
     * wrappers and two retention tasks), so the check is that some test in
     * tests/task/ names the class, not that a file exists per task.
     *
     * @return void
     */
    public function test_every_scheduled_task_is_claimed_by_a_test(): void {
        $tasks = [];
        require(__DIR__ . '/../../db/tasks.php');
        $this->assertNotEmpty($tasks, 'db/tasks.php should declare at least one task.');

        $claimed = '';
        foreach (glob(__DIR__ . '/../task/*_test.php') ?: [] as $file) {
            $claimed .= (string) file_get_contents($file);
        }

        foreach ($tasks as $def) {
            $classname = (string) $def['classname'];
            $this->assertStringContainsString(
                $classname,
                $claimed,
                "Scheduled task {$classname} is not named by any test in tests/task/"
            );
        }
    }

    public function test_every_service_returns_a_structure(): void {
        $functions = self::load_functions();
        foreach ($functions as $name => $def) {
            $classname = (string) $def['classname'];
            $returns = $classname::execute_returns();
            $this->assertInstanceOf(
                \core_external\external_description::class,
                $returns,
                "WS function `{$name}`: execute_returns() must return an external_description"
            );
        }
    }

    /**
     * Read db/services.php into the $functions array via include.
     *
     * @return array
     */
    private static function load_functions(): array {
        $functions = [];
        require(__DIR__ . '/../../db/services.php');
        return $functions;
    }

    /**
     * Read db/access.php into the $capabilities array via include.
     *
     * @return array
     */
    private static function load_capabilities(): array {
        $capabilities = [];
        require(__DIR__ . '/../../db/access.php');
        return $capabilities;
    }

    /**
     * Whether a capability a web service lists exists. The plugin's own
     * block/feedback_tracker:* names must be declared in db/access.php; any
     * other name (core or another plugin) must be installed on the site.
     *
     * @param string $cap
     * @param array $declaredcaps The plugin's db/access.php capabilities, keyed by name.
     * @return bool
     */
    private static function capability_exists(string $cap, array $declaredcaps): bool {
        if (strpos($cap, 'block/feedback_tracker:') === 0) {
            return isset($declaredcaps[$cap]);
        }
        return get_capability_info($cap) !== null;
    }
}

# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v4.5-r4] - 2026-11-02

The client-side performance audit (the teacher dashboard shows 50 courses at a time and its services
read once, not per course; the course report applies only the latest answer; a Read-only sessions
check), course backup and restore, background walks for bulk changes, and the Feedback Flow name
(version `2024100718`).

### Added
- **A Read-only sessions check on the Performance overview report** (*Site
  administration > Reports > Performance overview*). Every web service of the
  plugin is a read declared read-only, which core honours only when config.php
  sets `$CFG->enable_read_only_sessions = true;`; without it the calls a
  dashboard or report load starts together wait for each other on the session
  lock (three calls of 2-12 ms of work finished 130, 240 and 360 ms after they
  started, on a development site). The check warns while the flag is off, and
  its details and the README's new *Performance: Redis and read-only sessions*
  section say what to map first: core starts no session with the flag set
  while a session-mode cache is kept in the session store, so the cache
  stores move to Redis first. Measured with 500 courses, a course report's
  calls all answered within 61-75 ms with Redis and the flag, against
  357-458 ms without; Redis alone changed nothing (client-side performance
  audit, finding S1). Four new strings,
  `checkreadonlysessions` and its `_details`, `_ok` and `_warning`.
- **Course backup and restore** (issue #118), chosen by a new setting,
  `block_feedback_tracker/backup_ledger`. By default (`rederive`) a backup
  carries nothing of the plugin, and a restore queues `rederive_course`, which
  rebuilds the restored course's measurements from its submissions and grades
  whatever `backfill_active` says. With `full`, backups that include user data
  carry every ledger cycle of the course (`backup/moodle2/`); the restore
  maps them to the restored activities, students, groups and markers, moves
  the rule dates with the course start, and then rebuilds the rest. A restore follows the file, not the setting.

### Fixed
- **The course report shows only the answer to the latest request.** Its table
  page, drafts and academic-days strip each took the last answer to arrive, so
  a slow answer for a filter, page, class or mode the teacher had already left
  painted its rows under the new one: pressing Waiting then Attention could
  leave Waiting's rows under the Attention filter, and Graded then To grade
  could leave the graded list, each row offering "Grade", under the To grade
  columns. Each request now carries a number and only the latest one changes
  the screen. Switching between To grade and Graded drops the old mode's rows
  and shows the loading skeleton until the new mode's page lands, instead of
  drawing the old rows under the new columns, and the distribution bar shows a
  dash rather than 0 while it has no counts. Graded mode no longer fetches the
  drafts it does not show (client-side performance audit, findings B3 and B6).
- **The component smoke test page (`pages/spike_react.php`) shows its labels in
  the viewer's language** (issue #122). The demo card spelt its
  card title, band labels, counts, metrics, score breakdown and button in
  English inside `amd/src/spike_react.js`. The page now embeds
  `bootstrap::spike_i18n()`, built from the strings the real surfaces use, and
  the gauge and sparkline get their accessible names from it too. One new
  string, `spike_reroll`.
- **The activity re-derivation and the rollup re-queue reset the process
  memos first**, as every other task of the plugin does. `rederive_activity`
  read whether its course is tracked from a memo another task of the same cron
  process may have filled, so a course that gained or lost the block in the
  meantime could be skipped or walked. `process_memos_test` now fails for any
  task whose `execute()` does not start with the reset.
- **The plugin is called Feedback Flow everywhere it names itself, and Fluxo
  de Devolutivas in Brazilian Portuguese.** The teacher dashboard's tag line
  and the two page-view events (their names in the log and their
  descriptions) still said "Feedback tracker", and five capability names in
  Portuguese still translated the old name. The component,
  `block_feedback_tracker`, is unchanged.

### Changed
- **The teacher dashboard's services no longer read once per course.** The
  scope the dashboard, the grader priority list and the insights share read
  each visible course on its own to learn its group mode, and the SQL they
  built had one clause per course. The courses (with their contexts) are now
  read in one query, the courses a viewer sees whole share one `IN` list, and
  a restricted course keeps its own course-and-groups clause. The insights'
  week-over-week momentum, which ran two ledger queries per class, now reads
  the two weeks once. For a manager of 500 courses (2,000 classes): the
  dashboard 511 -> 12 reads, the priority list 507 -> 8 on every call, the
  insights 4,514 -> 14 reads and 592 -> 211 ms on a cold cache. The answers
  are identical, checked on both viewers of the audit's fixture (client-side
  performance audit, finding S2).
- **The teacher dashboard shows 50 courses at a time.** The courses table lists
  the first 50 of the chosen order, with "Showing 50 of 500 courses" and a
  **Show more** button that adds 50 more and moves focus to the first new row.
  Sorting still orders every course, and the headline figures still cover all
  of them. A viewer of hundreds of courses paid for laying out every row: at
  500 courses the page blocked for 481-605 ms while loading and took 320-408 ms
  to answer a sort press (client-side performance audit,
  `docs/performance-audit/PLAN.md`, finding A1). Two new strings,
  `dashboard_showing` and `dashboard_showmore`.
- **Single-column ledger updates go through `set_field_select()`** (issue
  #119): the `iscurrent` and `islatest` writes of `submission_ledger` and the
  release's `timegraded` close. Two writes keep a raw `UPDATE`, each with a
  comment saying why: the release stamp sets four columns, two of them through
  `COALESCE` over the row's own value, and the legacy dismissal sets three
  columns under a guard that reads one of them. Same statements, same counts.
- **A calendar edit or a settings save no longer walks every rollup tuple in
  the request** (issue #120, stage 1). Saving a calendar day, business hours, a
  site or course pause, or a rule-changing setting cost two statements per
  tuple inside the admin's request (200,000 statements and about 19 s for
  100,000 tuples). The request now bumps the calendar version, purges the
  caches, writes the audit row and queues one `requeue_rollups` adhoc task; the
  task walks the tuples in the background. Consecutive edits of one scope share
  one task. A group pause still re-queues its one tuple in the request.
- **"SLA" is gone from the interface.** The target response time is now
  "Target time" (pt_br "Prazo de retorno"), and the share answered within it
  "Within target" (pt_br "Retorno dentro do prazo"; "No prazo" on the group
  card, which drops its "within" caption). "Compliance" names the same figure
  and is renamed with it, in the score simulator and in the score weight
  setting. The pause-window capability, event and cache names drop "SLA". The
  setting descriptions say the target time is a reference for the
  indicators, not a contractual commitment. Setting keys and stored values do
  not change.
- **Saving an assignment's settings or revealing its identities re-derives
  every row, in the background** (issue #120, stage 2). Both read up to
  20,000 rows and queued the backfill tasks inside the teacher's request, and
  an activity with more rows was re-derived only up to the 20,000th, with a
  debugging notice as the only trace. The request now queues one
  `rederive_activity` adhoc task, which walks the activity in windows of ids
  with no ceiling; consecutive saves of one activity share one walk.
- **Deleting a group re-attributes its rows in the background, and no group,
  override or extension change re-dates rows** (issue #120, stage 3). Deleting a
  group read up to 20,000 users in the request and moved up to 50 of them there;
  it now queues one `reattribute_users` task for the course and group, which
  walks the group's users in pages with no ceiling. The open, due and cut-off
  dates a row stores are now frozen when its cycle closes: the writer resolves
  them from live state while the cycle is open and keeps them once it has
  closed, so a closed cycle records the dates in force when the teacher
  answered. With that, the seven group override, user override and extension
  observers, the re-dating after a membership change and the reconciler's
  `rules` sweep are removed: saving a group override no longer rewrites every
  member's rows in the teacher's request (200,009 statements and 425 s for
  100,000 members), and no rollup is re-queued for a date change. An upgrade
  step removes the sweep's cursor.

## [v4.5-r3] - 2026-10-23

The teacher dashboard's undefined-constant fix, with two tests that guard the
whole class of defect (version `2024100706`).

### Fixed
- **The teacher dashboard no longer fails with `Undefined constant
  "block_feedback_tracker\local\grading\ASSIGN_FILTER_NONE"`.** It failed for
  any teacher with a saved status filter on an assignment's grading page, on
  every load except the first after a cache purge. The grade-link gate
  (`grader_filters`, since v4.5-r1) compared that preference with mod_assign's
  constant, which only `mod/assign/locallib.php` defines. The dashboard, the
  pending report, the score simulator and the block do not load that file, and
  a request loads it as a side effect only while it rebuilds the plugin caches.
  The class now spells the value itself.

### Added
- `tests/runtime_symbols_test.php`: every global constant, function and class
  that runtime code names must be loaded on every request (what `lib/setup.php`
  loads), built into PHP, autoloaded, or declared by the file or a file it
  requires. The test reads the files instead of asking the PHPUnit process,
  which has every plugin's `lib.php`, mod_assign's `locallib.php` and the
  gradebook constants loaded and so passed against this defect.
- `tests/local/grading/grader_filters_without_locallib_test.php` runs the gate
  in a child process booted as `admin/tool/phpunit/cli/util.php` boots, where
  `locallib.php` is not loaded, and fails if it is.
- `mutations/gates.conf`: four gates for these guards (G1-G4).

## [v4.5-r2] - 2026-10-23

The Moodle plugins directory's submission guidelines, checked by a test (version
`2024100705`).

### Added
- `LICENSE` beside `COPYING.txt`, both the GPL v3 text: the directory asks for a
  licence file in the package, and the MAH completeness check still asks for
  `COPYING.txt`.
- `tests/marketplace_readiness_test.php`, the fleet's file-reading check of the
  guidelines: licence files shipped, English-only package, data-only lang files,
  a README naming every table, capability and dependency, settings stored as
  `block_feedback_tracker/<name>`, every stylesheet selector scoped to the
  plugin, the GPL boilerplate in every source file, and the privacy cover of any
  core row stamped with the component (the plugin writes none).
- README sections *Settings*, *Capabilities*, *Data stored* (every table, what a
  row holds, what removes it, and what a data request exports or deletes) and
  *Translations*.
- `mutations/gates.conf`: one mutation per new guard, each reddening the test
  written for it.

### Changed
- **Every rule of `styles.css` is scoped to the plugin.** The tokens were declared
  on `:root` and `body`, and the badge rules (`.badge.badge-excellent`, ...)
  matched any page of the site. Each selector now starts with
  `:where(.block-feedback-tracker)`: the block adds that class to its own element
  (`html_attributes()`) and every page under `pages/` to its body. `:where()` has
  no specificity, so each rule meets the theme with the specificity it had
  before. `stylesheet_contract_test` checks that every page carries the class.
- `settings.php` spells each setting's stored name as a literal
  `block_feedback_tracker/<name>` instead of building it from a variable.
- `lang/pt_br` is left out of the release package (`export-ignore`); the
  translation stays in the repository and reaches sites through AMOS.
- README: the peer context compares a group with every other scored group on the
  site, not a department; the requirements name Moodle 4.5's database minimums;
  the installation step says where the calendar itself is edited.

## [v4.5-r1] - 2026-10-18

The Moodle 4.5 release, and the first under the fleet's release names: one
release per Moodle branch, tagged `v<moodle>-r<N>` with the same name in
`$plugin->release` (it was `1.2.0`). `main` is now the Moodle 5.3 branch; the
4.5 line continues on `MOODLE_405_STABLE`.

### Changed
- **Bulk removal shows its queue and works in batches** (version `2024100702`).
  `pages/bulk_remove.php` queues a task and cron removes the blocks on its next
  run, so the courses used to stay on the list and could be queued again.
  - Courses waiting in a removal are listed in a "Waiting for removal" panel
    and left out of the course list, its total and the server-side check, so
    a course cannot be queued twice.
  - The list holds at most 100 courses, the most one request may queue, and
    says so when more match. After queuing, the page keeps the filter and
    lists the next batch at once.
  - "Select all N listed courses" ticks every loaded row and reveals the
    collapsed ones; "Recently completed" lists the last five finished runs
    from the audit log, with their counts.
  - The selection is checked on the server against the filter without the
    100-row ceiling (`course_finder::matching_ids()`), a request with more
    than 100 courses or no filter question answered queues nothing, and the
    administrator is told how many selected courses were skipped.
  - The measured-rows column is counted for the listed courses only, not for
    every course the filter matches: about a second per million ledger rows
    on each listing before.
  - In `discardnow` mode a course's discard failure no longer stops the batch:
    it is reported and retried by a `discard_course_data` task. The mode no
    longer leaves a deferred discard task behind for every course, which only
    found the history already gone.
  - Measured on Moodle 5.2 with PostgreSQL: 500 courses leave in 3 s, and
    10 s when `discardnow` also deletes a million ledger rows, at 22 MB.
- **The twelve read web services no longer hold the session lock** (version
  `2024100700`). Every `type => read` function in `db/services.php` now declares
  `'readonlysession' => true`, as core does for its own reads. The dashboard's
  three loads (`get_dashboard`, `get_grader_priority_list`, `get_insights`), the
  report page's and the block's no longer wait for one another, or for the
  page's other requests of the same session.
  - It takes effect only on a site that sets `$CFG->enable_read_only_sessions`.
    Such a site must map its session-mode caches outside the session store, and
    this plugin has two: `responsiveness_payload` and `dashboard_payload`.
  - Nothing on these paths writes `$SESSION`, `$USER` or the database: the
    recompute writers run only from tasks and the calendar observer.
    `tests/external/readonly_session_test.php` checks each service on a tracked
    course with a pending and a graded submission, and that every read and no
    write carries the flag.
  - Measured on Moodle 5.2 with the site flag on, four simultaneous calls of one
    service took 4.9 to 13.1 times one call before the change and 1.3 to 2.4
    times after it. The dashboard's three loads fired together went from 263-292 ms
    to 48-63 ms.
- **One branch per Moodle version, each numbered in that version's range.**
  `main` is now the Moodle 5.2 branch, the same commit as `MOODLE_502_STABLE`:
  `$plugin->requires` 5.2, `$plugin->supported = [502, 502]`, version
  `2026042000`. `MOODLE_501_STABLE` is the Moodle 5.1 branch, version
  `2025100600`. `MOODLE_405_STABLE` is the Moodle 4.5 branch, version
  `2024100700`, cut from `main` after the read-only session change. Each
  branch counts up inside its own range from here on. Moodle 5.0 is no longer
  served by any branch: sites there stay on 1.1.0.
- **The upgrade steps of 1.0.0 to 1.1.0 were removed.** They were numbered by
  date, above every per-version range, so a site lowering its version to
  switch would have run them all again. 1.1.0 (version `2026100902`) is the
  last date-numbered release and still carries them. The upgrade now checks
  the schema instead, and stops with instructions on a site that never
  reached 1.1.0.

### Fixed
- **Grade Now lists a student for the allocated marker** (version `2024100704`). On an
  activity with marking workflow and marker allocation, the teacher dashboard's
  cross-course Grade Now list now shows a student only to the marker allocated to them
  and only until the attempt is graded, and shows a student with no allocated marker to
  every teacher (the coordinator's queue); activities without allocation are unchanged.
  The rule is decided in SQL before the limit (`allocation_scope`), so hidden rows do not
  use the limit up.
- **Marker allocation is also observed from Moodle 5.3's events** (version
  `2024100703`). `db/events.php` now subscribes `marker_added` and `marker_removed`
  beside `marker_updated`; the classes exist only from 5.3, so here the lines are inert
  and the file stays identical on every branch. The allocation test now allocates
  through core's batch "Set allocated marker" operation instead of firing
  `marker_updated` by hand, so it fails if core stops sending the event; a second test
  covers two students allocated in one batch call. The `allocsource` column comment
  and the multi-marking and design docs no longer carry stale claims.
- **The historical backfill honours the retention window.** With
  `retention_active` on, `backfill_history` no longer dispatches submissions
  last modified before `retention::cutoff()`, the floor `reconcile_ledger`'s
  row-creating sweeps already apply. Before, a backfill walked every
  submission of the course and ingested closed history that `prune_ledger`
  deleted on its next run. The cursor still walks the whole course, so a course
  backfilled while retention was on is walked again in full only after
  `cli/backfill_course.php --reset`.
- **A grade link no longer opens another student** (version `2024100701`).
  mod_assign's grader lists only the students the teacher's saved filters let
  through (status, marking workflow, marker, the name initials of that
  assignment's grading table) and the active group; when the linked student is
  not among them, it opens the first student of the list instead. The grade
  links of the pending report and the dashboard's priority cards now go through
  `pages/open_grader.php` when the teacher may carry such state, which clears
  the saved filters, or switches the grader's group, only when they hide the
  student, and says so on the grader. A filter that keeps the student listed is
  left alone.
  - Cost: a teacher with no saved filter and no selected group, in an activity
    without groups or with access to all groups, still gets the direct link;
    the decision reads only the preferences already in the session.
    `config.grader_gate` and the rows' new `gradergate` field carry it.
  - The page asks core's own grading table, restricted to the one student by
    its `userid` parameter: measured at 8-10 ms and 21 queries for a class of
    200 or 2,000 students, against 12-116 ms for the whole-class table.
  - When the active group already hides the student, the saved filters are
    cleared as well, without telling whether they alone would have hidden
    them: core's check reads the group too.
  - The page needs the grader's own capability (`mod/assign:grade` or
    `mod/assign:viewgrades`) and changes nothing without the user's sesskey:
    the link then opens the grader as before.

### Upgrading from 1.1.0 or earlier
The new version numbers are lower than 1.1.0's, so Moodle refuses the new code
as a downgrade until the stored version is lowered:

1. If the site is below 1.1.0, upgrade to 1.1.0 first (version `2026100902`).
   Every earlier upgrade step runs there.
2. Enable maintenance mode, then replace the plugin files with this release.
3. Set the stored version just below this release, from the directory that
   holds `admin/` (`public/` on Moodle 5.1 and later):
   - Moodle 5.2 (`main`, `MOODLE_502_STABLE`):
     `php admin/cli/cfg.php --component=block_feedback_tracker --name=version --set=2026041999`
   - Moodle 5.1 (`MOODLE_501_STABLE`):
     `php admin/cli/cfg.php --component=block_feedback_tracker --name=version --set=2025100599`
   - Moodle 4.5 (`MOODLE_405_STABLE`):
     `php admin/cli/cfg.php --component=block_feedback_tracker --name=version --set=2024100699`
4. Run `php admin/cli/upgrade.php`, then disable maintenance mode.

Do step 3 only after step 2: with the 1.1.0 files still in place, a lowered
version would make the next upgrade run every step of 1.1.0 again.

## [1.1.0] - Unreleased

### Changed
- **Reconciliation no longer reads the whole submission table per query.**
  Measured on 5 million submissions (250 000 students, 6 000 groups):
  - the missing-row sweep cost 1.6 s per window of 500 on PostgreSQL, because
    its window filtered by course through joins and read every submission of
    the tracked courses to keep 500; the window now walks the primary key
    alone and the tracked submissions are picked out in PHP, which is cheap on
    both PostgreSQL and MariaDB (filtering by a list of assignment ids instead
    was fast on PostgreSQL and 1.6 s per window on MariaDB);
  - its probe started from the activities and scanned their submissions
    again, 0.9 s, and now starts from the window's ids, 16 ms;
  - the departed-participant sweep compared every ledger row of a course with
    every participant, 1.75 s per course; it now looks each row up, about
    75 ms per course.

  The missing-row and departed-participant sweeps share one definition of an
  active participant, core's own; the missing-row sweep's start-date test now
  matches core's (`timestart < now`).
- **`reconcile_batch_size` defaults to 1000** (was 500). On the same table,
  1000 to 2000 rows per query is the cheapest per row. Sites still on 500 move
  to 1000 on upgrade; any other value is kept.
- **The performance settings say what each one does and when to change it**,
  in a sentence or two each, and the retention ones say it does not reduce
  the reconciliation load.

### Added
- **Pending rows that lost their response before the cycle model can be
  dismissed.** Before measurement cycles, a student who saved an
  already-graded submission again erased its response: the row went back to
  pending with its clock running from that save, and the original hand-in time
  is gone from Moodle. The new `cli/dismiss_legacy_pending.php` lists those
  rows (cycle 0, no recorded mark, a live mark older than the hand-in, handed
  in before this site's cycle-model upgrade, or before `--before`) and, with
  `--run`, takes them out of the pending lists, the counts and every median
  without inventing a response time. The ledger keeps the row with the new
  `timedismissed` column; work the student saves afterwards opens a new cycle
  and is tracked as usual. Each run is recorded in the recompute audit log
  (reason `legacy_dismissal`), the column is part of the privacy export, and
  retention prunes a dismissed row by its dismissal date, since it never gets
  a response time.
- **Work handed in again after a mark says so.** When a teacher grades but
  leaves the submission editable, and the student saves it again in the same
  attempt, Moodle asks for it to be graded again ("Graded - resubmitted") and
  the plugin opens a new pending cycle whose clock starts at that save. The
  pending report, the group drill-down and the dashboard's "Grade now" cards
  now tag such rows **Resubmitted**, with the date of the earlier mark in the
  explanation, so a teacher no longer sees work they already graded listed as
  if it had never been answered. The tag also covers pending rows written
  before the cycle model, whose post-grading edit had erased the response:
  there the earlier mark is read from the activity's own grade. Saving the
  grade again, even unchanged, still answers the row; nothing about the
  measurement changes. `get_pending_submissions`, `get_graded_submissions` and
  `get_grader_priority_list` return two new fields, `resubmitted` and
  `previousmarktime`.
- **Reconciliation now records what each tick cost.** One audit row per tick
  (reason `reconcile`), carrying per-sweep rows repaired, milliseconds and
  cursor position, plus `emptyms` — the time spent proving nothing was wrong —
  and whether the time cap cut the tick short, with the names of the sweeps it
  skipped. The row is written on every tick, including the ones that repair
  nothing: on a converged ledger that *is* the task's cost, and until now
  nothing anywhere recorded it. Visible on *Tools → Recompute audit*.

  The skipped list is the operational signal worth watching. Sweep order
  rotates between ticks, so a cap too low for the site shows up as a skipped
  list that is rarely empty — the deferred repairs spread across the nine
  sweeps instead of pinning to the same names every tick.

- **Deleting a large group no longer re-attributes every member inside the
  request.** Up to 50 users are still moved to their current group at once; a
  larger group is handed to the new adhoc task `reattribute_users` in chunks
  of 50. The deletion now works from users rather than ledger rows, up to 20
  000 of them (it used to stop silently at 10 000 rows), and raises a
  debugging notice when it reaches that ceiling.

- **Site benchmarks on the teacher dashboard.** A collapsible section at the
  end of the dashboard shows the site-wide daily series for the last 7, 30 or
  90 days, as an accessible table under a median sparkline: the median, 10th
  and 90th percentile of business hours to feedback, the share graded within
  the SLA goal and the number graded. Only users holding
  `block/feedback_tracker:viewschoolcomparison` at system context (managers by
  default) receive the section and its strings; the `get_school_comparison`
  web service still checks the capability on every call. The data loads when
  the section is opened. The site history is recorded in business hours only,
  so in business-days mode the section says so rather than converting.

- **A group membership change re-dates the student's submissions at once.**
  Joining or leaving a group, or losing a deleted group, can change which
  group override sets a student's open, due and cut-off dates. The group event
  now rewrites the dates of that student's current rows in the same request
  instead of waiting for the reconciler's rule-drift sweep, which on a large
  site could take days to reach a row. Only activities with a group override,
  or rows storing dates other than the activity's own, are read, so on a
  course without group overrides the check is one query; beyond 50 rows the
  work goes to the `reattribute_users` task, which now re-dates the rows it
  moves. One case stays with the sweep: a former member of a deleted group
  whose submissions report under another of their groups, because nothing left
  in the database records the membership.

### Fixed
- **The reconciler no longer walks the whole ledger to find out it has nothing
  to do.** Every sweep ran one statement whose `LIMIT` sat over its own repair
  predicate, so the batch bounded the rows *returned*, not the rows examined.
  Drift is rare by design — the observers repair the common paths — so on a
  converged ledger, the normal state, each sweep returned fewer rows than the
  batch, read that as "pass complete", and reset its cursor to 0 after
  scanning every row in every tracked course. Every tick, for ever. The
  latest-drift statement made it worse with an `OR` between the individual and
  team join conditions, which no index on either PostgreSQL or MariaDB could
  serve past the `assignment` column: for every ledger row it read every
  submission of the activity, a cost quadratic in class size. A DBA reported it
  as a query that never finished.

  Measured on a synthetic 1.07 million-row ledger with 300 tracked courses and
  nothing to repair: the statement took 24.5 s and returned nothing; the same
  probe now takes 8 ms per window. Each sweep walks its driving table in
  windows of `reconcile_batch_size` rows (the setting keeps its name and its
  default; its meaning is now the window), probes only that window, and moves
  its cursor to the end of the window whether or not it held anything. The
  end of a pass is a window shorter than the batch and nothing else — a sweep
  stopped by the time cap keeps its place and resumes next tick. The `OR` in
  the latest-drift and orphan sweeps is two equality joins, one per submission
  mode, each a point lookup on the unique key.

  Behaviour that changes with it: a sweep keeps walking windows until its share
  of the time cap is spent, so on a large site a full pass now takes a few
  ticks instead of one unbounded query, and a single tick can no longer run
  past the cap inside one sweep. Each sweep's share is an equal split of what
  is left of the tick when its turn comes, so a cheap sweep hands its unused
  time on. The audit row records rows `examined` and `windows` walked per
  sweep beside the rows repaired. The window is capped at 10 000 rows whatever
  the setting says, because it becomes a placeholder list in the probe and
  PostgreSQL refuses a statement with more than 65 535 of them. The cursors'
  meaning is unchanged; nothing needs resetting on upgrade.

- **Extensions now reach the stored due date and cut-off.** An extension granted
  in the assignment replaces that student's due date, as the grading table
  shows it, whether the date came from the activity or from an override. It
  also moves an existing cut-off it passes, as mod_assign does when deciding
  whether submissions are still open; where there is no cut-off it creates
  none. The `extension_granted` observer already re-resolved the student's
  rules, but the resolver never read `{assign_user_flags}`, so the ledger kept
  the activity's dates.
- **An override that removes a date now removes it.** In an assignment
  override an empty value means "use the activity's date" and 0 means the date
  was switched off for that student or group. The plugin read both as "use the
  activity's date". Stored rule dates and the per-group activity dates on the
  block now follow mod_assign; on the group card, an override that removed
  dates counts as the group's own override.
- **A student in several overridden groups gets one answer, whichever path
  writes the row.** Each date now comes from the student's own override, then
  from the group override with the lowest sortorder among all of the student's
  groups, then from the activity, one date at a time, as the activity's dates
  on the course page are resolved. Before, the result depended on the group the
  ledger row was attributed to and on which write path ran last, and deleting a
  group override fell back to the activity instead of the student's remaining
  groups.
- **The rule sweep no longer re-dispatches every overridden or extended
  submission on every pass.** It compared the stored dates against the
  activity's own due date and the raw extension, neither of which the writer
  stored, so each such row was "repaired" to the same value on every tick. It
  now checks the open date, due date and cut-off of each current cycle with the
  same query the ledger stores them with, which also catches override edits,
  reorderings and group-membership changes that fired no event. Rows stored
  under the old rules are corrected over the sweep's next pass.
- **The grade-divergence sweep no longer re-dispatches marked submissions on
  grade type "None".** Core stores -1 for a grading on an activity with no
  grade. The sweep read that as "no mark", while the writer, like core, only
  checks that a later grade row exists.
- **Paused periods no longer count Friday as weekend and Sunday as a working
  day.** The paused-days aggregator numbered weekdays from Sunday, while the
  weekend setting numbers them from Monday. With the default Saturday + Sunday
  weekend, the paused-periods callout, the dashboard events line and the
  report's academic-days strip marked every Friday as a weekend day and every
  Sunday as an academic one. Counts over whole weeks looked right, which hid it.
- **An "&" in a name or a note no longer shows as "&amp;".** Calendar notes on
  upcoming pauses and sub-day events, course and group names, group titles
  built from custom fields, the dashboard greeting and the bulk block-removal
  list were HTML-escaped before reaching surfaces that escape text themselves.
  They are now sent as plain text, with tags still stripped, and escaped once
  where they are displayed.
- **A group title field with a link configured no longer breaks the block.**
  Titles and subtitles built from group custom fields used the field's display
  HTML. For a text field with a link that HTML is a link element, which made
  the web service reject the whole response, so no card loaded. Titles are now
  plain text for every field type: text, select, textarea, checkbox, date and
  number.
- **Names are filtered in the reader's language and people follow the site's
  full-name format.** The dashboard and its insight cards, the Grade Now list,
  the report's class filter, its pending and graded tables, the group
  drilldown and the activity list on the block's group cards sent course,
  group and activity names exactly as stored, so a multi-language name showed
  every language's markup and other text filters never ran. Student names were
  always "first last" whatever *Full name format* said; the report's search
  now matches the name in that same format. The cached dashboard, insights and
  block payload are kept per language, so switching language no longer shows
  the previous language's names for up to fifteen minutes.
- **Calendar editor messages are shown as text.** An error raised while saving
  a day, a pause window or business hours was inserted into the page as HTML.
  It is now escaped. Rejected CSV rows from a bulk import are listed one per
  line, with a translated line label.
- **Default-on settings are on before the settings page is first saved.**
  `exclude_grader_submissions` and `removal_grace_follow_recyclebin` default to
  on, but a value never saved read as off. After a web upgrade, until an admin
  saved the new settings, submissions by teachers and role-switched
  administrators were recorded, and a removed block's history was kept only for
  the plugin's own grace period even when the recycle bin keeps the course
  longer.

- **A teacher allocated to mark submissions is covered by privacy requests.**
  The allocated marker's user id was declared as personal data but never
  found, exported or erased for that teacher. An export now lists the
  teacher's current allocations (activity, attempt, allocation time and
  turnaround, without the student's identity); an erasure clears the teacher's
  id from those submissions and keeps the students' rows. `timeallocmarker` is
  declared too.

- **The teacher dashboard's course sparkline no longer shows trends from
  groups the teacher cannot see.** The courses table was already filtered to
  the teacher's groups, but the sparkline beside it averaged every group of
  the course, which in separate groups mode showed other groups' turnaround.

- **Removing the block again inside the grace period restarts the grace
  period.** If the block was removed, put back and removed again, the pending
  discard kept the first removal's deadline and could delete the course's
  history early.

- **The data reset no longer claims to delete the audit log.** It never did,
  and it should not: the reset records itself there. "Rows removed" no longer
  lists audit rows, and the warning no longer says pause or audit rows are
  deleted.

- **A cron process no longer carries one task's decisions into the next.**
  Moodle's cron runs many tasks in one process, and the plugin's memos
  (whether a course has the block, a user's group, the calendar lookups) lived
  as long as the process, so a block added or removed between two tasks could
  be missed. Every task now starts with fresh memos.

- **The queue drain counts only what it dispatched.** A recompute core refused
  to queue was reported as dispatched, whether one was already pending or, on
  4.5, 5.0, 5.1.0 to 5.1.4 and 5.2.0, a retry-exhausted task was still
  blocking it. Refusals are counted apart (`refused`) and traced.

- **Moving a pause window to another course or group recalculates the one it
  left.** Only the new scope was recalculated, so the old one kept counting
  the pause.

- **Re-importing a calendar day by CSV clears an old partial-day window,** as
  the editor form already did, and **removing a day that has no entry no
  longer recalculates every course on the site.**

- **Closed days and full-day optional days count as paused whatever the recess
  setting,** as the time engine counts them, and **the upcoming-pause notice
  no longer announces holidays or recesses that count as working time.**

- **An optional event with a start and end time is announced at the right time
  on a daylight-saving day.** Its minutes are read as wall-clock time, as
  business hours are.

- **Calendar edits are recorded in the recompute audit log and purge the
  per-day calendar and pause-window caches.** A day save, a CSV import, a
  business-hours save and a pause-window save or deletion each leave one row
  (`calendar_save`, `bulk_import`, `business_hours_save` or `pause_save`) with
  the rollups re-queued and the user; the reasons existed but nothing wrote
  them. The caches are keyed by the calendar version and have no expiry, so
  each edit used to leave every entry in the store.

- **A course's ungrouped card is no longer part of its own peer benchmark.**
  Group id 0 is the ungrouped card of every course, so excluding by group id
  alone left the course's own row in the "Department" and "Top 10%" pool; the
  exclusion now uses the (course, group) pair. **The hours benchmarks need
  their own minimum sample:** a card with pending work and nothing graded has
  a score but no median wait, so one group's median could be published as the
  department norm.

- **Pending report, business-days mode.** A submission not yet given its
  business-day count took its Status badge from a different measure than the
  distribution bar and the band filter, so the badge could name another band.
  Both use the same estimate, and sorting by Status follows the day count.

- **The dashboard's "gentle watch" insight counts in business days when the
  display unit is business days,** and **a tie for the "bright spot" goes to
  the group with more graded submissions,** as documented.

- **Every trend sparkline has a localised accessible name,** instead of the
  English "30-day trend" over a 14-day series, and **the score simulator's
  gauge has one too** (the page never sent the label, and the string held a
  mistyped placeholder).

- **The score simulator starts from the weights the groups are scored with.**
  A weight stored as 0 came back as its default in the simulator while the
  real score dropped that term.

- **Numbers and dates on the JavaScript pages follow the user's language and
  time zone.** Fractional hours and days use the language's decimal separator,
  and the block's last-sync stamp, the report's dates and the activity
  timeline use the language pack's locale and the user's Moodle time zone
  instead of a fixed DD/MM/YYYY or the browser's zone.

- **The dashboard's Effective column sorts on the figure it shows,** and **the
  block's Perceived tile no longer changes with the display unit** (an item
  waiting 0 hours no longer reads "1d").

- **The pending report's loading state reaches screen readers,** and **every
  form on the calendar editor has unique element ids** (ten forms shared
  `id_submitbutton`, `id_note` and the business-hours fields). The bulk
  removal table's checkbox column has its own hidden "Select" header instead
  of a repeated "Course" in Bootstrap 4's deprecated `sr-only`.

- **Text fixed in English is translatable:** the fallback "Group #N" name, the
  CSV import format hint, and the day and hour suffixes on the drilldown.

- **Bulk-removal page views in the site log link to that page** instead of the
  plugin settings, the "No submissions" badge has colours again, and the
  queue-to-turnaround chip and the bulk-removal count use the plugin's
  monospace font.

- **Team submission events no longer run one group query per participant,**
  and **`cli/recompute_one.php` requires `--courseid`;** both recompute
  scripts report a rollup they could not recompute because another process
  held its lock, and exit with status 1.

- **Cutoff settings saved out of order are repaired on upgrade.** A
  `score_thresholds_band`, `bucket_thresholds_eff` or `bucket_thresholds_days`
  value stored before the settings page validated it (for example score bands
  saved as `70,90,40`) kept every score or submission in the wrong band. The
  2026092500 upgrade step resets such a value to its shipped default, starts a
  new calendar version and queues every rollup for a recompute.

- **The group drill-down's status badge shows the band's name** in the user's
  language instead of its internal slug.

- **Courses tied on pending count on the teacher dashboard are ordered by the
  name the user reads,** after multilang filtering, rather than by the stored
  name.

- **The score simulator's sliders use the language's decimal separator**
  ("0,40" in Portuguese), matching the total beside them.

- **`js/vendor/README.md` no longer claims the bundle hash is in
  `thirdpartylibs.xml` when it was not;** both now carry it.

### Changed
- **The academic-time engine no longer runs inside the reconciler's tick.** The
  allocation sweep called `stamp_allocation_for_user()` inline, which invokes
  the engine once per ledger row of each (activity, student) pair — inside a
  cap shared by every sweep, on the sweep sitting last in the registry. It now
  dispatches an adhoc `stamp_allocations` task instead.

  The discovery instant travels in the payload rather than being read from the
  clock in the worker, so what gets recorded is byte-identical to the inline
  version: `reconciled` already declares the value as accurate only to the sweep
  period, and reading `time()` on the worker would fold in however far behind
  cron happens to be running.

  Descriptors are also deduplicated per (activity, student). The stamp already
  walks every row of that pair, so a student with several unstamped attempts
  used to cost one full pass per row.
- **The reconciler's sweeps rotate, so the tail stops starving.** The time cap
  is tested *between* sweeps and the order was fixed, so on a site whose ticks
  run out of budget the sweeps at the end of the registry were never reached —
  the rule and allocation ones, meaning due-date drift and marker turnaround
  stopped being repaired entirely, with nothing anywhere saying so.

  Each tick now resumes after the last sweep that actually ran. The marker is
  the sweep's key, never an index: an index re-points on its own the moment the
  registry changes. Rotation is a no-op on any tick that reaches every sweep,
  so it only does anything once the cap bites. The order a tick used is recorded
  in its audit row, and the `skipped` list is sliced from that order rather than
  from the registry.
- **Rows for departed participants are cleared in hours, not months.** The sweep
  that removes ledger rows for people who are no longer active participants
  visited exactly one course per tick, behind a cursor that was an *index* into
  the list of tracked courses. A full pass therefore took one tick per course —
  at the two-hourly schedule, a site with 1,000 tracked courses needed about
  83 days — and the index was unstable: adding the block to a course with a
  lower id shifted every later position and silently skipped a course for a
  whole cycle.

  The cursor is now a course id, which survives the list changing under it, and
  the sweep visits up to 25 courses per tick within its time budget. A course
  with a large backlog sheds what fits and the rest on the next pass, rather
  than holding the cursor and starving the courses behind it.

  The upgrade unsets the old cursor, because reading the old index as a course
  id would skip every course at or below it for the first pass.
- **The reconciler's sweeps are indexed.** New `idx_course_id` on
  `block_feedback_tracker_sub (courseid, id)`. The keyset sweeps page on
  `id > :cursor` while filtering on `courseid`, and no existing index led with
  `id` — the primary key does, but the course filter was then a residual over
  whatever the range scan produced. On a ledger where the tracked courses are a
  small slice of the table, that residual was most of the work.

  It does not help the two row-creating sweeps: those drive from
  `{assign_submission}`, which carries no course column on either supported
  core version.
- **Reconciliation has its own time cap.** `reconcile_time_cap_seconds` replaces
  the reconciler's use of `drain_time_cap_seconds`. One number was sizing two
  very different tasks: the drain inserts a couple of hundred rows into
  `{task_adhoc}`, while reconciliation runs nine diffs against the assignment
  tables. The cap is tested between sweeps, so a value too low for the site
  means some sweeps are deferred on every tick — a loss of repair throughput,
  not a slowdown. The rotation entry above keeps that loss spread across the
  nine sweeps rather than pinned to the tail of the order.

  The upgrade seeds the new setting from the old one's stored value, so a site
  that had raised the drain cap keeps the behaviour it had. Sites that never
  touched it read the same 50 either way. `drain_time_cap_seconds` continues to
  govern the drain, pending and backfill tasks.

- **A grade entered straight into the gradebook now counts as a response.**
  Until now the plugin only ever looked inside the activity, so a teacher who
  graded in the grader report, the single view or an import was invisible to
  it: the submission stayed in the pending count for ever, and nothing could
  clear it. The student, meanwhile, was looking at their mark — mod_assign's
  own student page reads the gradebook, not `{assign_grades}`.

  The rule is **the earliest response wins, and it is never withdrawn**. A
  cycle closes on whichever came first, the mark in the activity or the grade
  in the gradebook, and a later deletion does not re-open it: the feedback did
  reach the student at that time, and a figure that can be retro-edited by a
  later administrative act is not a fact. The activity keeps sole authority
  over re-opening — clearing a mark there still means "not answered yet",
  unchanged.

  Three boundaries are deliberate. **The instant comes from `overridden`, never
  from `timemodified`**: core sets `overridden` when a human grades outside the
  activity and suppresses it for a mass rescale, while a course regrade, a
  calculated-item recompute and 5.2's penalty manager all move `timemodified`
  without anybody grading — keying on the wrong column would have dated every
  response to whenever an admin last touched the gradebook. **A hidden grade is
  not a response**, which is the same reasoning the marking-workflow branch
  already applies to an unreleased mark, applied to the gradebook's own gate.
  And **the allocated marker's own turnaround is not closed by it**: a grade
  typed into the gradebook is frequently a coordinator's act, and crediting it
  would measure the wrong person on a figure that carries their name.

  `\core\event\user_graded` is now observed, exiting early when the activity
  owns the cycle — either it is already answered, or `{assign_grades}` carries a
  mark that postdates the hand-in, which means `submission_graded` is about to
  fire. Testing only for an answered cycle would have missed the ordinary path
  entirely: core writes the grade, pushes to the gradebook, and only then
  triggers its own event, so the row is still open when this one arrives. Its twin
  `grade_deleted` is **not** registered: under earliest-wins it has nothing to
  do, and it fires unreliably besides. A reconciler sweep covers what no event
  reaches — flipping a grade to overridden fires nothing at all, and neither
  does a re-grade to the same value.

- **The hidden-grade disclosure is now actionable, documented and tested.** The
  one case the gradebook work deliberately leaves unrepaired — a mark made
  inside the assignment stops the clock even while the gradebook hides the
  grade — is compensated entirely by telling the teacher, so that telling has
  to land. The tag now says the grade needs releasing and how to release it,
  rather than explaining the measurement to somebody auditing it; the README
  gains a "What counts as a response" section, because the plugin's own
  user-facing documentation said nothing about the gradebook at all; and a test
  asserts the flag reaches the pending report for exactly that case. Its
  absence mattered: the row carries no `overridden` stamp, because mod_assign
  pushes its mark through `grade_update()`, which never sets that column — so a
  detection keyed on it would have missed precisely the case the tag exists for,
  with nothing to catch the mistake.

- **Two per-row disclosures on the pending report.** A row answered from the
  gradebook says so, because the activity's grading screen shows nothing that
  explains it. And a row whose grade the gradebook is hiding says so too: that
  one is disclosure rather than repair — a mark made inside the activity still
  closes the response time even while hidden, which is long-standing behaviour,
  and the row now states it instead of letting a closed clock imply the student
  received something they cannot see.

- **Code comments describe the code again.** Every comment was checked against
  the code it annotates and rewritten to Moodle's comment guidance: claims that
  had drifted from the code were corrected, notes about the development
  environment and planning history were removed, and a rationale repeated in
  several places now lives once, at the code that implements it. No code
  changed; the AMD build is regenerated because its source maps carry the
  comment text.

- **The block, the dashboard and the report pages use the theme's colours and
  follow Moodle's dark mode.** Surfaces, text, borders and focus rings read
  the theme's Bootstrap tokens (the `--bs-*` set on 5.1 and later, the
  Bootstrap 4 names on 4.5), so a site's brand colour reaches the focus rings
  and a dark colour mode no longer shows light slabs. The band, plum and sand
  colours keep their light values and gain dark ones, and the JavaScript draws
  gauges, rings, peer bars and sparklines from those tokens instead of fixed
  light-mode colours. Every text colour keeps at least 4.5:1 on its surface in
  both modes, which darkened muted text and the "no data" band slightly
  (`#5f6b7f`), the "watch" insight tone (`#8a6420`) and the retry button
  (`#c2410c`); draft badges and stat-tile labels no longer fade their text
  with opacity.

- **The rollup no longer stores a next and last pause, and the upgrade
  recomputes every rollup.** The five `nextpause_*` and `lastpause_*` columns
  were written on every recompute and read by nothing; the upgrade drops them.
  It also queues every (course, group) for recompute, because `unallocated`
  and `overgoal_days` changed meaning in this version; `drain_queue` rebuilds
  them with no CLI run needed.

- **`unallocated` counts only activities that allocate markers.** On an
  activity without marking allocation every pending row read as unallocated,
  so the figure equalled `pending`. It now counts pending work in activities
  with marking allocation on, and is null when none of the pending work
  belongs to one, as the column always documented.

- **The business-days over-goal count uses the SLA goal in days.**
  `overgoal_days` was bounded by the first business-days bucket threshold
  while the day compliance figure used `sla_goal_days`; the hour pair has
  always used `sla_goal_hours` for both. The pending report's business-days
  bands use the same pair, so the block and the report still agree.

- **The score-band and wait-time bucket thresholds are checked on save.** Each
  setting must hold exactly three numbers in the order its bands are read:
  decreasing and within 0-100 for the score bands, increasing and not negative
  for the effective-hours and business-days buckets, with no two equal. A
  value typed out of order used to be saved and silently misclassified every
  score or submission on the site. Stored values are read as before and
  checked the next time the settings page is saved; the descriptions now state
  the expected order.

- **Two setting descriptions say what the code does.** The reconciliation
  batch size is capped at 10000, and the retention window also prunes the
  daily site and trend tables, which limits how far back the school comparison
  reaches.

- **The academic calendar web service rejects date ranges longer than 366 days
  and values that are not real dates.** The limit was declared but not
  enforced.

- **The dashboard and the pending report compute their hero figures in one
  shared module** (`amd/src/lib/aggregate.js`), so the two cannot drift apart.

- **CI runs on pushes to `main` and `MOODLE_*_STABLE`, on pull requests and on
  manual dispatch,** and a newer push supersedes a running pull-request run,
  never one on `main`.

- **Preact 10.29.8.** The vendored bundle moves from Preact 10.29.2 to 10.29.8
  (htm stays 3.1.1) and is now `js/vendor/bft-vendor-10.29.8-3.1.1.min.js`.
  The releases in between are bug and performance fixes; the only ones this
  plugin reaches are the faster child diff and hooks (preactjs/preact #5115,
  #5116, #5182). The two Preact files come from the npm release tarballs,
  checked against the registry's integrity values and their jsDelivr copies,
  and `js/vendor/README.md` and `thirdpartylibs.xml` record every SHA-384.

- **One class names the vendored bundle.** `local\output\vendor_bundle` holds
  the file name and loads the bundle for the block and every page, so the next
  update is a one-line change. A unit test fails when another PHP file spells
  the name, the named file is missing, a second bundle is left in `js/vendor`,
  or `thirdpartylibs.xml` or the README disagree; a Behat smoke test opens
  every page that loads the bundle and fails when one renders no interface.

- **Dimmed and disabled controls keep readable text.** The busy retry and
  refresh buttons, disabled load-more and pagination buttons, switched-off
  simulator sliders and terms, and the distribution bar's unselected segments
  now use a colour pair of their own instead of fading with opacity, which had
  taken labels below 4.5:1. The drill-down's sort arrow has its own 3:1 pair
  and background. A stylesheet test now refuses opacity on text and dimmed
  states without their own colours.

- The `reattribute_users` task is now named "re-attribute and re-date ledger
  rows after a group change".

### Added
- **Three lifecycle events are now observed**, closing gaps where a ledger row
  stops describing reality without any of its own values changing — the shape
  no reconciler sweep can detect, because it compares values.

  *Unenrolment* and *account deletion* now drop the affected rows in the
  request that caused them. The reconciler already did this, but it walks one
  course per tick on a two-hourly task, so on a site with many tracked courses
  a departed student stayed in pending counts and the grader priority list for
  days. Whether an unenrolment was the user's last in that course is read from
  core's own answer in the event payload rather than re-derived: deriving it
  with `get_enrolled_sql()` materialises the whole enrolled set to settle a
  one-row question, once per event, and a bulk unenrolment fires one event per
  student. Deletion across all courses is backed by a new index on `userid` —
  no existing index led with it, so both deletions would otherwise have been
  full table scans on exactly the bulk paths that matter.

  *An assign's settings save* re-derives the activity's measured rows.
  `markingworkflow`, `markingallocation` and `teamsubmission` change what
  already-stored rows **mean** — with marking workflow on, the response lands
  when the mark is released rather than when it is entered — and nothing could
  see that: the divergence sweep keys on the mark, the rule sweep keys on
  dates, and both find the stored rows perfectly consistent with a definition
  that no longer applies. Rather than diff against a snapshot the ledger does
  not keep, every affected row is re-derived from live state, dispatched as
  background chunks so a cohort-sized recompute never runs inside the
  teacher's request. Team work is dispatched once per group rather than once
  per member, because each dispatch already fans out to the whole group.

  Not registered at the time: `\core\event\user_graded` and
  `\core\event\grade_deleted`, because reading the gradebook as a grading
  source is a change to the measurement model rather than an observer, and was
  left as its own decision. **That decision was since taken** — see the
  gradebook entry under Changed above, which registers `user_graded` (and
  still refuses `grade_deleted`, for a different reason).

### Fixed
- **The reconciler no longer resurrects the rows it just deleted.** Two of its
  sweeps were fighting each other on every tick, indefinitely: the
  departed-participant sweep deletes ledger rows for anyone who is no longer an
  active participant, and the missing-row sweep — which runs *first* on each
  tick and reads `{assign_submission}` directly — had no enrolment or
  account-status predicate at all, so it rebuilt exactly those rows on the tick
  that followed. An unenrolled student therefore reappeared in pending counts
  and in the grader priority list for ever, and each round trip cost a backfill
  dispatch plus a rollup recompute.

  The missing-row sweep now restricts to active participants with the same
  definition the departed-participant sweep uses (`get_enrolled_sql($context,
  '', 0, true)`): a deleted account, a suspended enrolment, a suspended
  enrolment method, or an enrolment outside its start/end window all
  disqualify. The predicate is written out inline rather than reusing
  `get_enrolled_sql()`, which is course-scoped, because this sweep runs across
  every processable course in one query.

  One tick could never have shown this — within a single run the rebuild
  happens before the deletion — which is why the existing test passed while the
  behaviour was wrong. The regression test asserts on the *second* tick.

### Removed
- **The tools landing page (`manage.php`) is gone**, and the "Tools" heading on
  the plugin's admin settings page is now the single index of the calendar
  editor, audit log, bulk-removal and reset pages.

  The landing page had no way in. Nothing registered it as an
  `admin_externalpage` and nothing added it to the admin tree, so it was
  reachable only by typing its URL — while the settings page listed the same
  four tools and was linked from the block settings tree like every other
  plugin. Two lists with one reader had already drifted: the settings page also
  offers the score simulator, and the landing page filtered its links by
  capability where the settings page does not need to, being site-config gated
  in its entirety.

  The reset page's cancel and continue links now return to the settings page.
  `tool_page_viewed` keeps accepting the `manage` slug: log rows written before
  this change still carry it, and they resolve to the settings page rather than
  to a dead URL.

- **The unused server-rendered group card.** The block has rendered only its
  JavaScript view since the no-JavaScript fallback became a short message; the
  card, gauge and sparkline renderables and their four templates had no
  caller.

- **Unread fields in the block's web service response:** the 30-day paused-day
  aggregates, the next and last pause fields and `perceived_median_hours`,
  computed on every load and read by no client. This also removes a 30-day
  calendar walk from every uncached block load.

- **Unused JavaScript, strings and styles.** Five components nothing loaded
  (the grade-now panel, hero metric card, pause timeline modal, paused-periods
  callout and segmented filter), the never-loaded `responsiveness` module,
  unused formatter and web service wrapper exports, the strings only they
  used, and the rules for elements that no longer exist. The web services stay
  registered.

- **Two settings that nothing read:** "Wall-clock bucket thresholds" and
  "Enable school comparison overlay" (the school comparison is governed by the
  `viewschoolcomparison` capability alone). The upgrade removes their stored
  values.

- `dirty_queue::remove()`, which only a test called.

- **Unused strings.** 28 page-bundle entries no JavaScript read, and 27
  language strings nothing else used (old card, KPI, hero tooltip and report
  filter labels), are gone from both language packs. The site-benchmarks
  strings were reworded and are sent only to users who can see the section.

### Added
- **A tool to remove the block from many courses at once**, for the
  end-of-period sweep: filter by end date, start date, "no end date set",
  category (including subcategories) and hidden-only, then pick from the
  matches. The three date questions are separate and combinable rather than one
  clever control, because `course.enddate` is optional in Moodle and frequently
  zero — "ended before" alone misses most of an old archive, while silently
  falling back to `startdate` would sweep in courses still running.

  It deliberately does **not** go through `is_processable()`, which excludes
  hidden courses: a hidden course is what an archived one looks like, so the
  tool would have been blind to exactly the courses it exists to clear.

  The removal runs as a background task rather than in the submitting request,
  so a several-hundred-course sweep cannot time out halfway with a partial
  result nobody can see. A course that fails is skipped and counted rather than
  aborting the batch.

  Friction is a requirement here, not a cost. The list reveals 25 rows at a
  time up to 100 and states "showing N of M", so a truncated list can never
  read as a complete one; past 100 it asks for a narrower filter instead of
  paging, because with paging "select all" acquires two meanings and the
  difference between them is a few hundred courses cleared by accident.
  Confirmation is the **number of selected courses**, typed: a number has to be
  read to be typed, unlike a fixed word, and it goes stale the moment the
  selection changes. Selections are re-validated server-side against the
  candidate query, so a hand-edited form cannot reach a course the filter never
  offered.

  Gated by a new `block/feedback_tracker:bulkmanageblocks` capability (manager
  archetype, `RISK_DATALOSS`) — separate from `:managecalendar`, so being able
  to edit term dates never implies being able to clear a semester of courses.
  Because Moodle records nothing at all when a block is deleted, the batch
  writes an audit row naming who ran it and what it touched.

## [1.0.40] - Unreleased

### Added
- **Removing the block from a course now discards that course's history, after
  a grace period.** Previously the data simply stayed, invisible and
  unreachable, for ever. Moodle's own convention is to delete a block's data
  immediately in `instance_delete()`, and that is right for a block that owns
  its data — `block_html` deleting its own files. This block is a *gate*: the
  history belongs to the course, the plugin's tables are not in course backups,
  and removing a block from a course page is a small act with an irreversible
  consequence. So the discard is deferred and re-checked.

  **The run-time re-check is what makes the delay worth having.** Restoring a
  backup into an existing course with "delete the current contents" calls
  `remove_course_contents()`, which runs `blocks_delete_all_for_context()` on
  the course context and takes this block with it before the restore puts it
  back; importing from another course does the same. Without the re-check a
  routine restore would destroy a year of measurement a week later, with
  nothing in any log connecting the two — Moodle triggers **no event at all**
  when a block is deleted, on any supported version.

  The check asks about block presence directly rather than through
  `is_processable()`, which also requires the course to be visible: hiding a
  course is what archiving one looks like, and it must never read as "the block
  is gone".

  Off by default (`removal_cleanup_active`). The grace period defaults to a
  week and optionally follows the site's own recycle-bin retention — the
  longest enabled window wins, so this plugin is never quicker to discard a
  course's history than the site is to discard the course. A recycle bin set to
  never expire is ignored rather than treated as an infinite grace, which would
  silently disable the cleanup altogether. Floor of one hour.

  Because Moodle records nothing when a block is removed, the discard writes an
  audit row naming the course and the number of rows dropped.

## [1.0.39] - Unreleased

### Added
- **A retention policy, so the ledger has a ceiling.** The table had none: a
  closed measurement is never rewritten, a resubmission after grading opens
  another one, and a team submission is carried by every member — so it grew
  for the life of the site with no pruning of any kind. The new
  `prune_ledger` scheduled task discards closed measurements older than
  `retention_days` (default 365, floor 30), plus the daily trend and site-stat
  rows that outlived every surface reading them.

  Two rules make it safe to run unattended:

  - **Only closed measurements are deleted.** A submission still awaiting
    feedback is outstanding work, and its age is precisely the signal this
    plugin exists to surface, so no age threshold can reach it. Pending rows
    leave only when their submission, course or enrolment does.
  - **The reconciler agrees on the boundary.** Its first sweep recreates a
    ledger row for any submission lacking one, so without a shared cutoff it
    would resurrect everything the pruner deleted on the next tick, for ever.
    Both read `retention::cutoff()`, and a mutation test proves the guard is
    load-bearing.

  **Off by default** (`retention_active`), matching `backfill_active`: an
  upgrade must never start deleting a site's history because a new version
  shipped a policy. Turning it on bounds the report's all-time Graded tab —
  an audit surface — to the window, which the setting says in its own
  description.

  A window below 30 days is ignored and falls back to the default: it would
  delete work still inside the 30-day statistical window the score and the
  medians are built from, so the rollup would disagree with its own inputs.

## [1.0.38] - Unreleased

### Fixed
- **The pending count now matches Moodle's own at the boundary.** A grade saved
  in the same clock second as the submission's last change read as *graded*
  here and as *needs grading* in core's counter, whose clause is
  `s.timemodified >= g.timemodified`. Core needs that direction because it
  auto-creates placeholder grade rows carrying the submission's own timestamp;
  the plugin rejects those by grade value instead, but the boundary is now
  identical anyway — a disagreement at the tie would have shown two different
  pending counts for one activity and had the reconciler chasing the gap for
  ever.
- **Group overrides re-resolved the wrong students.** The rule refresh selected
  ledger rows by the ledger's own `groupid`, which is the *reporting*
  attribution — the group a student was last added to, used to bucket the
  dashboard — and has no reason to match the group an override targets. It now
  selects by real membership of the overridden group, and enqueues every
  reporting tuple actually touched rather than one built from the override
  group.
- **`marker_updated` no longer breaks on Moodle 5.2 or later.** 5.2 dropped
  `assign_user_flags.allocatedmarker` in favour of the new
  `assign_allocated_marker` table, and it does fire the event, so reading the
  old column took the observer down with it. 5.02 is a supported branch, so
  this was a live defect, not a forward-compatibility note.

### Added
- **The response interval is split by who owns each part.** A submission that
  waited ten days to be allocated and was then marked in two hours used to
  report a ten-day turnaround against the marker. The ledger now records
  `queuehours` (hand-in to the first allocation — the coordination queue, which
  belongs to whoever runs the allocation) beside `allochours` / `allocdays` /
  `allocbucket` (the current marker's allocation to the grading — the only part
  that is theirs). The student-experience clock that feeds the responsiveness
  score is deliberately unchanged: the student really did wait the whole time,
  and that remains the institution's SLA.
- The marker turnaround is measured from the **current** marker's allocation,
  not the first, so someone who inherits a long-queued submission on day 8 and
  grades it on day 9 is measured at one day rather than nine. mod_assign fires
  no de-allocation event in any supported version, so the reassignment is only
  detectable from the next allocation.
- **A non-measurable interval reports null, never zero.** An allocation stamp
  that lands at or after the grading — which the reconciler produces whenever
  it discovers an allocation after the fact — would otherwise band as
  `excellent`, reading as a flawless turnaround. Those rows are marked
  `allocsource = 'late'` and excluded from the medians.
- Rollup columns `unallocated` (pending work nobody is responsible for yet),
  `median_queue_h`, `median_alloc_h` and `alloc_coverage_pct`, plus the split
  on `get_responsiveness` and on every listed submission row
  (`get_pending_submissions` / `get_graded_submissions`). The report shows the
  per-row split with an explanatory tooltip.
- **User-level overrides and extensions reach the ledger.**
  `user_override_created` / `_updated` / `_deleted` and `extension_granted` are
  now observed: all four move the dates one student is judged against, and none
  is visible in any other signal — the reconciler's rule-drift sweep compares
  against the activity's own dates and `assign_user_flags`, so an
  `assign_overrides` row was invisible to it.
- **An eighth reconciliation sweep discovers silent allocations.** Before
  Moodle 5.2 only the batch "Set allocated marker" operation fires an event;
  quick grading and the grading form write the allocation with no signal at
  all. Those are now found by a periodic diff and stamped
  `allocsource = 'reconciled'` — the moment of *discovery*, not of allocation,
  which is why it stays separable from `observed`: a median built from a mix
  without saying so would understate every turnaround.
- Behat coverage for the three outcomes only a browser can prove: the reported
  resubmission defect (the grading survives in the history *and* a new pending
  item appears), the awaiting-release chip, and a group submission appearing
  against every member. The scenarios pin core's grading form via
  `local_unifiedgrader/enable_assign`, so a sibling plugin that replaces the
  assign grading UI cannot move the field labels underneath them.
- `alloc_coverage_pct` is published **beside** `median_alloc_h`, never alone:
  before Moodle 5.2 only one of mod_assign's three allocation paths fires an
  event, so the sample is partial by construction and the median must not be
  read as if it covered everyone.

## [1.0.37] - Unreleased

### Fixed
- **A student who re-saves an already-graded submission no longer un-grades
  it.** The ledger compared the live `assign_submission.timemodified` against
  the grade time on a single mutable row, so any later save — even one that
  changed nothing — pushed the hand-in time past the grading time, reset
  `timegraded` to null and restarted the clock. The recorded response time was
  destroyed and the submission reappeared as awaiting feedback, while Moodle
  itself kept reporting it as graded. The ledger now keys on a **measurement
  cycle**: work resubmitted after it already carried a mark opens a new cycle
  instead of rewriting the closed one, so the completed turnaround survives in
  the history and the re-look becomes a correctly-pending item whose clock
  starts at the re-save. Removing the timestamp comparison outright was
  considered and rejected — it makes a reopened cycle inherit the old mark and
  be born graded with a fabricated zero-hour turnaround.
- **Group assignments are tracked per member instead of not at all.**
  mod_assign stores a team's work in one `assign_submission` row with
  `userid = 0`; the observer mirrored it verbatim, producing a ledger row the
  rollup counted (it does not join `user`) but every list hid (they all do) —
  a pending item nobody could clear — while the actual group members got no row
  at all. The container row is now refused at the write path (and the existing
  ones removed on upgrade), and team submissions are fanned out to one ledger
  row per member: timing and status from the shared group row, the mark from
  each member's own grade row, tagged with the originating `teamgroupid`.
  A member who never personally saved has no submission row of their own when
  `requireallteammemberssubmit` is on, which is precisely why the per-user
  lookup dropped them; the fan-out reads the group row instead. Members of the
  default group (in none, or more than one, group of the activity's grouping)
  follow the same rule core applies, and are skipped entirely when
  `preventsubmissionnotingroup` bars them from submitting. Both the observers
  and the historical backfill route through it.
- **Superseded attempts stop counting as pending.** The ledger now mirrors
  `assign_submission.latest`, which is the gate core applies to every one of
  its own needs-grading reads, and every pending predicate is filtered on it
  plus `iscurrent` — the rollup's pending set, the stale-row recomputer, the
  report's pending and draft tabs, and the grade-now priority list. Granting
  another attempt fires no event at all, so an ungraded earlier attempt
  previously stayed pending indefinitely with a clock that grew without bound.
  The graded populations deliberately keep **every** cycle: a teacher who
  responded twice generated two genuine response events, so `numgraded30d`
  counts responses rather than distinct students.
- **The dashboard's "current" medians no longer count one attempt twice.**
  `cur_median_eff_h` / `cur_median_raw_h` / `cur_median_eff_days` /
  `cur_median_perc_days` merged the 30-day graded set with the pending set, so
  an attempt whose earlier cycle was graded inside the window while its current
  cycle awaits feedback appeared in both. They are now built from a dedicated
  current-state population, one live observation per attempt.
- **Elapsed-day fallbacks can no longer go negative.** A row written before the
  cycle model could hold `timegraded` earlier than `timesubmitted`, and the
  un-backfilled-day fallback turned that into a negative count that sorted
  straight to the top of the priority list. Clamped at zero, expressed as
  `CASE` rather than `GREATEST` (which core uses nowhere and which SQL Server
  lacks before 2022).
- **Activities with grade type "None" are no longer permanently pending.** They
  can never carry a numeric mark, so the grade-value test never passed. They
  now follow core's needs-grading counter, which clears them on a grade row
  later than the hand-in.
- **Submission events from the online-text and file subplugins no longer read
  the wrong row.** Those events override `objecttable`, so their `objectid` is
  the subplugin row id and the real `assign_submission.id` lives in
  `other['submissionid']`. The observer looked the former up in the latter's
  table: it either found nothing, or found an unrelated row and wrote a ledger
  entry against the wrong student.

### Added
- **Scheduled ledger reconciliation** (`reconcile_ledger`, every two hours,
  `reconcile_active` on by default). Six classes of mod_assign mutation emit
  no usable event and can only be repaired by diffing against the source
  tables: `add_attempt()` inserts a new attempt and flips the previous row's
  `latest` flag in total silence; blind marking makes `gradebook_item_update()`
  return false before doing anything, suppressing the grading event for the
  entire activity until identities are revealed; grading a non-latest attempt
  returns early, before the trigger; a gradebook-side override or lock silences
  it too; `reset_userdata()` bulk-deletes submissions with
  `delete_records_select()`, leaving orphans; and due dates, cut-offs,
  overrides and extensions change with no per-row signal. Seven keyset-paged
  sweeps, each behind its own cursor and bounded per tick, dispatch repairs as
  adhoc tasks — except the two cleanup sweeps (orphaned rows, departed
  participants), which act directly because the repair task re-gates on course
  processability and would skip exactly the courses whose rows most need
  removing. The divergence sweep mirrors the writer's predicate exactly and is
  cycle-scoped, so it converges instead of re-dispatching the same repair every
  tick; both properties are pinned by tests.
- **Event coverage for the mod_assign actions the observer used to miss.**
  `workflow_state_updated` (the marking-workflow release — the only signal
  that a grade became visible to the student, and one core keeps no timestamp
  for), `identities_revealed` (blind marking suppresses `submission_graded`
  outright, so until identities are revealed every grading on the activity is
  invisible and every submission reads as awaiting feedback), `marker_updated`,
  `submission_removed`, `submission_duplicated`, and the
  `assignsubmission_onlinetext` / `assignsubmission_file` `submission_updated`
  twins — without which a student editing an existing submission is invisible
  whenever `submissiondrafts` is on.
- **Allocation timestamps.** `timeallocated` (first allocation, sticky, closes
  the coordination-queue measurement), `timeallocmarker` (the current marker's
  own start, so someone inheriting a long-queued submission is not charged for
  a queue they did not cause), `allocmarkerid` and `allocsource`. mod_assign
  stores no allocation timestamp on any supported version, so the moment is
  only ever knowable when observed — and on 4.5 and 5.1 only the batch "Set
  allocated marker" operation fires an event at all, which is what
  `allocsource` records.
- **"Awaiting release" chip on marked-but-unreleased submissions.** Under
  marking workflow a saved grade is invisible to the student until the state
  reaches *Released*, and releasing needs a capability the marker frequently
  does not hold. The report now flags those rows with an explanatory tooltip so
  the marker can see that an outstanding step exists and that it may not be
  theirs. Reaches the payload as the new `awaitingrelease` field on
  `get_pending_submissions` / `get_graded_submissions` rows.
- New setting **`release_stops_clock`** (default off). When on, the response
  clock for a marking-workflow activity stops at release rather than at
  marking, which is when the feedback actually reaches the student. Default off
  so the upgrade moves no displayed number; turning it on changes historical
  figures on courses that use marking workflow and should be followed by
  `cli/recompute_all.php` and `cli/backfill_trends.php`.
- Ledger columns `cycle`, `timemarked`, `timereleased`, `timeclosed`,
  `islatest`, `iscurrent`, `gradestate` and `teamgroupid`. `timereleased` and
  `timeclosed` are maintained regardless of the setting above, so enabling it
  later needs no re-derivation of what the student actually saw — mod_assign
  persists no release timestamp of its own (`assign_user_flags` has no time
  columns on any supported version), so the moment is only ever knowable when
  observed.
- `docs/moodle-52-multimarking.md`: what Moodle 5.2 changed about marker
  allocation and multi-marking, and why it was a live defect rather than
  future work.
- `docs/assign-scenario-map.md` and `docs/assign-marking-allocation.md`: the
  full audit of mod_assign's submission and grading lifecycle against this
  plugin, covering the scenarios not yet addressed here (team fan-out, blind
  marking, gradebook-side changes, course reset, the marking-allocation clock)
  and the design for each.

## [1.0.36] - Unreleased

### Fixed
- **Sortable tables are reachable by keyboard.** The group drill-down's column
  headers attached their click listener to the `<th>` itself, so sorting could
  only be triggered with a mouse and the active column was never announced —
  a WCAG 2.1.1 failure. Headers now carry a real `<button>`, and `aria-sort`
  moves onto the `<th>` where it is valid. The pending report had the same
  `aria-sort` misplacement (on the button rather than the header) and is
  corrected to match.
- **Assistive technology is no longer read English on a pt_br site.** The score
  gauge and the sparkline hard-coded their `aria-label`; both now come from
  lang strings. The sparkline's label also said "30-day trend" while the card
  renders 14 days, so screen-reader users were told the wrong window.
- **The hero info dot is focusable.** It was a bare `<span>`, so its
  explanatory tooltip could not be reached without a mouse and its
  `aria-label` was ignored on a generic element. It is a `<button>` now.
- **Draft badges are visible.** `.badge-draft` had no rule at all, so under
  Bootstrap 5 a bare `.badge` set white text with no background and the label
  rendered white-on-white.
- **Sorting no longer inverts after a double init.** `pending_table.js` gained
  the idempotency guard every other entrypoint already had; without it a
  second init bound a second listener per header, so one click sorted
  ascending then immediately re-sorted descending.

## [1.0.31] - Unreleased

### Added
- **Business-days band thresholds** — when the display unit is business days,
  the excellent / good / up-next / priority bands classify by elapsed
  business days against a new comma-separated setting (default `2,5,10`,
  inclusive bounds: up to 2 days excellent, 3-5 good, 6-10 up-next, over 10
  priority) instead of the hour thresholds. The ruler is applied everywhere
  bands appear: report badges, distribution counts and band filters
  (pending and graded), the grade-now list, the block's pending tiles, the
  dashboard counts and the academic-days strip colours. The responsiveness
  score keeps using effective hours and is unaffected. New per-submission
  `effectivedays` column maintained alongside `effectivehours` (backfilled
  on upgrade) and day-ruler `critical_days`/`overgoal_days` rollup twins.
- The academic-days strip tooltip now shows each day's median in the
  configured unit (elapsed business days in days mode, effective hours
  otherwise) via a new per-day `eff_days` field on `get_academic_days`.

### Changed
- The report's "paused" row tag is now a compact info icon: hover keeps the
  explanation tooltip and clicking pins it, so touch users can read it too.
- Teacher-facing copy that names the working-time unit (the hero Effective
  tooltip, score note/tooltip, dashboard/report intro, the "business-time
  only" chip and the paused-row tip) now says "business days" / "dias úteis"
  when the business-days display unit is active, resolved server-side in the
  i18n bundle so the React layer is unchanged. Settings descriptions, the
  simulator and the SLA-goal tooltip stay in hours (they configure or report
  genuinely hour-based values).

## [1.0.30] - Unreleased

### Changed
- **Pending report loads like the dashboard** — the page ships its first byte
  immediately and every section loads asynchronously after first paint: the
  submissions table (skeleton while in flight) in parallel with the hero
  scopes and class filter, then drafts, then the academic-days strip. The
  page previously blocked on two submissions queries plus the full per-group
  responsiveness payload (trend series, peer stats, activity schedules)
  before sending any HTML.

### Added
- New `get_report_scopes` web service: per-group hero scopes + class-filter
  list read straight from the materialised rollup — the report no longer
  builds the full responsiveness payload at all.

## [1.0.29] - Unreleased

### Added
- **Wait-time display unit** — a site setting to show wait times in business
  **hours** (default) or **business days**. Business days are counted from
  the submission and grading *dates* (time of day is ignored): business days
  skip weekends, holidays and recesses per the platform calendar, while the
  perceived wait counts every calendar day — submitted Friday evening and
  graded Monday reads 1 business day / 3 calendar days. Applies everywhere:
  the in-course block, the dashboard hero and courses table, the grade-now
  priority cards, and the pending/graded report. The responsiveness score
  still uses effective hours and is unaffected. Toggling the unit is
  display-only (both representations are always computed); run
  `cli/recompute_all.php` once after upgrading to backfill the new day
  medians (or let the drain queue catch up).
- New per-submission `effective_days` / `perceived_days` fields on
  `get_pending_submissions`, `get_graded_submissions` and
  `get_grader_priority_list`; new `cur_median_eff_days` /
  `cur_median_perc_days` rollup columns surfaced via `get_responsiveness`
  and `get_dashboard`.
- **Show peer comparison** site setting to hide or show the peer-context panel
  (You / Department / Top 10%) on the in-course group cards.

### Fixed
- The grade-now priority card estimated the perceived wait from effective
  hours with a fudge factor, drifting far from the report's figure on long
  waits. It now shows the real elapsed calendar days.
- The no-JS responsiveness card's "show perceived time" and "show paused-today
  indicator" toggles could not be switched off — the stored `'0'` was read as
  on (PHP treats the string `'0'` as falsy). They now honour an explicit off.

## [1.0.27] - Unreleased

### Added
- **Graded view** on the pending-grading report — switch between work that's
  still waiting and work already graded, sharing one unified browser. New
  `get_graded_submissions` web service.
- **Academic-days strip** on the report — a 30-day view of on-goal, paused and
  other academic days. New `get_academic_days` web service.
- Drafts (not-yet-submitted work) are surfaced read-only on the report,
  clearly separated from work awaiting feedback.

### Changed
- The report reuses the dashboard hero (Score / Effective / SLA / Trend) for a
  consistent look, with an action column and a collapse toggle.
- `get_pending_submissions` gained pagination, sorting and a status filter.
- Brazilian Portuguese language pack brought to full key parity with English.
- Standardised all in-code comments to English (user-facing strings
  unaffected).

### Removed
- Dropped an unused legacy dashboard-greeting fallback.

## [1.0.25] - 2026-06-08

### Added
- Per-group **assignment open/close schedule** in the block: each course
  assignment shows its effective open/close dates per group and a four-state
  action chip (done / create rule / override rule / no rule), gated on the
  manage-overrides capability and deep-linking to the group overrides page.
- `get_responsiveness` now returns each group's activities.

### Changed
- The activity timeline bar shows before / running / closed phases; the stat
  row reflows gracefully on narrow blocks instead of overflowing.

## [1.0.24] - 2026-06-05

### Added
- `get_responsiveness` gained pagination (`limit` / `offset`) and sorting,
  with skeleton loading states and a "load more" control in the block.
- Settings to compose the group-card title and subtitle from custom group
  fields.

### Changed
- In-course block overhaul: collapsible group cards, accessibility and
  typography improvements (WCAG AA contrast, focus rings, larger touch
  targets), a footer with last-sync time and a cache note, and a smarter
  priority sort.
- The pending tiles (Waiting / Attention / Priority) now partition the whole
  backlog exactly; the score is unchanged.
- 14-day sparkline window; the score breakdown moved out of the block (the
  simulator covers it); comparison is score-only.

## [1.0.23] - 2026-06-04

### Added
- Optional **teacher access to the score simulator** (admin master switch,
  default off).

### Changed
- The score's **trend** term now compares this week against last week (rolling
  7-day windows); compliance, median, counts and the 30-day sparkline stay
  monthly. The formula itself is unchanged.

### Fixed
- The collapsed dashboard hero no longer overflows on intermediate widths, and
  the sort control is now translatable.

## [1.0.21] - 2026-06-03

### Changed
- Dashboard polish: the effective / perceived / trend mini-stats move into the
  hero copy column; a responsive courses table with mobile reflow; a scoped
  typography and accessibility token scale.
- Block effective / perceived KPIs now use backlog-aware "current" medians,
  matching the dashboard; the score stays graded-only.

## [1.0.20] - 2026-06-02

### Added
- Interactive **Academic Responsiveness Score simulator** (admin sandbox) —
  tune the five weights and a group scenario and watch the score, band and
  per-term breakdown update live. Nothing is saved.

## [1.0.19] - 2026-06-02

### Fixed
- Unified every surface on a single **"speed" model** for trend (faster =
  better, green ▲; slower = red ▼), correcting inverted arrows and an inverted
  sparkline.
- Hero effective / perceived times now include currently-pending work, so the
  backlog shows through (the score stays graded-only).
- The dashboard's global trend and SLA now populate (the service was omitting
  fields the view expected).

## [1.0.18] - 2026-05-31

### Fixed
- The teacher dashboard rendered an empty shell because a web-service call
  resolved a jQuery promise with no native `.finally()`. Every WS call now
  returns a native Promise. (Supersedes 1.0.17, whose rebuilt bundle was never
  regenerated.)

## [1.0.16] - 2026-05-31

### Added
- `cli/recompute_all.php` to refresh stored rollups in place after a
  scoring-rule change.

### Changed
- Teacher dashboard access scope made correct and configurable: the "admins
  see all" setting now works; non-admins are scoped to active
  teacher-or-higher enrolments.
- The dashboard loads asynchronously (ships a shell, fetches on mount) instead
  of running a large query batch before the page renders.
- Groups with no submitted work now score as a neutral "no data" instead of a
  misleading 100, and are excluded from averages, insights and peer stats.

### Fixed
- Priority cards deep-link to the single-student grader; course titles link to
  the pending report.

## [1.0.14] – [1.0.15] - 2026-05-30

### Fixed
- Continuous-integration hardening: resolved PHP CodeSniffer violations and a
  PHPUnit ordering flake; temporarily disabled Behat pending a CI image fix.

## [1.0.13] - 2026-05-30

### Fixed
- Trend backfill now covers every group (a multi-group course previously
  collapsed to one group per course).
- Clamp the 30-day trend percentage so a near-zero prior window can't overflow
  the stored column.

## [1.0.12] - 2026-05-29

### Changed
- Only **submitted** work counts toward pending counts, response time, score,
  compliance and trend. Draft / new / reopened attempts are awaiting the
  student, so they no longer inflate the metrics.

### Added
- Drafts are surfaced read-only and de-emphasised on the report and drilldown,
  never reaching the block or dashboard counts.

## [1.0.11] - 2026-05-27

### Fixed
- `PausedCallout` event segment now includes the event date and time
  alongside the label. Previously it rendered `1 event (⚽ Brasil vs
  França)`; now `1 event (21/05 14:00-16:00 · ⚽ Brasil vs França)`.
  The data was already in the `paused_events_30d` sidecar — only the
  line builder needed updating.
- Block view `PausedNote` now reads from the `paused_events_30d` sidecar
  directly when present, so a named optional event shows on the block
  even when the rollup pause indicators are stale (the drain queue
  may not have caught up since the calendar edit). Format:
  `DD/MM HH:MM-HH:MM: ⚽ label`.

### Added
- Teacher dashboard subline gains a "Recent event" chip (plum tone)
  for the most recent named optional event in the last 30 days,
  site-scope. `pages/teacher_dashboard.php` calls
  `paused_aggregator::for_window(0, ...)` at boot and emits the
  events list as `initial.events`. New i18n keys
  `dashboard_event_chip_label` + `dashboard_event_chip_tooltip`
  (en + pt_br).

## [1.0.10] - 2026-05-27

### Fixed
- `paused_aggregator::ymd_in_pause_span()` triggered PHP 8.x's
  "Deprecated: Implicit conversion from float ... to int loses precision"
  warning when computing the day-string from a YYYYMMDD integer. The
  expression `($ymd / 100) % 100` produced a float intermediate (PHP's
  `/` always returns float) and `% 100` on a float casts implicitly.
  Replaced with `intdiv()` so every intermediate stays an int. Same
  pattern in `pages/calendar_editor.php` minute→HH:MM conversion also
  switched to `intdiv()` for consistency (no functional change — the
  outer `(int)` cast was suppressing the deprecation there).

## [1.0.9] - 2026-05-27

### Phase 4C — Optional days and named sub-day events

#### Added
- `block_feedback_tracker_cday` schema gains nullable `starttime` and
  `endtime` columns (minutes since midnight). Both null = legacy full-day
  rule. When set on a `daytype = 'optional'` row, they describe a sub-day
  event window inside an otherwise active schoolday.
- `calendar::daytype_label()` static helper — single source of truth for
  the localised label of every daytype slug. Reused by
  `calendar_day_form.php` (dropdown options) and
  `pages/calendar_editor.php` (day-list column).
- `day_rule_resolver::for_date()` returns a new `optional_window` key on
  the rule shape when a sub-day event is present
  (`{startmin, endmin, note}`). Full-day optional rows keep their
  `is_active=false` behaviour.
- `academic_time::effective_hours_between()` subtracts the optional
  event window from the day's active intervals and records a synthetic
  pause with `reason='optional'` and the event label as `note`.
- `paused_aggregator::for_window()` grew an `events` sidecar list
  (`[{date, starttime, endtime, label}]`). Sub-day events surface
  there without inflating the `recess` day-bucket; full-day optional
  rows fold into the `recess` bucket as before.
- Payload + WS additive: `paused_events_30d` array on
  `responsiveness_payload::group_payload()` and
  `get_responsiveness::execute_returns()`.
- `save_calendar_day` WS gained nullable `starttime` / `endtime` params
  with range + ordering validation. JS wrapper
  `api.js::saveCalendarDay()` accepts the new options.
- Calendar-day form (`calendar_day_form.php`) reveals HH:MM start/end
  inputs when `daytype = 'optional'`. Both-set-or-both-empty is enforced;
  values round-trip through `get_data()` as minutes-since-midnight.
- PausedNote (block view) and PausedCallout (report page) recognise the
  new `optional` pause reason: PausedNote renders
  `"Paused 16:00-18:00: ⚽ Brasil vs França"`; PausedCallout's body
  line adds `"… · 1 event (⚽ Brasil vs França)"`. Event labels are
  pre-sanitised server-side via `format_string()` so emoji + unicode
  pass through cleanly while HTML is escaped.
- Calendar editor day list: localised label via the new helper +
  `"Optional · 16:00-18:00"` suffix for sub-day rows.
- New tests:
  - `paused_aggregator_test::test_full_day_optional_buckets_as_recess`
  - `paused_aggregator_test::test_sub_day_optional_event_appears_in_events_sidecar`
  - `day_rule_resolver_test::test_sub_day_optional_event_surfaces_window`
  - Extended `get_responsiveness_test` to assert `paused_events_30d`
    shape.

#### Changed
- `pause_reason_for_day()` in `academic_time` now distinguishes
  full-day `optional` from `closed`, returning a dedicated `'optional'`
  reason so PausedNote can render the event-style note rather than
  collapsing into a generic closed chip.
- `next_pause_indicator()` / `last_pause_indicator()` SQL filters
  include `DAYTYPE_OPTIONAL`; sub-day rows resolve their timestamps to
  `ymd + starttime*60` so the indicator points at the actual window.
- Upgrade savepoint at `2026060109` runs `$dbman->add_field()` for both
  new columns and bumps `calver` via `calendar::bump_version()` so
  cached payloads roll over and downstream views pick up the events
  sidecar on first read.

#### Notes
- Schema additions are nullable; existing cday rows continue to work as
  full-day rules with both columns null.
- Sub-day events do NOT bump the `recess` bucket count — they're
  hour-scale, not day-scale. The dedicated `events` sidecar list
  surfaces them for the UI to render alongside the bucket counts.

## [1.0.8] - 2026-05-26

### Phase 4B — Combined hero+insights collapse + user-preference persistence

#### Added
- `block_feedback_tracker_user_preferences()` in `lib.php` declares the
  `block_feedback_tracker_dashboard_collapsed` preference (PARAM_BOOL,
  default `'0'`, permission callback `\core_user::is_current_user`).
  Wires the plugin into Moodle's core
  [user-preferences API](https://moodledev.io/docs/5.2/apis/core/preference)
  so `core_user_update_user_preferences` accepts writes to this key.
- `pages/teacher_dashboard.php` preloads the preference via
  `get_user_preferences()` and emits it as `initial.dashboard_collapsed`
  in the bootstrap JSON — first paint matches the user's saved choice
  with no WS round-trip.
- Privacy provider now implements
  `\core_privacy\local\request\user_preference_provider`. The new
  preference is declared via `$collection->add_user_preference()` in
  `get_metadata()` and surfaces in subject-access exports through
  `export_user_preferences()` with localised "collapsed" / "expanded"
  descriptions. Deletion is handled by Moodle's core privacy
  machinery — no plugin-side delete path needed for preferences
  declared this way.
- New privacy lang strings:
  `privacy:metadata:preference:dashboard_collapsed`,
  `privacy:preference:dashboard_collapsed_collapsed`,
  `privacy:preference:dashboard_collapsed_expanded` (en + pt_br).
- Privacy provider tests gain two coverage methods:
  `test_export_user_preferences_writes_dashboard_collapsed` (verifies
  the value lands in the writer's preferences bucket) and
  `test_export_user_preferences_is_noop_when_unset`.

#### Changed
- The Responsiveness hero and Insights section now collapse together
  under a single toggle. Previously the hero had its own
  collapsed/expanded state and the Insights row was always visible.
- `ResponsivenessModule.js` is now a controlled presentational
  component: parent owns the state, module receives `collapsed` +
  `onToggle` props. Removed the `bft.dashboard.hero.collapsed`
  `localStorage` round-trip.
- `DashboardView` lifts the collapsed state, gates the Insights
  section on `!collapsed`, and persists toggles through
  `core_user/repository::setUserPreference()` with optimistic local
  update + revert-on-failure.

#### Notes
- Existing `localStorage` keys from v1.0.5–1.0.7 are now orphaned but
  harmless — no cleanup needed. Users get the server-side default
  (`expanded`) on first visit after upgrade.
- Permission callback restricts writes to the user's own preference
  row — admins can't toggle the dashboard hero on someone else's
  behalf through the WS.

## [1.0.7] - 2026-05-25

### Phase 4A — Trend-term refinements (Lever 1 + Lever 3)

#### Added
- `responsiveness_calculator::effective_weights($weights, $available)` —
  drops unavailable terms and renormalises the kept weights to sum 1.0.
  Used by both `compute()` and the breakdown panel so the displayed
  weights match what actually contributed to the score.
- `responsiveness_calculator::momentum_pct($courseid, $groupid, $now)` —
  week-over-week % change in median effective hours for one group.
  Returns null when either 7-day window has fewer than 5 grades.
- `insight_momentum_eyebrow` / `insight_momentum_body` lang strings
  (en + pt_br) for the dashboard momentum copy.
- `breakdown_excluded_prefix` lang string (en + pt_br) for the new
  breakdown footnote.
- `.bft-breakdown-footnote` CSS rule.

#### Changed
- `responsiveness_calculator::compute()` — when the rollup has no prior
  30-day window (`trend_pct_30d === null`), the trend term is now
  dropped instead of substituted with 0.5. The other four weights
  renormalise to sum 1.0, so a brand-new course can legitimately
  reach 100. Previously a fresh course's theoretical maximum was 95.
- `components.trend` is now `null` (not `0.5`) when no trend data is
  available — the breakdown panel skips the row and prints a footnote
  explaining the exclusion.
- `responsiveness_card::build_breakdown()` mirrors the JS-side math:
  renormalised weights, excluded-rows footnote.
- `get_insights::pick_most_improved()` — first checks for sharp
  week-over-week momentum (`momentum_pct < -40%` with ≥5 grades each
  week); falls back to the existing 30-day heuristic. The returned
  row carries an optional `momentum` boolean so the JS InsightCard
  can swap eyebrow text + body.
- `DashboardView` consumes the `momentum` flag and renders either the
  "This week's momentum" or "Most improved" copy.

#### Notes
- No schema change, no calver bump — payload shape is additive
  (`momentum` is `VALUE_OPTIONAL`), score component shape is
  unchanged (trend was already declared `NULL_ALLOWED`).
- Momentum recognition is dashboard-only — the score formula never
  sees the week-over-week signal, so the headline number stays
  transparent and explainable.
- Weekly-weighted trend in the score formula (Lever 2) was
  considered for this release; deferred to v1.1.0 so the 95-cap fix
  can soak first before changing what `trend_pct_30d` itself means.

## [1.0.6] - 2026-05-24

### Phase 3F — Web-service completion

#### Added
- New WS `get_audit_log` (`classes/external/get_audit_log.php`) —
  paginated read of `block_feedback_tracker_log` with optional
  `courseid` and `actor` filters. Reuses the existing `viewaudit`
  capability. Returns `{success, total, page, perpage, entries[],
  lastsynced}`.
- Five typed JS write wrappers in `amd/src/lib/api.js`:
  `savePauseWindow`, `deletePauseWindow`, `saveCalendarDay`,
  `bulkImportCalendar`, `saveBusinessHours`. Each mirrors the server's
  `execute_parameters()` signature so callers can pass payload-shaped
  options objects.
- Read wrapper `getAuditLog()` added to `amd/src/lib/api.js`.
- Drift-check phpunit test `services_coverage_test.php` — iterates
  every entry in `db/services.php` and asserts the class exists,
  extends `external_api`, defines `execute_parameters()` / `execute()`
  / `execute_returns()`, and references a declared capability.

#### Notes
- Calendar editor migration to React deferred — the existing
  `pages/calendar_editor.php` is pure server-rendered moodleform with
  no JS to migrate. The future React port (documented in
  `docs/future-features.md`) will adopt the new typed wrappers.

## [1.0.5] - 2026-05-24

### Phase 3E — Dashboard redesign

#### Added
- New WS `get_insights` (`classes/external/get_insights.php`)
  returning `{bright_spot, most_improved, gentle_watch}` for the
  dashboard insight cards. Heuristics: bright spot = top-scoring
  group, most improved = largest negative `trend_pct_30d`, gentle
  watch = group with most critical pending. Null insights are omitted
  from the response. Cached 900s per `(calver, userid)`. Capability:
  `viewdashboard`.
- 8 new Preact components: `WaveMark`, `Sparkle`, `InsightCard`,
  `PriorityCard`, `ResponsivenessHero`, `ResponsivenessHeroSlim`,
  `ResponsivenessModule` (toggle wrapper, persisted via
  `localStorage`), `CoursesTable`.
- `docs/future-features.md` documenting the "On-goal academic days"
  deferral, audit-log React-view deferral, mobile reflow, woff2
  self-hosting, and Moodle 5.2 React migration.

#### Changed
- `DashboardView.js` rewritten — brand-tag → time-aware greeting (with
  `WaveMark`) → subline → collapsible `ResponsivenessModule` →
  Insights row → Priority cards → Courses table.
- `get_dashboard::execute_returns()` extended with per-course
  `score_band`, `median_eff_h`, `perceived_median_hours`, and
  `trend_series` (30-day, from `block_feedback_tracker_trend`).
  `CACHE_KEY_VERSION` bumped to 3.
- `pages/teacher_dashboard.php` pre-loads insights server-side + emits
  `greeting_firstname` so the view can build the greeting from local
  clock.
- `bootstrap::dashboard_i18n()` extended with ~30 new keys (greetings,
  insights eyebrows/bodies, priority labels, business-time chip).

## [1.0.4] - 2026-05-24

### Phase 3D — Pending report page redesign

#### Added
- 4 new Preact components: `PausedCallout` (transparency strip),
  `StatusDistributionBar` (segmented click-to-filter), `HeroMetricCard`
  (children-driven hero card chrome), `SegmentedFilter` (pill row
  with tone-coloured active state).
- Scope-level hero metrics in `pages/pending_report.php` —
  `build_pending_report_scope()` helper picks the active group's
  payload or aggregates across the course when `groupid=0`.

#### Changed
- `PendingReportView.js` rewritten — breadcrumb → title + overall
  band chip → 4-card hero (Score / Effective / SLA / Trend) →
  PausedCallout → StatusDistributionBar → toolbar with segmented
  status filter → table with dual `Effective` (bold colored) +
  `Perceived` columns + per-row `paused` tag where
  `waitinghours − effectivehours > 0.5h`.

## [1.0.3] - 2026-05-24

### Phase 3C — Perceived time + Paused aggregates + Peer data

#### Added
- New `classes/local/calendar/paused_aggregator.php` —
  `for_window(courseid, start, end)` returns `{total_days, weekend,
  holiday, recess}` for the design's transparency callout. Honours
  `excludeweekends` / `excludeholidays` / `excluderecesses` flags;
  `schoolday` override cancels weekend classification; manual pauses
  bucket as recess.
- New `classes/local/score/peer_stats.php` — `for_exclusion(groupid)`
  returns `{department_score, department_hours, top10_score,
  top10_hours}` (p50 / p90 / p10 of group rollups). Returns nulls when
  sample size < 3 so the JS `PeerContext` hides gracefully.
- Tests: `tests/local/calendar/paused_aggregator_test.php` (8 cases
  covering weekends, holiday-overrides-weekend, recess+closed,
  schoolday cancellation, manual pause, course-scope isolation, empty
  window, weekend-exclusion disabled).

#### Changed
- `responsiveness_payload::group_payload()` gains
  `perceived_median_hours` (alias of existing `median_raw_h`),
  `paused_days_30d`, `paused_breakdown_30d`,
  `peer_department_score`, `peer_department_hours`,
  `peer_top10_score`, `peer_top10_hours`.
- `get_responsiveness::execute_returns()` mirrors the new fields
  (strict additive — existing callers ignore unknown keys).
- Upgrade savepoint bumps `calver` via `calendar::bump_version()` so
  MUC keys roll over and cached payloads pick up new keys on first
  read.

## [1.0.2] - 2026-05-24

### Phase 3B — Block view recomposition

#### Added
- 8 new Preact components in `amd/src/components/`: `ScoreRing`,
  `KpiTile`, `TrendRow`, `StatTile`, `PeerContext`, `PausedNote`,
  `TimelineBar`, `OverallBanner`.
- `OverallBanner` mounted at the top of `BlockView.js` — eyebrow +
  ScoreRing + score + band pill + `PausedNote`. Overall score is a
  pending-weighted average across present group scores.
- Activities list inside each `GroupCard` — per-assignment open/close
  `TimelineBar` with urgency colouring and "NO RULE" badge for
  rule-less assignments.

#### Changed
- `GroupCard.js` recomposed — header strip (course + class name +
  status chip) → hero row (`ScoreRing` + score + caption) →
  3-column KPI row (Effective / Perceived / SLA) → `TrendRow`
  (arrow + verbal label + sparkline) → `StatTile` row (Pending /
  At risk / Priority — clickable, deep-link to filtered report) →
  `PeerContext` (optional, hidden when sample too small) →
  `BreakdownPanel` (kept, collapsed) → activities list.
- Mustache SSR fallback templates kept structurally identical;
  visual refresh comes via the CSS tokens introduced in 1.0.1.

## [1.0.1] - 2026-05-24

### Phase 3A — Design tokens & threshold setting

#### Added
- Admin setting `score_thresholds_band` (CSV `"90,70,40"` default,
  mirroring the existing `bucket_thresholds_eff` pattern) routing
  through new helper `responsiveness_calculator::parse_thresholds_band()`.
  PHP `band_for()` reads from the setting; JS
  `bandForScore(score, thresholds)` accepts an explicit thresholds
  arg propagated via `bootstrap::config_bundle()` →
  `initial.config.score_thresholds`.
- `:root` CSS token block — surface / border / text / per-band fg+bg
  pairs / font-family stacks. Per-band tokens are
  `--bft-band-{slug}-fg` / `-bg`.
- `.bft-mono` utility class for numeric cells; `--bft-font-display`
  (Manrope first, system-ui fallback) + `--bft-font-mono`
  (JetBrains Mono first, ui-monospace fallback).

#### Changed
- Band palette across PHP (`score_gauge.php::BAND_COLOURS`), JS
  (`bands.js::BAND_COLOURS`), CSS (badge rules), and gauge stroke now
  uses the calm "Academic Responsiveness" palette: excellent
  `#047857`, good `#0e7490` (teal, replacing amber), regular
  `#b45309`, critical `#be4b25` (softer burnt sienna, replacing
  pure red), pending `#475569`.
- Default font-family promoted to Manrope across `.block_feedback_tracker`
  and `.bft-dashboard`.

#### Notes
- Self-hosting Manrope + JetBrains Mono woff2 files deferred — design
  degrades cleanly to system geometric sans for users without the
  fonts installed.

## [1.0.0] - 2026-05-23

### Added — data layer
- Per-submission SLA ledger (`block_feedback_tracker_sub`) tracking raw
  wall-clock hours and business / academic effective hours for every
  `\mod_assign` submission, keyed by `(cmid, userid, attemptnumber)` and
  tied to `groupid`.
- Materialised rollup (`block_feedback_tracker_group`) with pending /
  critical / over-goal counts, raw and effective medians / p90 / max,
  compliance %, 30-day trend, `nextpause` / `lastpause` indicators, and
  the five score-formula component values (`comp_*`) per (course, group).
- Per-course backfill cursors (`block_feedback_tracker_bfcursor`) with
  round-robin starvation prevention across courses.
- Daily trend table for the 30-day sparkline and a site-wide stats table
  for the school-comparison overlay.
- Calendar configuration tables: `_cday` (per-day exceptions), `_chours`
  (weekly business hours), `_cpause` (manual pause windows).
- Dirty queue + audit log tables.

### Added — engine + score
- Academic-time engine with weekly business hours, exception days
  (schoolday / holiday / recess / closed / optional), site / course /
  group manual pause windows, weekend bitmask, and timezone awareness.
- Academic Responsiveness Score (0-100) — five-term weighted formula
  (compliance / median / critical / pending / trend) with admin-tunable
  weights (auto-normalised to sum 1.0), a four-band mapping (excellent /
  good / regular / critical), and per-term component values persisted on
  the rollup so the card UI can show *why* the score is what it is.
- Two-tier caching: per-request memos + MUC application caches
  (`calendar_effective_day`, `pause_windows_by_course`, plus session
  caches for the WS payloads). `calver` site setting bumps on every
  calendar-affecting write so old cache keys naturally fall out.
- Pause timeline computed on demand — no stored pause table needed.

### Added — events + tasks
- Event observers for the assign + group + course lifecycle that upsert
  the ledger and enqueue rollup recompute.
- Three custom plugin events (`cal_day_updated`, `cal_hours_updated`,
  `cal_pause_updated`) so calendar edits drive cache invalidation +
  rollup re-enqueue.
- Scheduled tasks: drain queue (5 min), recompute pending (hourly),
  recompute trend (daily), recompute site stats (daily), purge calendar
  cache (daily), backfill history (inactive by default), prune audit
  log (daily).
- Drain task uses a dispatcher pattern — fans out `recompute_one` adhoc
  tasks for cluster-wide parallelism.
- Backfill dispatcher fans out `backfill_one_submission` adhoc tasks
  with configurable sub-chunk size.
- Concurrency-safe rollup recompute via Lock API guard.

### Added — course processing gate
- `course_access` helper — `is_processable($courseid)` requires a
  `feedback_tracker` block instance on the course context.
- Admin setting `process_hidden_courses` (default OFF).
- SQL pre-filter for backfill using `processable_course_ids()`.

### Added — web services
- 12 external functions: get_responsiveness, get_pending_submissions,
  get_pause_timeline, get_calendar, save_calendar_day,
  bulk_import_calendar, save_business_hours, save_pause_window,
  delete_pause_window, get_dashboard, get_school_comparison,
  get_grader_priority_list.
- CSV importer with per-line error reporting.

### Added — UI
- React UI built on vendored Preact 10.29.2 + htm 3.1.1.
- Block content: SVG ring gauge, counts row, metrics row,
  paused-today / next-pause strip, 30-day sparkline, refresh button,
  drilldown link, collapsible score-breakdown panel.
- Teacher dashboard with hero KPI tiles, sortable courses table,
  optional site benchmarks section, and Grade Now priority panel.
- Pending grading report with sortable/paginated table, server-side
  filters, client-side search, and pause timeline modal.
- Calendar editor page with days / hours / pauses sections and bulk
  CSV import.
- Group drilldown page with sortable pending-submissions table.
- Recompute audit log viewer, full-reset confirmation page, tools
  landing page.

### Added — admin + access
- Site settings: 5 weights, SLA goal, bucket thresholds, calendar
  behaviour switches, weekend mask, timezone selector,
  grading-during-pause mode, performance knobs, view toggles, Tools
  links.
- 9 capabilities (addinstance / myaddinstance plus viewresponsiveness,
  viewdashboard, viewschoolcomparison, managecalendar,
  managepausewindows, resetdata, viewaudit).
- Group-mode-aware visibility on the block.
- `backfill_active` admin UI toggle.

### Added — privacy
- Full GDPR provider implementing metadata + contextlist + export +
  delete for the ledger table.

### Added — testing
- PHPUnit test classes covering academic-time engine, interval math,
  day-rule resolver, pause lookup, CSV importer, bucket classifier,
  statistics helpers, observer, submission ledger, rollup service,
  pending recomputer, score calculator, privacy provider, drain queue
  task, backfill history task, backfill cursor, course access gate,
  and web service functions.
- Behat features for install check, calendar editor, responsiveness
  block, pending report, and teacher dashboard.
- Plugin generator with helpers for seeding fixtures.

### Added — i18n
- Full EN + PT-BR language packs with complete key parity.
- "Feedback tracker" → "Feedback Flow" branding across user-facing
  strings.

### Supported Moodle range
- Moodle 4.5 through 5.2 (`requires = 2024100700`, `supported = [405, 502]`).

### Notes
- `db/upgrade.php` is a stub — fresh installations only, no upgrade
  path from hypothetical prior versions.
- `db/install.xml` is the single source of truth for the schema.

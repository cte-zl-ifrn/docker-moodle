<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Block Feedback Flow
 *
 * Documentation: {@link https://moodledev.io/docs/apis/plugintypes/blocks}
 *
 * @package    block_feedback_tracker
 * @copyright  2026 Anderson Blaine <anderson@blaine.com.br>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Feedback Flow block class definition.
 *
 * @package    block_feedback_tracker
 * @copyright  2026 Anderson Blaine <anderson@blaine.com.br>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class block_feedback_tracker extends block_base {
    /**
     * Block initialisation
     */
    public function init() {
        $this->title = get_string('pluginname', 'block_feedback_tracker');
    }

    /**
     * Get content
     *
     * On a course page, emits a React mount-point div carrying a light
     * bootstrap payload (empty groups + i18n + config) as JSON. block_app.js
     * fetches the group cards asynchronously in sequential pages after mount;
     * a short no-JS hint is wrapped inside <noscript> for graceful
     * degradation. On a page without a real course (the front page) it emits
     * a hint to add the block to a course instead.
     *
     * @return stdClass
     */
    public function get_content() {
        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = (object) ['text' => '', 'footer' => ''];

        $courseid = (int) ($this->page->course->id ?? SITEID);
        if ($courseid <= 0 || $courseid === SITEID) {
            $renderer = $this->page->get_renderer('block_feedback_tracker');
            $this->content->text = $renderer->render_from_template(
                'block_feedback_tracker/empty_hint',
                ['message' => get_string('block_addtocoursehint', 'block_feedback_tracker')]
            );
            return $this->content;
        }

        $context = context_course::instance($courseid);
        if (!has_capability('block/feedback_tracker:viewresponsiveness', $context)) {
            return $this->content;
        }

        // The group cards load asynchronously from block_app.js via the
        // get_responsiveness web service (paginated), so the initial payload
        // ships an empty groups array and a light shell — no synchronous
        // rollup read blocks first paint here.
        $groups = [];
        $lastsynced = 0;

        $renderer = $this->page->get_renderer('block_feedback_tracker');
        $ssrhtml = $renderer->render_from_template(
            'block_feedback_tracker/empty_hint',
            ['message' => get_string('block_nojs', 'block_feedback_tracker')]
        );

        // Bootstrap payload for the React tree — empty groups + every
        // localised label + the score-formula config. block_app.js fetches
        // the groups in sequential pages after mount.
        $payload = $this->build_block_payload($courseid, $groups, $lastsynced);
        // JSON_HEX_TAG protects against "</script>" appearing inside a
        // payload string from breaking out of the inline JSON island.
        $payloadjson = json_encode(
            $payload,
            JSON_HEX_TAG | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );
        if ($payloadjson === false) {
            $payloadjson = '{}';
        }

        $this->content->text = '<div data-bft-block-root data-courseid="' . $courseid . '">'
            . '<script type="application/json" data-bft-init>' . $payloadjson . '</script>'
            . '<noscript>' . $ssrhtml . '</noscript>'
            . '</div>';

        \block_feedback_tracker\local\output\vendor_bundle::load($this->page);
        $this->page->requires->js_call_amd('block_feedback_tracker/block_app', 'init');

        return $this->content;
    }

    /**
     * Assemble the JSON bootstrap consumed by block_app.js. The shared
     * i18n + config bundles live in classes/local/output/bootstrap.php so
     * standalone pages (pending_report.php, teacher_dashboard.php) can
     * autoload them — Moodle doesn't autoload block classes outside the
     * blocks subsystem.
     *
     * @param int $courseid
     * @param array $groups Group payload entries; get_content() passes none.
     * @param int $lastsynced Unix timestamp of the last rollup compute.
     * @return array
     */
    private function build_block_payload(int $courseid, array $groups, int $lastsynced): array {
        return [
            'courseid' => $courseid,
            'lastsynced' => $lastsynced,
            // Calendar version — the client folds it into its sessionStorage
            // cache key so a calendar-affecting save naturally invalidates any
            // stored pages (mirrors the server's MUC calver keying).
            'calver' => \block_feedback_tracker\local\calendar\calendar::current_version(),
            'groups' => $groups,
            'i18n' => \block_feedback_tracker\local\output\bootstrap::i18n_bundle(),
            'config' => \block_feedback_tracker\local\output\bootstrap::config_bundle(),
        ];
    }

    /**
     * Expose settings.php in the site administration tree.
     *
     * @return bool
     */
    public function has_config() {
        return true;
    }

    /**
     * Add the stylesheet's scope class to the block's own element.
     *
     * Every rule of styles.css applies only inside .block-feedback-tracker, so
     * the plugin's CSS never reaches the rest of the page; the plugin's pages
     * put the same class on their body.
     *
     * @return array
     */
    public function html_attributes() {
        $attributes = parent::html_attributes();
        $attributes['class'] .= ' block-feedback-tracker';
        return $attributes;
    }

    /**
     * Where this block can be placed: course pages only.
     *
     * @return array<string, bool>
     */
    public function applicable_formats() {
        return [
            'course-view' => true,
            'site' => false,
            'my' => false,
            'admin' => false,
        ];
    }

    /**
     * Called once by core during plugin uninstall, before it deletes every
     * instance of this block (each through instance_delete()).
     *
     * It is the only signal that separates "the plugin is going away" from
     * "somebody removed the block from a course page", and it stops
     * instance_delete() from queuing cleanup tasks for tables that are about
     * to be dropped. {@see \block_feedback_tracker\local\sla\removal_grace::mark_uninstalling()}
     *
     * @return void
     */
    public function before_delete() {
        \block_feedback_tracker\local\sla\removal_grace::mark_uninstalling();
    }

    /**
     * Arm the delayed discard of this course's measured history.
     *
     * Unlike the usual synchronous delete, the discard is deferred by the grace
     * period ({@see \block_feedback_tracker\local\sla\removal_grace} explains
     * why), and the task re-checks at run time whether the block came back.
     *
     * No decision about sibling instances is taken here: core calls this before
     * deleting the block_instances row, and blocks_delete_instances() deletes
     * the rows only after its whole loop, so a count taken now still includes
     * instances that are being deleted. The task counts when it runs.
     *
     * @return bool
     */
    public function instance_delete() {
        if (\block_feedback_tracker\local\sla\removal_grace::is_uninstalling()) {
            return true;
        }
        if (\block_feedback_tracker\local\sla\removal_grace::is_discarding_inline()) {
            return true;
        }
        if (!\block_feedback_tracker\local\sla\removal_grace::is_active()) {
            return true;
        }
        $courseid = $this->resolve_course_id();
        if ($courseid <= 0) {
            return true;
        }
        \block_feedback_tracker\local\sla\removal_grace::schedule_discard($courseid);
        return true;
    }

    /**
     * The course this instance sat on, or 0 when it did not sit on one.
     *
     * Read from the instance's parent context rather than from $this->page:
     * core loads the block against whatever the global $PAGE is, which on bulk
     * deletes, course teardown and CLI runs need not be the block's course.
     *
     * @return int
     */
    private function resolve_course_id(): int {
        if (empty($this->instance->parentcontextid)) {
            return 0;
        }
        $context = \context::instance_by_id((int) $this->instance->parentcontextid, IGNORE_MISSING);
        if (!$context || $context->contextlevel != CONTEXT_COURSE) {
            return 0;
        }
        return (int) $context->instanceid;
    }
}

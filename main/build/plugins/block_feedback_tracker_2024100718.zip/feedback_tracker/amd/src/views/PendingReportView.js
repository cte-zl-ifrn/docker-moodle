// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Full-page React view for pages/pending_report.php, reusing the dashboard's
 * hero + collapse pattern and the block's vocabulary.
 *
 * Composition (top → bottom):
 *   1. Breadcrumb (back to course + current crumb)
 *   2. Title row (course name H1 + overall status pill)
 *   3. ResponsivenessModule hero, scheduled-pause notice and AcademicDaysStrip
 *      (the hero and the strip collapse together)
 *   4. StatusDistributionBar — pending bands (Waiting/Attention/Priority) with a
 *      toggle into the graded view (On goal/Good/Regular result bands)
 *   5. Toolbar — class select, real (server-side) search, refresh
 *   6. Table — Student / Activity / Class / Submitted / [Graded] / Effective /
 *      [Perceived] / Status or Result / Action (grade or review link); Graded
 *      shows in graded mode only, Perceived in pending mode only
 *   7. Drafts table (pending mode only)
 *
 * Everything is server-driven: the group filter, distribution filter, search,
 * column sort, paging, and the distribution counts all re-fetch the WS so they
 * span every matching row, not just the page on screen. The hero scope is the
 * one client-side computation — it recomputes instantly from the groupscopes
 * payload when the class filter changes (no round-trip).
 *
 * @module    block_feedback_tracker/views/PendingReportView
 * @copyright 2026 Anderson Blaine <anderson@blaine.com.br>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

import {html, useState, useEffect, useRef} from 'block_feedback_tracker/lib/preact';
import Badge from 'block_feedback_tracker/components/Badge';
import ResponsivenessModule from 'block_feedback_tracker/components/ResponsivenessModule';
import AcademicDaysStrip from 'block_feedback_tracker/components/AcademicDaysStrip';
import StatusDistributionBar from 'block_feedback_tracker/components/StatusDistributionBar';
import Skeleton from 'block_feedback_tracker/components/Skeleton';
import RetryNotice from 'block_feedback_tracker/components/RetryNotice';
import ScheduledPauses from 'block_feedback_tracker/components/ScheduledPauses';
import {bandForScore, colourFor} from 'block_feedback_tracker/lib/bands';
import {aggregate, perceivedLabel} from 'block_feedback_tracker/lib/aggregate';
import {getPendingSubmissions, getGradedSubmissions, getAcademicDays, getReportScopes}
    from 'block_feedback_tracker/lib/api';
import {formatHours, formatDays, formatDate, usesDays, formatCount} from 'block_feedback_tracker/lib/format';
import {graderUrl} from 'block_feedback_tracker/lib/grader';
import {setUserPreference} from 'core_user/repository';
import Notification from 'core/notification';

/** Moodle user-preference name persisting the hero+heatmap collapse state. */
const PREF_REPORT_COLLAPSED = 'block_feedback_tracker_report_collapsed';

/** Hours by which the wall-clock wait must exceed effective hours to tag a row as paused. */
const PAUSED_TAG_EPSILON = 0.5;

/**
 * Map a pending row's band to its Status badge {colour band slug, label}. Uses
 * the Waiting / Attention / Priority vocabulary (card_* strings) and the same
 * colour tones as the distribution bar, so the badge always agrees with the
 * filter that produced the row.
 *
 * @param {string} pendingband  aguardando | atencao | prioridade.
 * @param {object} i18n
 * @returns {{band: string, label: string}}
 */
const pendingBadge = (pendingband, i18n) => {
    switch (pendingband) {
        case 'prioridade': return {band: 'critical', label: i18n.card_critical || 'Priority'};
        case 'atencao': return {band: 'regular', label: i18n.card_overgoal || 'Attention'};
        default: return {band: 'pending', label: i18n.card_pending || 'Waiting'};
    }
};

/**
 * Map a graded row's slabucket to its result Badge {band, label}. Graded
 * submissions use the three-band result set (Excellent / Good / Regular) from
 * the academic-days strip; critical results fold into Regular. The server
 * already folds them, so the default arm only guards the display.
 *
 * @param {string} slabucket  excellent | good | regular (critical pre-folded).
 * @param {object} i18n
 * @returns {{band: string, label: string}}
 */
const gradedBadge = (slabucket, i18n) => {
    switch (slabucket) {
        case 'excellent': return {band: 'excellent', label: i18n.acaday_legend_ongoal || 'On goal'};
        case 'good': return {band: 'good', label: i18n.acaday_legend_good || 'Good'};
        default: return {band: 'regular', label: i18n.acaday_legend_regular || 'Regular'};
    }
};

/**
 * Compute the hero scope for the active class filter, in the shape
 * lib/aggregate.js aggregate() returns plus the band. Single group → that
 * group's own figures and band; "all" (gid 0) → aggregate() over every scope,
 * the same aggregation as the dashboard hero, with the band left to the
 * caller.
 *
 * @param {Array<object>} scopes  Trimmed per-group metrics from the payload.
 * @param {number} gid            Active group id, 0 = whole course.
 * @returns {object|null}
 */
const computeScope = (scopes, gid) => {
    if (!Array.isArray(scopes) || scopes.length === 0) {
        return null;
    }
    if (gid > 0) {
        const g = scopes.find((s) => Number(s.groupid) === gid);
        if (!g) {
            return null;
        }
        return {
            score: g.responsiveness_score,
            band: g.score_band || null,
            effective: g.cur_median_eff_h,
            perceived: g.cur_median_raw_h,
            effectivedays: g.cur_median_eff_days,
            perceiveddays: g.cur_median_perc_days,
            compliance: g.compliance_pct,
            compliancedays: g.compliance_pct_days,
            trendpct: g.trend_pct_30d,
            pending: Number(g.pending) || 0,
            critical: Number(g.critical) || 0,
            overgoal: Number(g.overgoal) || 0,
        };
    }
    return {...aggregate(scopes, 'responsiveness_score'), band: null};
};

/**
 * Header cell — column label as a button that drives the server-side sort.
 *
 * @param {object} props
 * @param {string} props.label
 * @param {string} props.sortKey
 * @param {string} props.currentKey
 * @param {string} props.currentOrder
 * @param {Function} props.onClick
 * @returns {object} vnode
 */
const SortableHeader = ({label, sortKey, currentKey, currentOrder, onClick}) => {
    const active = currentKey === sortKey;
    let arrow = '';
    let ariaSort = 'none';
    if (active) {
        arrow = currentOrder === 'asc' ? ' ▲' : ' ▼';
        ariaSort = currentOrder === 'asc' ? 'ascending' : 'descending';
    }
    return html`
        <th scope="col"
            class=${'bft-th-sortable' + (active ? ' is-active' : '')}
            aria-sort=${ariaSort}>
            <button type="button"
                    class="bft-th-sortable-btn"
                    onClick=${() => onClick(sortKey)}>
                ${label}${arrow}
            </button>
        </th>
    `;
};

/**
 * Paused-period info chip — a hatched swatch + "i" toggle that pins a small
 * popover explaining that the row crossed a paused window. Shared by the
 * pending (perceived) cell and the graded (result) cell so both annotate a
 * pause identically; the caller passes the already unit-resolved tip copy
 * (business-hours vs business-days wording).
 *
 * @param {object} props
 * @param {number} props.submissionid  Row id; drives the open-popover state.
 * @param {string} props.tip           Localised, unit-resolved explanation.
 * @param {string} props.label         Localised "paused" aria label.
 * @param {number|null} props.openid   Currently open submissionid, or null.
 * @param {Function} props.onToggle    Sets the open submissionid (or null).
 * @returns {object} vnode
 */
const PausedTag = ({submissionid, tip, label, openid, onToggle}) => html`
    <span class="bft-row-paused-wrap">
        <button type="button"
                class="bft-row-paused-tag"
                title=${tip}
                aria-label=${label}
                aria-expanded=${openid === submissionid ? 'true' : 'false'}
                onClick=${() => onToggle(openid === submissionid ? null : submissionid)}>
            <span class="bft-row-paused-swatch" aria-hidden="true"></span>
            <span class="bft-row-paused-i" aria-hidden="true">i</span>
        </button>
        ${openid === submissionid && html`
            <span class="bft-row-paused-pop" role="note">${tip}</span>
        `}
    </span>
`;

/**
 * Marker-turnaround chip. Shown only when the submission carries both
 * allocation stamps, i.e. when the split is a fact for this row rather than an
 * estimate. Reads "queue → turnaround" so a long wait for someone to be made
 * responsible is not mistaken for slow marking.
 *
 * @param {object} props
 * @param {number|null} props.queuehours  Hand-in to first allocation.
 * @param {number|null} props.allochours  Allocation to grading.
 * @param {string} props.tip              Localised explanation.
 * @returns {object|null} vnode
 */
const AllocSplitTag = ({queuehours, allochours, tip}) => {
    if (queuehours === null || queuehours === undefined
        || allochours === null || allochours === undefined) {
        return null;
    }
    return html`
        <span class="bft-row-split" title=${tip}>
            <span class="bft-row-split-queue">${formatHours(queuehours)}</span>
            <span class="bft-row-split-arrow" aria-hidden="true">→</span>
            <span class="bft-row-split-alloc">${formatHours(allochours)}</span>
        </span>
    `;
};

/**
 * The explanation of a resubmitted row, dated with the earlier mark when it is
 * still known (retention can prune the cycle that held it).
 *
 * @param {number} previousmarktime Epoch of the earlier mark, 0 when unknown.
 * @param {object} i18n
 * @returns {string}
 */
const resubmittedTip = (previousmarktime, i18n) => {
    const when = Number(previousmarktime) || 0;
    if (when > 0) {
        return String(i18n.status_resubmitted_help || '').replace('{$a}', formatDate(when));
    }
    return i18n.status_resubmitted_help_nodate || '';
};

/**
 * A per-row disclosure: a short tag whose explanation opens on click.
 *
 * Used wherever a row's status is true but incomplete on its own — work handed
 * in again after a mark, a mark the workflow has not released, a cycle answered
 * outside the activity, a grade the gradebook is hiding. The key carries the variant as well as the row, because
 * one row can raise more than one of these and a key of the row alone would let
 * them fight over the single open slot.
 *
 * Releasing a workflow mark needs mod/assign:releasegrades, which core grants
 * only to editing teachers and managers, so the release tag names that step for
 * a marker who often cannot take it, instead of letting the row read as finished.
 *
 * @param {object} props
 * @param {string} props.tagkey   Unique per row AND variant.
 * @param {string} props.variant  Modifier for the CSS class.
 * @param {string} props.tip      The explanation.
 * @param {string} props.label    The visible tag text.
 * @param {string} props.openid   Which tag is currently open.
 * @param {Function} props.onToggle
 * @returns {object} vnode
 */
const RowDisclosureTag = ({tagkey, variant, tip, label, openid, onToggle}) => {
    const popid = 'bft-tip-' + String(tagkey).replace(':', '-');
    const open = openid === tagkey;
    /* No aria-label: the button is named by its visible text. An aria-label
       holding the explanation would replace that short name, and with title
       also set screen readers would read the explanation twice on focus.
       aria-controls ties the button to the popup it opens. */
    return html`
        <span class="bft-row-release-wrap">
            <button type="button"
                    class="bft-badge bft-badge-${variant}"
                    title=${tip}
                    aria-expanded=${open ? 'true' : 'false'}
                    aria-controls=${popid}
                    onKeyDown=${(e) => e.key === 'Escape' && open && onToggle(null)}
                    onClick=${() => onToggle(open ? null : tagkey)}>
                ${label}
            </button>
            ${open && html`
                <span class="bft-row-release-pop" id=${popid} role="note">${tip}</span>
            `}
        </span>
    `;
};

/**
 * Top-level view.
 *
 * @param {object} props
 * @param {object} props.initial  Mount-point payload.
 * @returns {object} vnode
 */
// Branch count over the lint cap is acknowledged debt (refactor pass pending).
// eslint-disable-next-line complexity
export default function PendingReportView({initial}) {
    const i18n = initial.i18n || {};
    const config = initial.config || {};
    const scoreThresholds = config.score_thresholds || null;
    const courseid = Number(initial.courseid) || 0;
    const initialPending = initial.pending || {};


    const wwwroot = (typeof M !== 'undefined' && M.cfg && M.cfg.wwwroot) || '';
    const courseUrl = wwwroot + '/course/view.php?id=' + encodeURIComponent(String(courseid));

    // --- Mode + server-driven filters. ---
    const [mode, setMode] = useState('pending');
    const [groupid, setGroupid] = useState(Number(initialPending.groupid) || 0);
    const [filter, setFilter] = useState(String(initialPending.band || ''));
    const [serverSort, setServerSort] = useState(String(initialPending.sort || 'longestwait'));
    const [sortOrder, setSortOrder] = useState('desc');
    const [page, setPage] = useState(Number(initialPending.page) || 0);
    const [perpage] = useState(Number(initialPending.perpage) || 25);

    // Debounced search: searchInput is bound to the box; search drives the WS.
    const [searchInput, setSearchInput] = useState('');
    const [search, setSearch] = useState('');

    // --- Page data — all fetched after mount (the bootstrap ships only the
    // filter parameters), so the page's first byte never blocks on the
    // submissions queries. loading starts true so the first paint shows the
    // table skeleton instead of a flash of "no submissions".
    const [submissions, setSubmissions] = useState([]);
    const [total, setTotal] = useState(0);
    const [counts, setCounts] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // Drafts (pending mode only) — lazy-loaded after the main table lands,
    // refetched on class change.
    const [drafts, setDrafts] = useState([]);

    // Hero scopes + class-filter list, from the lightweight rollup-only
    // get_report_scopes WS (the full responsiveness payload is never built
    // for this page). The hero and the class filter stay hidden until this
    // lands.
    const [groupScopes, setGroupScopes] = useState([]);
    const availableGroups = groupScopes.map((g) => ({
        id: Number(g.groupid) || 0,
        name: g.name || '',
    }));

    /**
     * Load the per-group scopes (hero + class filter).
     */
    const fetchScopes = async() => {
        try {
            const result = await getReportScopes({courseid});
            setGroupScopes(Array.isArray(result.groups) ? result.groups : []);
        } catch (e) {
            setGroupScopes([]);
        }
    };

    // Collapse state for the hero + heatmap container (Moodle user preference).
    const [collapsed, setCollapsed] = useState(Boolean(initial.report_collapsed));
    // Scheduled-pause notice — preloaded course-scope by pending_report.php,
    // already decorated + visibility-filtered server-side. Gated by the admin
    // toggle (default ON).
    const [upcoming] = useState(Array.isArray(initial.upcoming) ? initial.upcoming : []);

    // Which row's paused-info popover is open (submissionid, or null). The
    // info icon keeps its hover title; click pins the explanation for
    // touch devices and discoverability.
    const [pausedinfo, setPausedinfo] = useState(null);

    // Which RowDisclosureTag explanation is pinned open (its tagkey, e.g.
    // '42:release', or null). Kept separate from pausedinfo so a row can show both.
    const [releaseinfo, setReleaseinfo] = useState(null);

    // Academic-days heatmap (async).
    const [acaDays, setAcaDays] = useState([]);
    const [acaSummary, setAcaSummary] = useState(null);
    const [acaEvents, setAcaEvents] = useState([]);
    const [acaLoading, setAcaLoading] = useState(true);
    const [acaError, setAcaError] = useState(null);

    const firstRun = useRef(true);
    const firstRunDrafts = useRef(true);
    // Number of the latest request of each kind: only its answer may change the screen, so a slow answer for a
    // mode, filter, page or class the viewer has already left is dropped (SchoolComparison's pattern).
    const pageTicket = useRef(0);
    const draftsTicket = useRef(0);
    const acaTicket = useRef(0);
    // The class the drafts on screen belong to. Graded mode fetches no drafts, so a class changed there is
    // fetched on the way back to pending.
    const draftsGroup = useRef(null);

    /**
     * Pick the user-facing message for a failed fetch: a friendly connectivity
     * notice for network drops (api.js tags these `bftNetwork` and suppresses
     * the technical toast) or the generic report error otherwise.
     *
     * @param {*} e  The rejection value from a web-service call.
     * @returns {string}
     */
    const netMsg = (e) => (e && e.bftNetwork)
        ? (i18n.connection_lost || 'Connection lost. Check your internet and try again.')
        : (i18n.pendingreport_error || 'Failed to load.');

    /**
     * Fetch a page using the current mode + filters.
     */
    const fetchPage = async() => {
        pageTicket.current += 1;
        const ticket = pageTicket.current;
        setLoading(true);
        setError(null);
        const args = {courseid, groupid, sort: serverSort, order: sortOrder, search, page, perpage};
        try {
            const result = mode === 'graded'
                ? await getGradedSubmissions(Object.assign({}, args, {bucket: filter}))
                : await getPendingSubmissions(Object.assign({}, args, {band: filter}));
            if (ticket !== pageTicket.current) {
                return;
            }
            setSubmissions(Array.isArray(result.submissions) ? result.submissions : []);
            setTotal(Number(result.total) || 0);
            setCounts(result.counts || {});
        } catch (e) {
            if (ticket === pageTicket.current) {
                setError(netMsg(e));
            }
        } finally {
            if (ticket === pageTicket.current) {
                setLoading(false);
            }
        }
    };

    // Debounce keystrokes into the search term (reset to page 0 on change).
    useEffect(() => {
        const t = setTimeout(() => {
            setPage(0);
            setSearch(searchInput);
        }, 350);
        return () => clearTimeout(t);
    }, [searchInput]);

    // Re-fetch on any server-driven change. The guard skips the mount run —
    // the mount effect below owns the initial load.
    useEffect(() => {
        if (firstRun.current) {
            firstRun.current = false;
            return;
        }
        fetchPage();
    }, [mode, groupid, filter, serverSort, sortOrder, search, page]);

    // Drafts depend only on the class filter, and show in pending mode only.
    const fetchDrafts = async() => {
        draftsTicket.current += 1;
        const ticket = draftsTicket.current;
        const forgroup = groupid;
        try {
            const result = await getPendingSubmissions({
                courseid, groupid, status: 'draft', sort: 'recent', perpage,
            });
            if (ticket !== draftsTicket.current) {
                return;
            }
            setDrafts(Array.isArray(result.submissions) ? result.submissions : []);
            draftsGroup.current = forgroup;
        } catch (e) {
            if (ticket === draftsTicket.current) {
                setDrafts([]);
                draftsGroup.current = null;
            }
        }
    };
    // Guard skips the mount run — the mount effect below chains the initial
    // drafts fetch after the first table page resolves.
    useEffect(() => {
        if (firstRunDrafts.current) {
            firstRunDrafts.current = false;
            return;
        }
        if (mode === 'graded' || draftsGroup.current === groupid) {
            return;
        }
        fetchDrafts();
    }, [groupid, mode]);

    // Mount: the main table is what the teacher came for, so it fetches
    // first, in parallel with the lightweight hero scopes; drafts follow once
    // the table has landed. The academic-days strip has its own mount effect.
    useEffect(() => {
        fetchScopes();
        // Errors surface inside fetchPage/fetchDrafts themselves.
        fetchPage().then(fetchDrafts).catch(() => null);
    }, []);

    // Academic-days heatmap loads on mount and on class change.
    const fetchAcademic = async() => {
        acaTicket.current += 1;
        const ticket = acaTicket.current;
        setAcaLoading(true);
        setAcaError(null);
        try {
            const result = await getAcademicDays({courseid, groupid});
            if (ticket !== acaTicket.current) {
                return;
            }
            setAcaDays(Array.isArray(result.days) ? result.days : []);
            setAcaSummary(result.summary || null);
            setAcaEvents(Array.isArray(result.events) ? result.events : []);
        } catch (e) {
            if (ticket === acaTicket.current) {
                setAcaDays([]);
                setAcaError(netMsg(e));
            }
        } finally {
            if (ticket === acaTicket.current) {
                setAcaLoading(false);
            }
        }
    };
    useEffect(() => {
        fetchAcademic();
    }, [groupid]);

    const totalPages = Math.max(1, Math.ceil(total / perpage));
    const graded = mode === 'graded';

    // Column captions — each cell repeats its caption through data-label, which
    // surfaces as the field label when the table reflows into stacked cards on
    // narrow screens (mirrors the dashboard courses table). Values match the
    // header strings so the card caption always equals its column header.
    const cols = {
        activity: i18n.drilldown_col_activity,
        'class': i18n.pendingreport_filter_class_label || 'Class',
        submitted: i18n.drilldown_col_submitted,
        graded: i18n.pendingreport_col_graded || 'Graded',
        effective: i18n.pendingreport_col_effective || 'Effective',
        perceived: i18n.pendingreport_col_perceived || 'Perceived',
        status: graded
            ? (i18n.pendingreport_col_result || 'Result')
            : i18n.drilldown_col_status,
        lastsaved: i18n.drilldown_col_lastsaved || 'Last saved',
    };

    /**
     * Toggle the collapse state, persisting it as a user preference.
     *
     * @param {boolean} next
     */
    const handleToggleCollapsed = (next) => {
        setCollapsed(next);
        setUserPreference(PREF_REPORT_COLLAPSED, next ? '1' : '0')
            .catch((e) => {
                setCollapsed(!next);
                Notification.exception(e);
            });
    };

    /**
     * Switch pending ↔ graded, resetting the dependent filters.
     *
     * @param {string} m
     */
    const handleModeChange = (m) => {
        if (m === mode) {
            return;
        }
        setMode(m);
        // The two modes have different columns: the old mode's rows go with it, and the skeleton stands in
        // until the new mode's first page lands.
        setSubmissions([]);
        setTotal(0);
        setLoading(true);
        setFilter('');
        setCounts({});
        setPage(0);
        setServerSort(m === 'graded' ? 'graded' : 'longestwait');
        setSortOrder('desc');
    };

    /**
     * Toggle / set the server-side column sort.
     *
     * @param {string} key
     */
    const handleSort = (key) => {
        if (serverSort === key) {
            setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
        } else {
            setServerSort(key);
            const textcol = key === 'student' || key === 'activity' || key === 'class';
            setSortOrder(textcol ? 'asc' : 'desc');
        }
        setPage(0);
    };

    // --- Hero scope. ---
    const scope = computeScope(groupScopes, groupid);
    const scopeScore = scope && scope.score !== null && scope.score !== undefined
        ? Number(scope.score) : null;
    const scopeBand = (scope && scope.band) || bandForScore(scopeScore, scoreThresholds);
    const scopeBandLabel = (i18n.bands || {})[scopeBand] || '';
    // Compliance chip + hero honour the display unit: business-days mode uses
    // the day-ruler twin (compliancedays), hours mode the effective-hours value.
    let scopeCompliance = null;
    if (scope) {
        scopeCompliance = usesDays(config) ? scope.compliancedays : scope.compliance;
    }

    const chips = [];
    if (scope) {
        if (scopeCompliance !== null && scopeCompliance !== undefined) {
            chips.push({
                label: Math.round(Number(scopeCompliance)) + '% ' + (i18n.report_chip_sla || 'within target'),
                tone: scopeBand,
            });
        }
        if (scope.overgoal > 0) {
            chips.push({label: formatCount(scope.overgoal) + ' ' + (i18n.hero_sla_atrisk || 'at risk'), tone: 'regular'});
        }
        if (scope.critical > 0) {
            chips.push({label: formatCount(scope.critical) + ' ' + (i18n.hero_sla_critical || 'critical'), tone: 'critical'});
        }
    }

    let perceivedlabel;
    if (usesDays(config)) {
        perceivedlabel = formatDays(scope ? scope.perceiveddays : null);
    } else {
        perceivedlabel = scope ? perceivedLabel(scope.perceived) : '—';
    }

    const heroprops = {
        score: scopeScore,
        band: scopeBand,
        bandlabel: scopeBandLabel,
        effectivehours: scope && scope.effective !== null && scope.effective !== undefined
            ? Number(scope.effective) : null,
        effectivedays: scope && scope.effectivedays !== null && scope.effectivedays !== undefined
            ? Number(scope.effectivedays) : null,
        perceivedlabel,
        compliancepct: scopeCompliance !== null && scopeCompliance !== undefined
            ? Number(scopeCompliance) : null,
        trendpct: scope && scope.trendpct !== null && scope.trendpct !== undefined
            ? Number(scope.trendpct) : null,
        i18n,
        config,
        chips,
        eyebrow: i18n.report_hero_eyebrow,
        headline: i18n.report_hero_headline,
        body: i18n.report_hero_body,
    };

    const sublineLabel = (graded
        ? (i18n.pendingreport_subline_graded || '{$a} graded')
        : (i18n.pendingreport_subline_pending || '{$a} awaiting feedback')).replace('{$a}', formatCount(total));

    // Empty-state precedence: skeleton while the first page loads, retry on
    // error, "nothing matches" otherwise; null means the table renders. The
    // skeleton is aria-hidden, so while a page loads the table region is
    // aria-busy and the visually-hidden status line announces the load.
    let emptystate = null;
    if (loading && submissions.length === 0) {
        emptystate = html`<${Skeleton} count=${5} />`;
    } else if (error && submissions.length === 0) {
        emptystate = html`
            <${RetryNotice}
                message=${error}
                onRetry=${fetchPage}
                retrying=${loading}
                i18n=${i18n}
                variant="block" />`;
    } else if (submissions.length === 0) {
        emptystate = html`
            <div class="bft-empty">
                ${i18n.pendingreport_empty || 'No submissions match the current filter.'}
            </div>
        `;
    }

    return html`
        <div class="bft-report">
            <nav class="bft-breadcrumb" aria-label="breadcrumb">
                <a class="bft-crumb-link" href=${courseUrl}>
                    ${i18n.pendingreport_breadcrumb_course || '← Back to course'}
                </a>
                <span class="bft-crumb-sep">/</span>
                <span class="bft-crumb-current">
                    ${i18n.pendingreport_crumb_current || 'Pending grading · detailed report'}
                </span>
            </nav>

            <div class="bft-report-title-row">
                <div class="bft-report-title-text">
                    <h1 class="bft-report-h1">${initial.coursename}</h1>
                    <div class="bft-report-subline">${sublineLabel}</div>
                </div>
                ${scopeBand && scopeBandLabel && html`
                    <${Badge} band=${scopeBand} label=${scopeBandLabel} />
                `}
            </div>

            ${scope && html`
                <${ResponsivenessModule}
                    collapsed=${collapsed}
                    onToggle=${handleToggleCollapsed}
                    heroprops=${heroprops} />
            `}

            ${config.show_scheduled_pauses !== false && html`
                <${ScheduledPauses} pauses=${upcoming} i18n=${i18n} />
            `}

            ${!collapsed && html`
                <${AcademicDaysStrip}
                    days=${acaDays}
                    summary=${acaSummary}
                    events=${acaEvents}
                    loading=${acaLoading}
                    error=${acaError}
                    onRetry=${fetchAcademic}
                    i18n=${i18n}
                    config=${config} />
            `}

            <${StatusDistributionBar}
                mode=${mode}
                counts=${counts}
                active=${filter}
                onSelect=${(slug) => {
 setPage(0); setFilter(slug);
}}
                onModeChange=${handleModeChange}
                i18n=${i18n} />

            <div class="bft-report-controls">
                ${availableGroups.length > 1 && html`
                    <label class="bft-filter-label">
                        <span>${i18n.pendingreport_filter_class_label || 'Class'}</span>
                        <select value=${String(groupid)}
                                onChange=${(e) => {
 setPage(0); setGroupid(Number(e.target.value));
}}>
                            <option value="0">${i18n.pendingreport_filter_group_all || 'All groups'}</option>
                            ${availableGroups.map((g) => html`
                                <option value=${String(g.id)} key=${'g-' + g.id}>${g.name}</option>
                            `)}
                        </select>
                    </label>
                `}
                <div class="bft-report-controls-spacer"></div>
                <input type="search"
                       class="bft-search"
                       placeholder=${i18n.pendingreport_search_placeholder || 'Search by name…'}
                       aria-label=${i18n.pendingreport_search_placeholder || 'Search by name'}
                       value=${searchInput}
                       onInput=${(e) => setSearchInput(e.target.value)} />
                <button type="button"
                        class=${'bft-refresh' + (loading ? ' bft-refresh-busy' : '')}
                        disabled=${loading}
                        title=${i18n.card_refresh}
                        aria-label=${i18n.card_refresh}
                        onClick=${fetchPage}>⟳</button>
            </div>

            ${error && submissions.length > 0 && html`
                <${RetryNotice}
                    message=${error}
                    onRetry=${fetchPage}
                    retrying=${loading}
                    i18n=${i18n}
                    variant="banner" />`}

            <span class="bft-sr-only" role="status">
                ${loading ? i18n.pendingreport_loading : ''}
            </span>
            <div class="bft-report-body"
                 aria-busy=${loading ? 'true' : 'false'}
                 aria-label=${loading ? i18n.pendingreport_loading : null}>
                ${emptystate}
                ${!emptystate && html`
                    <table class="bft-report-table">
                        <thead>
                            <tr>
                                <${SortableHeader} label=${i18n.drilldown_col_student}
                                    sortKey="student" currentKey=${serverSort}
                                    currentOrder=${sortOrder} onClick=${handleSort} />
                                <${SortableHeader} label=${i18n.drilldown_col_activity}
                                    sortKey="activity" currentKey=${serverSort}
                                    currentOrder=${sortOrder} onClick=${handleSort} />
                                <${SortableHeader} label=${(i18n.pendingreport_filter_class_label || 'Class')}
                                    sortKey="class" currentKey=${serverSort}
                                    currentOrder=${sortOrder} onClick=${handleSort} />
                                <${SortableHeader} label=${i18n.drilldown_col_submitted}
                                    sortKey="submitted" currentKey=${serverSort}
                                    currentOrder=${sortOrder} onClick=${handleSort} />
                                ${graded && html`
                                    <${SortableHeader} label=${i18n.pendingreport_col_graded || 'Graded'}
                                        sortKey="graded" currentKey=${serverSort}
                                        currentOrder=${sortOrder} onClick=${handleSort} />
                                `}
                                <${SortableHeader} label=${i18n.pendingreport_col_effective || 'Effective'}
                                    sortKey="effective" currentKey=${serverSort}
                                    currentOrder=${sortOrder} onClick=${handleSort} />
                                ${!graded && html`
                                    <${SortableHeader} label=${i18n.pendingreport_col_perceived || 'Perceived'}
                                        sortKey="perceived" currentKey=${serverSort}
                                        currentOrder=${sortOrder} onClick=${handleSort} />
                                `}
                                <${SortableHeader} label=${cols.status}
                                    sortKey="status" currentKey=${serverSort}
                                    currentOrder=${sortOrder} onClick=${handleSort} />
                                <th class="bft-report-col-action">
                                    ${i18n.pendingreport_col_action || 'Action'}
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            ${submissions.map(
                                // Branch count over the lint cap is acknowledged debt.
                                // eslint-disable-next-line complexity
                                (row) => {
                                // Paused = part of the window fell in a non-business
                                // period. Detected per the active display unit:
                                // business-days mode compares elapsed calendar vs
                                // business days; hours mode compares wall-clock vs
                                // effective hours.
                                const paused = usesDays(config)
                                    ? Number(row.perceived_days || 0)
                                        - Number(row.effective_days || 0) >= 1
                                    : Number(row.waitinghours || 0)
                                        - Number(row.effectivehours || 0) > PAUSED_TAG_EPSILON;
                                const rowColor = colourFor(row.slabucket);
                                const resultbadge = graded ? gradedBadge(row.slabucket, i18n) : null;
                                return html`
                                    <tr class="bft-report-row" key=${'r-' + row.submissionid}>
                                        <td class="bft-report-cell-title">${row.studentname}</td>
                                        <td data-label=${cols.activity}>${row.activityname}</td>
                                        <td data-label=${cols.class}>${row.groupname || '-'}</td>
                                        <td class="bft-mono" data-label=${cols.submitted}>${formatDate(row.timesubmitted)}</td>
                                        ${graded && html`
                                            <td class="bft-mono" data-label=${cols.graded}>${formatDate(row.timegraded)}</td>
                                        `}
                                        <td class="bft-report-effective bft-mono" data-label=${cols.effective}
                                            style=${'color: ' + rowColor + ';'}>
                                            ${usesDays(config)
                                                ? formatDays(row.effective_days)
                                                : formatHours(row.effectivehours)}
                                        </td>
                                        ${!graded && html`
                                            <td class="bft-mono" data-label=${cols.perceived}>
                                                <span class="bft-report-perceived">
                                                    ${usesDays(config)
                                                        ? formatDays(row.perceived_days)
                                                        : formatHours(row.waitinghours)}
                                                    ${paused && html`<${PausedTag}
                                                        submissionid=${row.submissionid}
                                                        tip=${i18n.pendingreport_row_paused_tip || ''}
                                                        label=${i18n.pendingreport_row_paused || 'paused'}
                                                        openid=${pausedinfo}
                                                        onToggle=${setPausedinfo} />`}
                                                </span>
                                            </td>
                                        `}
                                        <td data-label=${cols.status}>
                                            ${graded
                                                ? html`
                                                    <span class="bft-row-result">
                                                        <${Badge} band=${resultbadge.band}
                                                            label=${resultbadge.label} />
                                                        ${paused && html`<${PausedTag}
                                                            submissionid=${row.submissionid}
                                                            tip=${i18n.pendingreport_row_paused_graded_tip || ''}
                                                            label=${i18n.pendingreport_row_paused || 'paused'}
                                                            openid=${pausedinfo}
                                                            onToggle=${setPausedinfo} />`}
                                                    </span>
                                                `
                                                : (() => {
                                                    const pb = pendingBadge(row.pendingband, i18n);
                                                    return html`<${Badge} band=${pb.band} label=${pb.label} />`;
                                                })()}
                                            ${!graded && Number(row.resubmitted) === 1 && html`
                                                <${RowDisclosureTag}
                                                    tagkey=${row.submissionid + ':resubmitted'}
                                                    variant="resubmitted"
                                                    tip=${resubmittedTip(row.previousmarktime, i18n)}
                                                    label=${i18n.status_resubmitted || 'Resubmitted'}
                                                    openid=${releaseinfo}
                                                    onToggle=${setReleaseinfo} />
                                            `}
                                            ${Number(row.awaitingrelease) === 1 && html`
                                                <${RowDisclosureTag}
                                                    tagkey=${row.submissionid + ':release'}
                                                    variant="release"
                                                    tip=${i18n.status_awaiting_release_help || ''}
                                                    label=${i18n.status_awaiting_release || 'Awaiting release'}
                                                    openid=${releaseinfo}
                                                    onToggle=${setReleaseinfo} />
                                            `}
                                            ${row.closedsource === 'gradebook' && html`
                                                <${RowDisclosureTag}
                                                    tagkey=${row.submissionid + ':gradebook'}
                                                    variant="gradebook"
                                                    tip=${i18n.status_closed_in_gradebook_help || ''}
                                                    label=${i18n.status_closed_in_gradebook || 'Graded in gradebook'}
                                                    openid=${releaseinfo}
                                                    onToggle=${setReleaseinfo} />
                                            `}
                                            ${Number(row.gradehidden) === 1 && html`
                                                <${RowDisclosureTag}
                                                    tagkey=${row.submissionid + ':hidden'}
                                                    variant="hiddengrade"
                                                    tip=${i18n.status_grade_hidden_help || ''}
                                                    label=${i18n.status_grade_hidden || 'Hidden from student'}
                                                    openid=${releaseinfo}
                                                    onToggle=${setReleaseinfo} />
                                            `}
                                            <${AllocSplitTag}
                                                queuehours=${row.queuehours}
                                                allochours=${row.allochours}
                                                tip=${i18n.alloc_split_tip || ''} />
                                        </td>
                                        <td class="bft-report-col-action">
                                            <a class="bft-report-action-grade" href=${graderUrl(row, config)}>
                                                ${graded
                                                    ? (i18n.pendingreport_action_review || 'Review')
                                                    : (i18n.pendingreport_action_grade || 'Grade')}
                                            </a>
                                        </td>
                                    </tr>
                                `;
                            })}
                        </tbody>
                    </table>
                `}
            </div>

            ${total > perpage && html`
                <div class="bft-pagination">
                    <button type="button"
                            disabled=${page === 0 || loading}
                            onClick=${() => setPage(Math.max(0, page - 1))}>
                        ${i18n.pendingreport_page_prev || '« Prev'}
                    </button>
                    <span class="bft-pagination-state">
                        ${(i18n.pendingreport_page_template || 'Page {$a->page} of {$a->total}')
                            .replace('{$a->page}', String(page + 1))
                            .replace('{$a->total}', String(totalPages))
                        }
                    </span>
                    <button type="button"
                            disabled=${page >= totalPages - 1 || loading}
                            onClick=${() => setPage(page + 1)}>
                        ${i18n.pendingreport_page_next || 'Next »'}
                    </button>
                </div>
            `}

            ${!graded && drafts.length > 0 && html`
                <div class="bft-report-drafts">
                    <h2 class="bft-report-drafts-heading">
                        ${i18n.drafts_heading || 'Not yet submitted'}
                    </h2>
                    ${i18n.drafts_note && html`
                        <p class="bft-report-drafts-note">${i18n.drafts_note}</p>
                    `}
                    <table class="bft-report-table bft-report-drafts-table">
                        <thead>
                            <tr>
                                <th>${i18n.drilldown_col_student}</th>
                                <th>${i18n.drilldown_col_activity}</th>
                                <th>${i18n.pendingreport_filter_class_label || 'Class'}</th>
                                <th>${i18n.drilldown_col_lastsaved || 'Last saved'}</th>
                                <th>${i18n.drilldown_col_status}</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${drafts.map((row) => html`
                                <tr class="bft-report-row bft-report-row--draft"
                                    key=${'d-' + row.submissionid}>
                                    <td class="bft-report-cell-title">${row.studentname}</td>
                                    <td data-label=${cols.activity}>${row.activityname}</td>
                                    <td data-label=${cols.class}>${row.groupname || '-'}</td>
                                    <td class="bft-mono" data-label=${cols.lastsaved}>${formatDate(row.timesubmitted)}</td>
                                    <td data-label=${cols.status}>
                                        <span class="bft-badge bft-badge-draft">
                                            ${i18n.status_draft || 'Draft'}
                                        </span>
                                    </td>
                                </tr>
                            `)}
                        </tbody>
                    </table>
                </div>
            `}
        </div>
    `;
}

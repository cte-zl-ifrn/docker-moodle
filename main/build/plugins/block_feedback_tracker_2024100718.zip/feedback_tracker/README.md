# Feedback Flow

[![Moodle Plugin CI: main (Moodle 5.3)](https://github.com/uaiblaine/moodle-block_feedback_tracker/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/uaiblaine/moodle-block_feedback_tracker/actions/workflows/ci.yml?query=branch%3Amain)
[![Moodle Plugin CI: MOODLE_502_STABLE (Moodle 5.2)](https://github.com/uaiblaine/moodle-block_feedback_tracker/actions/workflows/ci.yml/badge.svg?branch=MOODLE_502_STABLE)](https://github.com/uaiblaine/moodle-block_feedback_tracker/actions/workflows/ci.yml?query=branch%3AMOODLE_502_STABLE)
[![Moodle Plugin CI: MOODLE_501_STABLE (Moodle 5.1)](https://github.com/uaiblaine/moodle-block_feedback_tracker/actions/workflows/ci.yml/badge.svg?branch=MOODLE_501_STABLE)](https://github.com/uaiblaine/moodle-block_feedback_tracker/actions/workflows/ci.yml?query=branch%3AMOODLE_501_STABLE)
[![Moodle Plugin CI: MOODLE_405_STABLE (Moodle 4.5)](https://github.com/uaiblaine/moodle-block_feedback_tracker/actions/workflows/ci.yml/badge.svg?branch=MOODLE_405_STABLE)](https://github.com/uaiblaine/moodle-block_feedback_tracker/actions/workflows/ci.yml?query=branch%3AMOODLE_405_STABLE)

**Feedback Flow** helps teaching teams visualize — and value — how efficiently students receive feedback on their work, measured fairly in *working time* rather than raw calendar days.

## Why Feedback Flow?

Timely feedback is one of the biggest drivers of student learning, but it is often hard to evaluate at a glance how a course is doing. Counting raw elapsed time can be misleading: it inadvertently penalizes educators for nights, weekends, holidays, and term breaks when grading is naturally paused.

Feedback Flow measures the turnaround time between a student submitting work and a teacher evaluating it using **academic business time**. It automatically pauses the clock outside of working hours, ensuring the resulting **Academic Responsiveness Score** is an encouraging indicator that rewards consistency, rather than a rigid stopwatch that adds unnecessary pressure.

## What it does

- **Academic Responsiveness Score (0–100)** for each class or group, featuring a clear status band (Excellent, Good, …) and a plain-language explanation of how the score was calculated.
- **A fair "working-time" clock** — pauses automatically on weekends, holidays, recesses, and outside configured hours, following an academic calendar you control.
- **A course block** showing each group's score, typical turnaround time, and the volume of submissions currently awaiting review.
- **A teacher dashboard** with a clean overview across all courses, a priority list for upcoming grading, and supportive insights (e.g., most improved, items requiring attention).
- **A pending-grading report** outlining what is in the queue, what has been completed, and a 30-day historical view of grading momentum.
- **Optional peer context**: each group's score beside the median of every other scored group on the site and the top 10%, with no names (shown once at least three other groups have a score).
- **Optional score simulator** — a safe sandbox to understand how different scenarios affect the score, without altering real data.

Only work that students have explicitly **submitted** triggers the system, and Feedback Flow only runs in courses where you have added the block — giving you total control over when to opt in.

## Screenshots

*Moodle with the Boost theme and a demo term: five courses, one teacher, about four hundred submissions.*

### Teacher dashboard

![Teacher dashboard: overall score, upcoming pause, insights, the three submissions to grade first and a table of the teacher's courses](docs/screenshots/teacher-dashboard.png)

One page across every course the teacher teaches. The top card gives their Academic Responsiveness Score with the typical feedback time in working hours, the wait as students perceive it in calendar days, and the trend against the previous week. A pause from the academic calendar is announced a few days ahead. **Insights** name the group doing best, the one improving fastest and the one that needs a look; **Grade now** picks the three submissions that have waited longest in working time, each with a link straight to it. The course table ends in a 14-day sparkline per course.

### The block in a course

![A course page with the Feedback Flow block open in the block drawer](docs/screenshots/course-page.png)

<table>
<tr>
<td valign="top" width="260"><img src="docs/screenshots/course-block.png" alt="Close-up of the block: course score, upcoming pause and the card of one group" width="240"></td>
<td valign="top">

Added to a course, the block shows the course score and one card per group, read from top to bottom:

- **Course score** and its band, with any pause the academic calendar has coming up.
- **Group score** for the class.
- **Effective** feedback time in working hours, the **perceived** wait in calendar days, and the share answered within the target time (**Within target**), a reference for the indicators rather than a contractual commitment.
- **Last 14 days**: the trend, faster or slower than before.
- **Waiting, Attention, Priority**: how many submissions sit in each band of waiting time.
- **Activities**: each assignment's open and due dates for the group. A teacher who can manage overrides gets a link to give the group dates of its own.
- **Peer context**: the group's score next to the median of every group on the site and the top 10%.
- **Open pending list**: the course report below, filtered to the group.

</td>
</tr>
</table>

### Course report

![Pending grading report for one course: score with within-target chips, the last 30 academic days, distribution by status and the list of submissions waiting](docs/screenshots/course-report.png)

The pending-grading report for one course or group. The score card adds how many submissions were answered within the goal and how many are at risk or critical; the strip of the last 30 academic days shows which days met the goal and which were paused (weekends, holidays, recesses). The status bands filter the table, which lists every submission still waiting, longest wait first, with its effective and perceived time and a **Grade** button. **Graded** switches the table to the work already answered.

## What counts as a response

The clock stops when the feedback **reaches the student**, not when a teacher types it. Two things follow from that, and both are worth knowing before you read the numbers.

**Grading in the gradebook counts.** A mark entered straight into the grader report, single view, or a grade import closes the clock just as marking inside the assignment does — the student sees it either way. Whichever came first is the one recorded, and it is never taken back: deleting the grade afterwards does not re-open a response the student already received. Rows answered this way carry a **"Graded in gradebook"** tag on the pending report, because the assignment's own grading screen shows nothing that would explain them.

**A hidden grade has not reached anybody.** If the gradebook hides the grade — the item hidden, or a *hidden until* date still in the future — the student sees no grade, no feedback, and gets no notification. So a grade entered in the gradebook while hidden does not count as a response at all.

There is one exception, and it is deliberate: **a mark made inside the assignment still stops the clock even while the gradebook hides it.** That is how the plugin has always behaved, and changing it would move figures that have already been reported. Instead those rows are flagged on the pending report with a **"Hidden from student"** tag telling you the grade still needs to be released. If your courses hold results back by hiding a column, expect to see that tag — it is pointing at real work left to do, not at an error.

## Requirements

- Moodle 4.5 (this branch, `MOODLE_405_STABLE`; `main` and `MOODLE_503_STABLE` are the Moodle 5.3 release, `MOODLE_502_STABLE` the 5.2 one, `MOODLE_501_STABLE` the 5.1 one)
- PHP 8.1 or later
- PostgreSQL or MariaDB, at the versions Moodle 4.5 requires (PostgreSQL 13, MariaDB 10.6.7); the plugin is tested on those two
- No other plugin: the block reads `mod_assign` and the gradebook, both part of core

## Installation

1. Copy the plugin into `<moodle>/blocks/feedback_tracker`.
2. Visit *Site administration → Notifications* (or run `php admin/cli/upgrade.php`) to complete the installation.
3. Review the settings under *Site administration → Plugins → Blocks → Feedback Flow* (see *Settings* below). The **Calendar behaviour** section chooses which pauses apply (weekends, holidays, recesses, business hours) and the time zone; the days, weekly hours and pause windows themselves are set in the **Calendar editor**, linked under *Tools* on the same page.

## Getting started

1. Turn editing on in a course and add the **Feedback Flow** block.
2. Teachers in that course open their dashboard from the block to see scores, priorities, and the pending-grading report.
3. (Optional) Fine-tune the academic calendar and the scoring weights in the admin settings.

## Settings

All settings live under *Site administration → Plugins → Blocks → Feedback Flow* and are stored as `block_feedback_tracker/<name>`. Changing one that the figures depend on re-queues every course's summary for recomputation.

- **Scoring**: the five score weights `weight_compliance` (0.40), `weight_median` (0.25), `weight_critical` (0.15), `weight_pending` (0.10) and `weight_trend` (0.10), rescaled at read time when their sum is not close to 1; the goal `sla_goal_hours` (24 effective hours) or `sla_goal_days` (2 business days); the waiting-time bands `bucket_thresholds_eff` (24, 48, 120 hours) or `bucket_thresholds_days` (2, 5, 10 days); and the score bands `score_thresholds_band` (90, 70, 40).
- **Calendar behaviour**: `excludeweekends`, `excludeholidays`, `excluderecesses` and `enablebusinesshours` (all on), `weekendmask` (Saturday and Sunday), `timezone` (the server's) and `grading_during_pause_mode` (clipped: time inside a pause never counts).
- **Processing scope**: `process_hidden_courses` (off), `backfill_active` (off: when on, submissions made before the block was added are measured too) and `backup_ledger` (`rederive`: see *Backup and restore*).
- **Performance**: batch sizes and time caps of the background tasks (`recompute_batch_size`, `pending_batch_size`, `drain_time_cap_seconds`, `backfill_chunk`, `backfill_chunk_per_course`, `backfill_sub_chunk`, `reconcile_batch_size`, `reconcile_time_cap_seconds`, `retention_batch_size`), the recent-statistics window `trend_window_days` (30), `purge_inactive_after_days` (730) and `retention_days` (365).
- **Views**: `enable_admin_view_all` (off), `enable_teacher_simulator` (off), `show_perceived_time`, `show_paused_today_indicator`, `show_peer_context` and `exclude_grader_submissions` (on), `release_stops_clock` (off), `reconcile_active` (on), `retention_active` (off), `removal_cleanup_active` (off), `removal_grace_follow_recyclebin` (on), `removal_grace_seconds` (7 days), `display_time_unit` (business hours) and the group card's `group_title_fields` and `group_subtitle_fields` (empty).
- **Tools**: links to the calendar editor, the recompute audit log, the bulk block removal and the data reset pages.

## Performance: Redis and read-only sessions

The teacher dashboard and the course report each start three or four web service calls at once when they load.
Every one of them is a read declared `readonlysession`, but core honours that only when config.php sets
`$CFG->enable_read_only_sessions = true;`. Without it each call holds the viewer's session lock, so the calls answer
one after another: three calls of 2 to 12 ms of work finished 130, 240 and 360 ms after they started. With it they
run side by side.

Core refuses to start a session with the flag set while any cache definition in session mode is kept in the session
store, which is where a default installation keeps them (this plugin's `dashboard_payload` among them). Moving the
cache stores to Redis first is what makes the flag possible:

1. Add a Redis store instance under *Site administration > Plugins > Caching > Configuration* and make it the
   default store for the **application** and **session** modes (or map each session-mode definition to it).
2. Then add `$CFG->enable_read_only_sessions = true;` to config.php. It is not an admin setting.

*Site administration > Reports > Performance overview* shows a **Read-only sessions** check that warns while the
flag is off.

Measured on a development site (500 courses, 10,000 students, 470,000 submissions; Redis session handler; browser at
4x CPU slowdown), as the time until the last of a page's parallel calls had answered, two rounds each:

| Page | Default cache stores, flag off | Redis cache stores, flag off | Redis cache stores, flag on |
|---|---|---|---|
| Course report (3 calls) | 365 / 357 ms | 357 / 458 ms | **61 / 75 ms** |
| Teacher dashboard, 10 courses (3 calls) | 359 / 351 ms | 347 / 348 ms | **54 / 57 ms** |
| Teacher dashboard, 500 courses (3 calls) | 969 / 992 ms | 1,015 / 869 ms | **612 / 613 ms** |

Redis alone changes nothing on these loads, because the session lock dominates; Redis with the flag makes them
about six times quicker. On the 500-course dashboard what remains is the grader priority list's own work on the
server, about 500 ms.

## Capabilities

| Capability | Context | Given by default to | What it allows |
|---|---|---|---|
| `block/feedback_tracker:addinstance` | Course | Editing teacher, manager | Add the block to a course |
| `block/feedback_tracker:myaddinstance` | Course | Authenticated user | Add the block to the Dashboard (the block offers itself on course pages only) |
| `block/feedback_tracker:viewresponsiveness` | Course | Teacher, editing teacher, manager | See the block's figures, the pending-grading report and the group drill-down of a course |
| `block/feedback_tracker:viewdashboard` | Course | Teacher, editing teacher, manager | Open the teacher dashboard and the score simulator, over the courses where the user holds it |
| `block/feedback_tracker:viewalldata` | System | Nobody | See every course and group on the teacher dashboard |
| `block/feedback_tracker:viewschoolcomparison` | System | Manager | See the site-wide benchmarks on the dashboard |
| `block/feedback_tracker:managecalendar` | System | Manager | Edit the academic calendar (days and business hours) |
| `block/feedback_tracker:managepausewindows` | System | Manager, editing teacher | Add and remove pause windows, checked in the window's own context |
| `block/feedback_tracker:resetdata` | System | Manager | Erase every measurement (the data reset) |
| `block/feedback_tracker:bulkmanageblocks` | System | Manager | Remove the block from many courses at once |
| `block/feedback_tracker:viewaudit` | System | Manager | Read the recompute audit log |

## Data stored

The plugin reads `mod_assign` submissions, grades and marker allocations and keeps what it measured in its own tables:

| Table | One row is | Personal data | Kept until |
|---|---|---|---|
| `block_feedback_tracker_sub` | One measurement cycle of a submission: course, group, activity, attempt, status, the submission, marking, release and grading times, the allocated marker and the waiting and effective time | The student (`userid`) and the allocated marker (`allocmarkerid`) | The course, the activity or the submission goes, the student is no longer an active participant of the course (checked every two hours), or the student's account is deleted. With `retention_active` on, graded rows older than `retention_days` (365 by default) are deleted every night; pending rows never are |
| `block_feedback_tracker_group` | The summary of one course group: counts, medians, compliance, score and band | None | The course is deleted |
| `block_feedback_tracker_trend` | One day of one course group: median time, graded count, compliance | None | The course is deleted, or the day falls outside `retention_days` with `retention_active` on |
| `block_feedback_tracker_site` | One day of the whole site: medians, percentiles, compliance | None | The day falls outside `retention_days` with `retention_active` on |
| `block_feedback_tracker_queue` | A course group waiting to be recomputed | None | Recomputed, within five minutes |
| `block_feedback_tracker_cday` | A calendar exception: holiday, recess, closure or optional day | The administrator who last edited it (`usermodified`) | Removed in the calendar editor, or its date is older than `purge_inactive_after_days` (730) |
| `block_feedback_tracker_chours` | One weekly business-hours slot | The administrator who last edited it (`usermodified`) | Replaced in the calendar editor |
| `block_feedback_tracker_cpause` | A manual pause window of the site, a course or a group | The user who last edited it (`usermodified`) | Removed in the calendar editor, or it ended more than `purge_inactive_after_days` ago |
| `block_feedback_tracker_log` | One recompute: reason, rows affected, start and end | The user who triggered it (`triggeredby`) | 90 days |
| `block_feedback_tracker_bfcursor` | How far the history backfill has read one course | None | The course is deleted |

Removing the block from a course keeps that course's rows unless `removal_cleanup_active` is on; then they are deleted after the grace period (`removal_grace_seconds`, or the recycle bin's retention). The data reset (`pages/reset.php`, `cli/reset.php`) deletes every measurement table and keeps the calendar and the audit log. The plugin also stores two user preferences, `block_feedback_tracker_dashboard_collapsed` and `block_feedback_tracker_report_collapsed` (whether the dashboard's and the report's top panels are collapsed).

Everything above is covered by the Privacy API. A data request exports, per course, the user's submission cycles and the cycles where they were the allocated marker, and, at site level, the calendar rows and recomputes they are recorded against, plus both preferences. A deletion request deletes the student's cycles; for a marker it clears `allocmarkerid`, keeping the students' rows; for the calendar and the audit log it clears the user id and keeps the row. The course summaries hold no user and are recomputed from what remains.

Opening a submission from the dashboard or the report may clear the viewer's own saved filters on the assignment's grading page (status, workflow, marker and name initial), when they would hide that student; those preferences belong to `mod_assign`.

## Backup and restore

What a course backup carries is the `backup_ledger` setting:

- **`rederive`** (default): the backup carries nothing of the plugin. Once the course is restored, an adhoc task (`rederive_course`) rebuilds its measurements in the background from the restored submissions and grades. What Moodle itself does not store cannot be rebuilt: when feedback was released, when a marker was allocated, the cycles a resubmission superseded and the rows taken out with the legacy dismissal.
- **`full`**: backups that include user data also carry every row of `block_feedback_tracker_sub` for the course. The restore maps them to the restored activities, students, groups and markers, leaves out the rows of anything not restored, and then runs the same rebuild for whatever the file did not hold. Backups without user data, course imports among them, carry no rows.

A restore follows what the backup file holds, not the setting at the time of the restore. The block must be restored with the course for anything to be measured there.

The cost, measured on Moodle 5.3 with PostgreSQL on a course of 300 students and 10 assignments (3,000 measurement rows): `full` made the backup file 220 KiB instead of 119 KiB and added about 1.5 s to the backup (7.9 s against 6.3 s) and 1.9 s to the restore (7.7 s against 5.8 s). The rebuild runs in cron afterwards in either mode and took about 7 s.

## Translations

The English strings ship in the package. The Brazilian Portuguese translation is maintained in this repository (`lang/pt_br`) and reaches sites through [AMOS](https://lang.moodle.org/), as the plugins directory requires; it is left out of the release package.

## License

GNU GPL v3 or later.
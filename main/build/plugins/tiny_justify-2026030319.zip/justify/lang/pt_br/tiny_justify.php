<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Brazilian Portuguese language strings for tiny_justify.
 *
 * @package    tiny_justify
 * @copyright  2026 CTE-ZL IFRN
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['aligncenter'] = 'Centralizar';
$string['alignjustify'] = 'Justificar';
$string['alignleft'] = 'Alinhar à esquerda';
$string['alignmenu'] = 'Alinhar';
$string['alignright'] = 'Alinhar à direita';
$string['helplinktext'] = 'Justificar';
$string['pluginname'] = 'Justificar';
$string['alignjustifymenu'] = 'Justificar texto';
$string['privacy:metadata'] = 'O plugin tiny_justify não armazena nenhum dado pessoal.';

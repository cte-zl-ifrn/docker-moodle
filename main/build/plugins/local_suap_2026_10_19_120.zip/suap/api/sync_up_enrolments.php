<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

namespace local_suap;

// Desabilita verificação CSRF para esta API
if (!defined('NO_MOODLE_COOKIES')) {
    define('NO_MOODLE_COOKIES', true);
}

require_once(\dirname(\dirname(\dirname(__DIR__))) . '/config.php');

global $CFG;
require_once($CFG->dirroot . '/course/lib.php');
require_once($CFG->dirroot . '/user/lib.php');
require_once($CFG->dirroot . '/cohort/lib.php');
require_once($CFG->dirroot . '/user/profile/lib.php');
require_once($CFG->dirroot . '/group/lib.php');
require_once($CFG->dirroot . '/lib/enrollib.php');
require_once($CFG->dirroot . '/enrol/locallib.php');
require_once($CFG->dirroot . '/enrol/externallib.php');
require_once($CFG->dirroot . '/local/suap/locallib.php');
require_once($CFG->dirroot . '/local/suap/classes/Jsv4/Validator.php');
require_once($CFG->dirroot . '/local/suap/api/servicelib.php');


function getattr($obj, $prop, $default = '') {
    $result = property_exists($obj, $prop) ? $obj->$prop : $default;
    return $result !== null ? $result : $default;
};

class sync_up_enrolments_service extends service {
    /** Domínio do e-mail de fallback (mesmo do auth_suap) para usuários sem e-mail no SUAP. */
    const PLACEHOLDER_EMAIL_DOMAIN = 'sem-email.invalid';
    public $json;
    private $result = [];
    private $cursoCategory;
    private $turmaCategory;
    private $context;
    private $course;
    private $coordenacao;
    private $isCoordination;
    private $roles_mapping;
    private $default_user_preferences;
    private $auths_mapping;
    private $usuarios_sincronizados = [];
    private $alunos_sincronizados = [];
    private $ids_suspensos = [];
    private $falhas_matricula = [];
    private $inBackground = false;


    function do_call() {
        global $DB, $CFG;

        $jsonstring = file_get_contents('php://input');

        $this->validate_json($jsonstring);
        $id = $DB->insert_record(
            "suap_enrolment_to_sync",
            (object)['json' => $jsonstring, 'timecreated' => time(), 'processed' => 0]
        );
        \local_suap\audit\context::set('api:suap', "suap_enrolment_to_sync:$id");
        $result = $this->process(false);

        $task = new \local_suap\task\sync_up_enrolments_task();
        $task->set_custom_data(['id' => $id]);
        $taskid = \core\task\manager::queue_adhoc_task($task);

        $DB->update_record('suap_enrolment_to_sync', (object) ['id' => $id, 'taskid' => $taskid]);

        $result['sincronizacao_url'] = "{$CFG->wwwroot}/local/suap/admin/view.php?id=$id";
        return $result;
    }


    function validate_json($jsonstring) {
        global $CFG;

        $this->json = json_decode($jsonstring);

        if (!$this->json) {
            throw new \Exception("Erro ao decodificar o JSON, favor corrigir.");
        }
    }


    function process($inBackground) {
        $this->result = [
            "url" => null,
            "url_sala_coordenacao" => null,
            "ids_suspensos" => [],
            "logMessages" => [],
        ];
        $this->inBackground = $inBackground || getattr($this->json, 'sincrono', false);

        $this->sync_log("SINCRONIZANDO AO NÍVEL DO SISTEMA", 0);

        // Sincronização ao nível do sistema
        $this->sync_categories();
        $this->sync_users();
        $this->sync_cohorts();

        // Sincronização ao nível da sala
        foreach ([true, false] as $isCoordination) {
            $this->isCoordination = $isCoordination;
            $this->sync_course($isCoordination ? $this->cursoCategory->id : $this->turmaCategory->id);
            $this->sync_enrols_cohorts();
            if ($this->inBackground || getattr($this->json, 'sincrono', false)) {
                $this->sync_enrols_manuals();
                $this->sync_enrolments();
                $this->sync_groups();
                if ($this->get_sala_tipo() == 'diarios') {
                    $this->suspend_students_not_in_list_all_enrols();
                }
            }
        }
        $this->result["ids_suspensos"] = array_unique($this->ids_suspensos);

        if (!empty($this->falhas_matricula)) {
            throw new \Exception(
                "Sincronização concluída com " . count($this->falhas_matricula) . " falha(s) de matrícula/papel: "
                    . implode('; ', $this->falhas_matricula)
            );
        }

        return $this->result;
    }


    private function sync_log(string $message, int $code) {
        $logMessage = ($code != 0 ? "\nERROR {$code}: $message" : "\nINFO: $message");
        $this->result['logMessages'][] = $logMessage;
        if ($this->inBackground && (defined('CLI_SCRIPT') && CLI_SCRIPT)) {
            echo $logMessage;
            return;
        }
        if ($code != 0) {
            throw new \Exception($message, $code);
        }
    }


    function get_course_enrol_instance_by_enrol_type($enrol_type) {
        global $DB;
        foreach (\enrol_get_instances($this->course->id, true) as $instance) {
            if ($instance->enrol === $enrol_type) {
                return $instance;
            }
        }
        if (!$enrol_plugin = \enrol_get_plugin($enrol_type)) {
            return null;
        }
        $instance_id = $enrol_plugin->add_instance($this->course);
        return $DB->get_record('enrol', ['id' => $instance_id]);
    }


    function is_user_enrolled_in_role($user, $enrol_instance, $role): bool {
        global $DB;

        $sql = "
            SELECT      COUNT(*)
            FROM        {user_enrolments}                   ue
                            JOIN {enrol}                    e   ON (ue.enrolid  = e.id)
                                JOIN {context}              ctx ON (e.courseid  = ctx.instanceid AND ctx.contextlevel   = 50)
                                    JOIN {role_assignments} ra  ON (ctx.id      = ra.contextid   AND ue.userid          = ra.userid)
            WHERE       ue.userid         = :userid
              AND       ue.enrolid        = :enrolid
              AND       e.courseid        = :courseid
              AND       ra.roleid         = :roleid
              AND       ue.status         = 0
              AND       e.status          = 0
        ";

        $params = [
            'userid' => $user->id,
            'enrolid' => $enrol_instance->id,
            'courseid' => $enrol_instance->courseid,
            'roleid' => $role->id,
        ];
        return (int) $DB->get_field_sql($sql, $params) > 0;
    }


    function get_sala_tipo() {
        // Acessa restricoes do objeto (com check se existe)
        $restricoes = isset($this->json->turma->restricoes) ? $this->json->turma->restricoes : null;
        $this->result["restricoes"] = trim(strval($restricoes));
        $this->result["sala_tipo"] = match (true) {
            $this->isCoordination => 'coordenacoes',
            !empty($this->result["restricoes"]) => 'autoinscricoes',
            isset($this->json->curso->praticas) && !empty($this->json->curso->praticas) => 'praticas',
            isset($this->json->curso->modelos) && !empty($this->json->curso->modelos) => 'modelos',
            default => 'diarios',
        };

        return $this->result["sala_tipo"];
    }

    function get_componente_tipo() {
        /* 1:Regular, 2:Seminário, 3:Prática Profissional, 4:Trabalho de Conclusão de Curso, 5:Atividade de Extensão, 6:Prática como Componente Curricular, 7:Visita Técnica / Aula da Campo, 8:Componentes Extracurriculares */
        $tipo = getattr($this->json->componente, 'tipo', '1');
        return match (true) {
            $tipo == '1' => 'Regular',
            $tipo == '2' => 'Seminário',
            $tipo == '3' => 'Prática Profissional',
            $tipo == '4' => 'Trabalho de Conclusão de Curso',
            $tipo == '5' => 'Atividade de Extensão',
            $tipo == '6' => 'Prática como Componente Curricular',
            $tipo == '7' => 'Visita Técnica / Aula da Campo',
            $tipo == '8' => 'Componentes Extracurriculares',
            default => 'Regular',
        };
    }


    function get_course_and_customfields_by_idnumber(string $courseidnumber) {
        global $DB, $CFG;
        require_once("$CFG->dirroot/course/lib.php");

        $course = $DB->get_record('course', ['idnumber' => $courseidnumber], '*');
        if (!$course) {
            return null;
        }

        $mappedfields = (array)$course;
        foreach (\core_customfield\handler::get_handler('core_course', 'course')->get_instance_data($course->id) as $d) {
            $mappedfields["customfield_{$d->get_field()->get('shortname')}"] = $d->get_value();
        }

        return (object)$mappedfields;
    }


    function getIdDosAlunosFaltandoAgrupar($group, $alunos) {
        global $DB;
        $alunoIds = [];
        foreach ($alunos as $aluno) {
            $user = $this->usuarios_sincronizados[$aluno->username] ?? null;
            if ($user) {
                $alunoIds[] = $user->id;
            }
        }
        if (empty($alunoIds)) {
            return [];
        }
        [$insql, $inparams] = $DB->get_in_or_equal($alunoIds);
        $sql = "SELECT userid FROM {groups_members} WHERE groupid = ? and userid $insql";
        $ja_existem = $DB->get_records_sql($sql, array_merge([$group->id], $inparams));
        return array_map(function ($x) {
            return $x->userid;
        }, $ja_existem);
    }


    function parse_auths_mapping() {
        $this->auths_mapping = [];
        foreach (explode("\n", config('auths_mapping')) as $mapping_line) {
            $parts = array_map('trim', explode(':', $mapping_line));
            if (count($parts) === 2) {
                [$papel_suap, $auth] = $parts;
                $this->auths_mapping[$papel_suap] = $auth;
            }
        }
    }


    function sync_categories() {

        $ano_periodo = substr($this->json->turma->codigo, 0, 4) . "." . substr($this->json->turma->codigo, 4, 1);

        $this->sync_log("  Categorias a sincrizar: 5.", 0);

        $diarioCategory = $this->sync_category(
            config('top_category_idnumber') ?: 'diarios',
            config('top_category_name') ?: 'Diários',
            config('top_category_parent') ?: 0
        );

        $campusCategory = $this->sync_category(
            $this->json->campus->sigla,
            $this->json->campus->descricao,
            $diarioCategory->id
        );

        $this->cursoCategory = $this->sync_category(
            $this->json->curso->codigo,
            $this->json->curso->nome,
            $campusCategory->id
        );

        $semestreCategory = $this->sync_category(
            "{$this->json->curso->codigo}.{$ano_periodo}",
            $ano_periodo,
            $this->cursoCategory->id
        );

        $this->turmaCategory = $this->sync_category(
            $this->json->turma->codigo,
            $this->json->turma->codigo,
            $semestreCategory->id
        );
    }

    function sync_category($idnumber, $name, $parent) {
        global $DB;
        $this->sync_log("    Categoria " . $idnumber . " será sincronizada. ", 0);
        $category = $DB->get_record('course_categories', ['idnumber' => $idnumber]);
        if (empty($category)) {
            $category = \core_course_category::create(['name' => $name, 'idnumber' => $idnumber, 'parent' => $parent]);
        }
        return $category;
    }


    function sync_users() {
        $this->default_user_preferences = array_map(
            fn($line) => explode('=', trim($line), 2),
            array_filter(
                preg_split('/[\r\n]+/', config('default_user_preferences'), -1, PREG_SPLIT_NO_EMPTY),
                fn($line) => count(explode('=', trim($line), 2)) === 2
            )
        );

        $this->parse_auths_mapping();

        if (isset($this->json->alunos)) {
            foreach ($this->json->alunos as $aluno) {
                $aluno->username = strtolower($aluno->matricula);
                $aluno->tipo_usuario = "Aluno";
            }
        }
        if (isset($this->json->professores)) {
            foreach ($this->json->professores as $professor) {
                $professor->username = strtolower($professor->login);
                $professor->tipo_usuario = $professor->tipo;
            }
        }
        if (isset($this->json->coortes)) {
            foreach ($this->json->coortes as $coorte) {
                foreach (getattr($coorte, 'colaboradores', []) as $colaborador) {
                    $colaborador->username = strtolower($colaborador->login);
                }
            }
        }
        if (isset($this->json->equipe)) {
            foreach ($this->json->equipe as $membro) {
                $membro->username = strtolower($membro->login);
                $membro->tipo_usuario = getattr($membro, 'tipo', 'Equipe');
            }
        }

        $professores = getattr($this->json, 'professores', []);
        $equipe = getattr($this->json, 'equipe', []);

        $coortes_colaboradores = [];
        $coortes = getattr($this->json, 'coortes', []);
        if (is_array($coortes)) {
            foreach ($coortes as $coorte) {
                if (is_object($coorte) && isset($coorte->colaboradores) && is_array($coorte->colaboradores)) {
                    $coortes_colaboradores = array_merge($coortes_colaboradores, $coorte->colaboradores);
                }
            }
        }

        $equipe_denormalizada = array_merge($coortes_colaboradores, $professores, $equipe);

        $equipe_completa = array_values(array_reduce(
            $equipe_denormalizada,
            function ($carry, $usuario) {
                $username = $usuario->username;
                if (!isset($carry[$username])) {
                    $carry[$username] = $usuario;
                }
                return $carry;
            },
            []
        ));

        $usuarios = $this->inBackground ? array_merge($equipe_completa, getattr($this->json, 'alunos', [])) : $equipe_completa;
        $this->sync_log("  Usuários a sincronizar: " . count($usuarios), 0);
        foreach ($usuarios as $usuario) {
            $this->sync_user($usuario);
            $this->sync_profile_custom_fields($usuario);
        }
    }


    /**
     * Resolve o e-mail do usuário; a API do SUAP devolve "" (não null) quando não há e-mail.
     * Sem e-mail algum, retorna ''.
     *
     * @param object $usuario Dados do usuário vindos do SUAP.
     * @return string
     */
    function resolve_email($usuario): string {
        foreach (['email_preferencial', 'email', 'email_secundario', 'email_google_classroom', 'email_academico'] as $prop) {
            $value = getattr($usuario, $prop);
            if (is_string($value) && trim($value) !== '') {
                return trim($value);
            }
        }
        return '';
    }

    function sync_user($usuario) {
        global $DB;
        if (in_array($usuario->username, array_keys($this->usuarios_sincronizados))) {
            return;
        }
        $this->sync_log("    Usuário " . $usuario->username . " será sincronizado. ", 0);
        $nome_parts = explode(' ', getattr($usuario, 'nome', getattr($usuario, 'nome_completo')));
        $tipo = getattr($usuario, 'tipo_usuario', getattr($usuario, 'tipo', 'Aluno'));

        $insert_only = [
            'username' => $usuario->username,
            'password' => '!aA1' . uniqid(),
            'timezone' => '99',
            'confirmed' => 1,
            'mnethostid' => 1,
            'suspended' => 0,
            'lang' => '',
        ];
        $insert_or_update = [
            'firstname' => implode(' ', array_slice($nome_parts, 0, -1)),
            'lastname' => end($nome_parts),
            'auth' => isset($this->auths_mapping[$tipo]) ? $this->auths_mapping[$tipo] : config('default_auth'),
        ];
        $email = $this->resolve_email($usuario);

        $user = $DB->get_record("user", ["username" => $usuario->username]);
        if ($user) {
            // Sem e-mail no SUAP, preserva o já cadastrado em vez de apagá-lo.
            if ($email !== '') {
                $insert_or_update['email'] = $email;
            }
            \local_suap\audit\writer::update_user((object) array_merge(['id' => $user->id], $insert_or_update));
        } else {
            $insert_or_update['email'] = $email !== '' ? $email : $usuario->username . '@' . self::PLACEHOLDER_EMAIL_DOMAIN;
            \local_suap\audit\writer::create_user((object) array_merge($insert_or_update, $insert_only));
            $user = $DB->get_record("user", ["username" => $usuario->username]);
            foreach ($this->default_user_preferences as $parts) {
                \local_suap\audit\writer::set_preference($parts[0], $parts[1], $user);
            }
        }
        $this->usuarios_sincronizados[$usuario->username] = $user;
    }


    function sync_cohorts() {
        global $DB;

        if (isset(($this->json->coortes))) {
            $this->sync_log("  Coortes a sincronizar: " . count($this->json->coortes), 0);
            foreach ($this->json->coortes as $coorte) {
                $this->sync_log("    Coorte '" . $coorte->nome . "' será sincronizada.", 0);
                $cohort = $DB->get_record('cohort', ['idnumber' => $coorte->idnumber]);
                if (!$cohort) {
                    $cohort = (object)[
                        "name" => $coorte->nome,
                        "idnumber" => $coorte->idnumber,
                        "description" => $coorte->descricao,
                        "visible" => $coorte->ativo,
                        "contextid" => 1,
                    ];
                    $cohort->id = \cohort_add_cohort($cohort);
                } else {
                    $cohort->name = $coorte->nome;
                    $cohort->idnumber = $coorte->idnumber;
                    $cohort->description = $coorte->descricao;
                    $cohort->visible = $coorte->ativo;
                    \cohort_update_cohort($cohort);
                }

                foreach ($coorte->colaboradores as $usuario) {
                    $user = $this->usuarios_sincronizados[$usuario->username];
                    if (!$user) {
                        $this->sync_log("      Usuário '{$usuario->username}' não encontrado para adicionar à coorte '{$coorte->nome}'.", 533);
                        continue;
                    }
                    $this->sync_log("      Usuário '" . $user->username . "' será add à coorte '" . $cohort->name . "'. ", 0);
                    \cohort_add_member($cohort->id, $user->id);
                }
                $coorte->cohort = $cohort;
            }
        }
    }


    function sync_profile_custom_fields($usuario) {
        $campus = getattr($this->json, 'campus', (object)[]);
        $curso = getattr($this->json, 'curso', (object)[]);
        $modalidade = getattr($curso, 'modalidade', (object)[]);
        $nivel_ensino = getattr($modalidade, 'nivel_ensino', (object)[]);
        $turma = getattr($this->json, 'turma', (object)[]);
        $polo = getattr($usuario, 'polo', (object)[]);
        $tipo_doc_certificado = getattr($usuario, 'cpf') == '' ? 'passaporte' : 'cpf';

        $custom_fields = [
            // SUAP
            'tipo_usuario' => getattr($usuario, 'tipo_usuario'),
            'eh_servidor' => getattr($usuario, 'eh_servidor', strlen($usuario->username) < 11 ? true : false),
            'eh_aluno' => getattr($usuario, 'eh_aluno', strlen($usuario->username) > 11 ? true : false),
            'eh_prestador' => getattr($usuario, 'eh_prestador', strlen($usuario->username) == 11 ? true : false),
            'eh_usuarioexterno' => getattr($usuario, 'eh_usuarioexterno', strlen($usuario->username) == 11 ? true : false),
            'eh_docente' => getattr($usuario, 'eh_docente'),
            'eh_tecnico_administrativo' => getattr($usuario, 'eh_tecnico_administrativo'),

            // Dados pessoais
            'nome_apresentacao' => getattr($usuario, 'nome_usual'),
            'nome_completo' => getattr($usuario, 'nome_registro'),
            'nome_social' => getattr($usuario, 'nome_social'),
            'data_de_nascimento' => getattr($usuario, 'data_de_nascimento'),
            'sexo' => getattr($usuario, 'sexo'),
            'cpf' => getattr($usuario, 'cpf'),
            'passaporte' => getattr($usuario, 'passaporte'),
            'tipo_doc_certificado' => $tipo_doc_certificado,
            'id_doc_certificado' => getattr($usuario, $tipo_doc_certificado),
            'eh_estrangeiro' => getattr($usuario, 'eh_estrangeiro'),

            // Dados de contato
            'email_google_classroom' => getattr($usuario, 'email_google_classroom'),
            'email_academico' => getattr($usuario, 'email_academico'),
            'email_secundario' => getattr($usuario, 'email_secundario'),

            // Matrícula
            'programa_nome' => getattr($usuario, 'programa', "Institucional"),
            'ingresso_periodo' => getattr($usuario, 'ingresso_periodo'),
            'outras_matriculas' => json_encode(getattr($usuario, 'outras_matriculas', [])),

            // Polo
            'polo_id' => getattr($polo, 'id'),
            'polo_sigla' => getattr($polo, 'sigla'),
            'polo_nome' => getattr($polo, 'descricao'),

            // Campus
            'campus_id' => getattr($campus, 'id'),
            'campus_descricao' => getattr($campus, 'descricao'),
            'campus_sigla' => getattr($campus, 'sigla'),

            // Curso
            'curso_id' => getattr($curso, 'id'),
            'curso_codigo' => getattr($curso, 'codigo'),
            'curso_descricao' => getattr($curso, 'nome'),
            'curso_modalidade_id' => getattr($modalidade, 'id'),
            'curso_modalidade_descricao' => getattr($modalidade, 'descricao'),
            'curso_nivel_ensino_id' => getattr($nivel_ensino, 'id'),
            'curso_nivel_ensino_descricao' => getattr($nivel_ensino, 'descricao'),

            // Turma
            'turma_id' => getattr($turma, 'id'),
            'turma_codigo' => getattr($turma, 'codigo'),
        ];

        // Filtra apenas campos com conteúdo
        $custom_fields = array_filter($custom_fields, function ($v) {
            return $v !== '';
        });

        $user = $this->usuarios_sincronizados[$usuario->username];
        \local_suap\audit\writer::save_profile_fields((int) $user->id, $custom_fields);
    }


    function sync_course($categoryid) {
        global $CFG;

        $course_code = $this->isCoordination ? "{$this->json->campus->sigla}.{$this->json->curso->codigo}" : "{$this->json->turma->codigo}.{$this->json->componente->sigla}";
        $course_code_long = $this->isCoordination ? $course_code : "{$course_code}#{$this->json->diario->id}";
        $modalidade = getattr($this->json->curso, 'modalidade', (object)[]);
        $nivelensino = getattr($modalidade, 'nivel_ensino', (object)[]);
        $tipo_course = $this->isCoordination ? "SALA DE COORDENAÇÃO" : "DIÁRIO";

        $this->sync_log("SINCRONIZANDO AO NÍVEL DO CURSO $tipo_course ($course_code_long).", 0);

        $data = [
            "category" => $categoryid,
            "fullname" => $this->isCoordination ? "Sala de coordenação do curso {$this->json->curso->nome}" : $this->json->componente->descricao,
            "shortname" => $course_code_long,
            "idnumber" => $course_code_long,

            /* Fixo */
            "customfield_curso_sala_coordenacao" => $this->isCoordination ? 'Sim' : 'Não',
            "visible" => 0,
            "enablecompletion" => 1,
            // "startdate"=>time(),
            "showreports" => 1,
            "completionnotify" => 1,

            /* Obrigatório - Painel AVA */
            "customfield_sala_tipo" => $this->get_sala_tipo(),
            "customfield_turma_autoinscricao" => $this->isCoordination ? '' : (getattr($this->json->turma, 'autoinscricao') == 'true' ? '1' : '0'),
            "customfield_restricoes_de_autoinscricao" => getattr($this->json->turma, 'restricoes', ''),

            /* Obrigatórios - Campus */
            "customfield_campus_id" => $this->json->campus->id,
            "customfield_campus_sigla" => $this->json->campus->sigla,
            "customfield_campus_descricao" => $this->json->campus->descricao,

            /* Obrigatórios - Curso */
            "customfield_curso_id" => $this->json->curso->id,
            "customfield_curso_codigo" => $this->json->curso->codigo,
            "customfield_curso_nome" => $this->json->curso->nome,

            /* Opcionais - Curso */
            "customfield_curso_descricao" => getattr($this->json->curso, 'descricao'),
            "customfield_curso_descricao_historico" => getattr($this->json->curso, 'descricao_historico'),
            "customfield_curso_titulo_certificado_masculino" => getattr($this->json->curso, 'titulo_certificado_masculino'),
            "customfield_curso_titulo_certificado_feminino" => getattr($this->json->curso, 'titulo_certificado_feminino'),
            "customfield_curso_ch_total" => getattr($this->json->curso, 'ch_total'),
            "customfield_curso_ch_aula" => getattr($this->json->curso, 'ch_aula'),
            "customfield_curso_autoinstrucional" => getattr($this->json->curso, 'autoinstrucional') == 'true' ? '1' : '0',
            "customfield_curso_programa" => getattr($this->json->curso, 'programa'),
            "customfield_curso_modalidade_id" => getattr($modalidade, 'id'),
            "customfield_curso_modalidade_descricao" => getattr($modalidade, 'descricao'),
            "customfield_curso_nivel_ensino_id" => getattr($nivelensino, 'id'),
            "customfield_curso_nivel_ensino_descricao" => getattr($nivelensino, 'descricao'),
            "customfield_curso_conteudo" => json_encode(getattr($this->json->curso, 'conteudo', [])),

            /* Obrigatórios - Componente Curricular */
            "customfield_disciplina_id" => $this->isCoordination ? '' : $this->json->componente->id,
            "customfield_disciplina_sigla" => $this->isCoordination ? '' : $this->json->componente->sigla,
            "customfield_disciplina_descricao" => $this->isCoordination ? '' : $this->json->componente->descricao,

            /* Opcionais - Componente Curricular */
            "customfield_disciplina_descricao_historico" => $this->isCoordination ? '' : getattr($this->json->componente, 'descricao_historico'),
            "customfield_disciplina_periodo" => $this->isCoordination ? '' : getattr($this->json->componente, 'periodo'),
            "customfield_disciplina_tipo" => $this->isCoordination ? '' : $this->get_componente_tipo(),
            "customfield_disciplina_optativo" => $this->isCoordination ? '' : getattr($this->json->componente, 'optativo'),
            "customfield_disciplina_qtd_avaliacoes" => $this->isCoordination ? '' : getattr($this->json->componente, 'qtd_avaliacoes'),
            "customfield_disciplina_is_seminario_estagio_docente" => $this->isCoordination ? '' : getattr($this->json->componente, 'is_seminario_estagio_docente'),
            "customfield_disciplina_ch_presencial" => $this->isCoordination ? '' : getattr($this->json->componente, 'ch_presencial'),
            "customfield_disciplina_ch_pratica" => $this->isCoordination ? '' : getattr($this->json->componente, 'ch_pratica'),
            "customfield_disciplina_ch_extensao" => $this->isCoordination ? '' : getattr($this->json->componente, 'ch_extensao'),
            "customfield_disciplina_ch_pcc" => $this->isCoordination ? '' : getattr($this->json->componente, 'ch_pcc'),
            "customfield_disciplina_ch_visita_tecnica" => $this->isCoordination ? '' : getattr($this->json->componente, 'ch_visita_tecnica'),
            "customfield_disciplina_ch_semanal_1s" => $this->isCoordination ? '' : getattr($this->json->componente, 'ch_semanal_1s'),
            "customfield_disciplina_ch_semanal_2s" => $this->isCoordination ? '' : getattr($this->json->componente, 'ch_semanal_2s'),

            /* Obrigatórios - Turma */
            "customfield_turma_id" => $this->isCoordination ? '' : $this->json->turma->id,
            "customfield_turma_codigo" => $this->isCoordination ? '' : $this->json->turma->codigo,

            /* Opcionais - Turma */
            "customfield_turma_ano_periodo" => $this->isCoordination ? '' : substr(getattr($this->json->turma, 'codigo'), 0, 4) . "." . substr(getattr($this->json->turma, 'codigo'), 4, 1),
            "customfield_turma_data_inicio" => $this->isCoordination ? '' : getattr($this->json->turma, 'data_inicio'),
            "customfield_turma_data_fim" => $this->isCoordination ? '' : getattr($this->json->turma, 'data_fim'),
            "customfield_turma_gerar_matricula" => $this->isCoordination ? '' : getattr($this->json->turma, 'gerar_matricula'),
            "customfield_turma_nota_minima" => $this->isCoordination ? '' : getattr($this->json->turma, 'nota_minima'),
            "customfield_turma_completude_minima" => $this->isCoordination ? '' : getattr($this->json->turma, 'completude_minima'),
            "customfield_turma_modelo_padrao" => $this->isCoordination ? '' : getattr($this->json->turma, 'modelo_padrao'),

            /* Obrigatórios - Diário */
            "customfield_diario_id" => $this->isCoordination ? '' : $this->json->diario->id,

            /* Opcionais - Diário */
            "customfield_diario_tipo" => $this->isCoordination ? '' : getattr($this->json->diario, 'tipo', 'regular'),
            "customfield_diario_situacao" => $this->isCoordination ? '' : getattr($this->json->diario, 'situacao'),
            "customfield_diario_descricao" => $this->isCoordination ? '' : getattr($this->json->diario, 'descricao'),
            "customfield_diario_descricao_historico" => $this->isCoordination ? '' : getattr($this->json->diario, 'descricao_historico'),

            /* Opcionais - URL da sala de coordenação */
            "customfield_url_sala_coordenacao" => $this->isCoordination ? '' : "{$CFG->wwwroot}/course/view.php?id={$this->coordenacao->id}",
        ];

        $this->course = $this->get_course_and_customfields_by_idnumber($course_code_long);
        if (!$this->course) {
            $this->course = create_course((object)$data);
        } else if (!$this->isCoordination) {
            $data['id'] = $this->course->id;
            unset($data['visible']);
            $this->course = (object)$data;
            update_course($this->course);
        }
        $this->context = \context_course::instance($this->course->id);

        $course_url = "{$CFG->wwwroot}/course/view.php?id={$this->course->id}";
        $course_type = $this->isCoordination ? 'url_sala_coordenacao' : 'url';
        $this->result[$course_type] = $course_url;

        if ($this->isCoordination) {
            $this->coordenacao = $this->course;
        }
    }


    function sync_enrols_cohorts() {
        global $DB;

        $enrol_plugin = enrol_get_plugin("cohort");
        $this->sync_log("  Sincronizando enrols do tipo coorte para " . count(getattr($this->json, 'coortes', [])) . " coortes.", 0);
        foreach (getattr($this->json, 'coortes', []) as $coorte) {
            if (!$cohort = $DB->get_record('cohort', ['idnumber' => $coorte->idnumber])) {
                $this->sync_log("    Não localizei a coorte '{$coorte->nome}' ({$coorte->idnumber})", 555);
                continue;
            }
            $coorte_role = strtolower($coorte->role);
            if (!$role = $DB->get_record('role', ['shortname' => $coorte_role])) {
                $this->sync_log("    Não localizei a role({$coorte_role})", 555);
                continue;
            }
            if (!$instance = $DB->get_record('enrol', ["enrol" => "cohort", "customint1" => $cohort->id, "courseid" => $this->course->id])) {
                $enrol_plugin->add_instance($this->course, ["customint1" => $cohort->id, "roleid" => $role->id, "customint2" => 0]);
                $this->sync_log("    Coorte '{$coorte->nome}' ({$coorte->idnumber}): adicionada ao curso. ", 0);
            } else {
                $this->sync_log("    Coorte '{$coorte->nome}' ({$coorte->idnumber}): não precisou ser adicionada. ", 0);
            }
        }
    }


    function sync_enrols_manuals() {
        global $DB;

        $professores = getattr($this->json, 'professores', []);
        $equipe = getattr($this->json, 'equipe', []);
        $staff = array_merge($professores, $equipe);
        $alunos = getattr($this->json, 'alunos', []);
        $sala_tipo = $this->get_sala_tipo();

        $prefixes = [];
        $usuarios = $this->inBackground ? array_merge($staff, $alunos) : $staff;
        $this->sync_log("  Gerando mapeamento de papéis para os tipos de sala e usuários (" . count($usuarios) . ").", 0);
        foreach ($usuarios as $usuario) {
            $papel_suap = getattr($usuario, "tipo_usuario", "Aluno");
            $prefix = "$sala_tipo:$papel_suap";
            $prefixes[$prefix] ??= ["sala_tipo" => $sala_tipo, "papel_suap" => $papel_suap];
            $this->sync_log("    Usuário {$usuario->username} mapeado como $prefix.", 0);
        }

        $mappings = json_decode(config('roles_mapping'));

        $this->sync_log("  Instâncias de enrols (" . count($prefixes) . ") serão sincronizadas.", 0);
        foreach ($prefixes as $prefix => $keys) {
            $sala_tipo = $keys["sala_tipo"];
            $papel_suap = $keys["papel_suap"];
            if (!isset($mappings->$sala_tipo)) {
                $this->sync_log(
                    "    Não localizei mapeamento para salas do tipo '{$sala_tipo}'.",
                    550
                );
                continue;
            }
            if (!isset($mappings->$sala_tipo) || !isset($mappings->$sala_tipo->$papel_suap)) {
                $this->sync_log(
                    "    Nas salas do tipo '{$sala_tipo}' não existe mapeamento para o papel '{$papel_suap}'.",
                    551
                );
                continue;
            }
            $m = $mappings->$sala_tipo->$papel_suap;

            if (!isset($m->role_instance)) {
                if (!$role_instance = $DB->get_record('role', ['shortname' => $m->role])) {
                    $this->sync_log(
                        "Não localizei a role({$m->role}) para $prefix.",
                        552
                    );
                    continue;
                }
                $m->role_instance = $role_instance;
            }

            if (!isset($m->enrol_plugin)) {
                if (!$enrol_plugin = enrol_get_plugin($m->enrol)) {
                    $this->sync_log(
                        "    Não localizei a enrol({$m->enrol}) para $prefix'.",
                        553
                    );
                    continue;
                }
                $m->enrol_plugin = $enrol_plugin;
            }
            if (!isset($m->enrol_instance)) {
                if (!$enrol_instance = $this->get_course_enrol_instance_by_enrol_type($m->enrol)) {
                    $this->sync_log(
                        "    Não consegui criar/recurperar a instância do enrol ({$m->enrol}) para $prefix.",
                        554
                    );
                    continue;
                }
                $m->enrol_instance = $enrol_instance;
            }

            $this->roles_mapping[$prefix] = $m;
            $this->sync_log(
                "    Instância do enrol $prefix={$m->enrol} foi sincronizada.",
                0
            );
        }
    }


    function sync_enrolments(): array {
        global $DB;

        $professores = getattr($this->json, 'professores', []);
        $equipe = getattr($this->json, 'equipe', []);
        $alunos = getattr($this->json, 'alunos', []);
        $usuarios = $this->inBackground ? array_merge($professores, $equipe, $alunos) : array_merge($professores, $equipe);

        $this->sync_log("  Sincronizando matriculamentos para " . count($usuarios) . " usuários.", 0);
        foreach ($usuarios as $usuario) {
            $user = $this->usuarios_sincronizados[$usuario->username] ?? null;
            if (!$user) {
                $this->sync_log("    Usuário '{$usuario->username}' não encontrado para matricular.", 533);
                continue;
            }
            // Mesma chave usada em sync_enrols_manuals (tipo_usuario), senão o aluno é ignorado silenciosamente.
            $prefix = $this->get_sala_tipo() . ":" . getattr($usuario, 'tipo_usuario', 'Aluno');
            if (!is_array($this->roles_mapping) || array_key_exists($prefix, $this->roles_mapping) === false) {
                $this->falhas_matricula[] = "{$user->username}: sem mapeamento para '{$prefix}'";
                $this->alunos_sincronizados[] = $user->id; // evita suspensão por omissão
                $this->sync_log("    Não localizei mapeamento para o prefixo '{$prefix}' (usuário '{$user->username}').", 535);
                continue;
            }
            $m = $this->roles_mapping[$prefix];
            $status_str = strtolower(getattr($usuario, 'situacao_diario', getattr($usuario, 'status', 'inativo')));
            $status = $status_str === 'ativo' ? \ENROL_USER_ACTIVE : \ENROL_USER_SUSPENDED;

            if ($this->is_user_enrolled_in_role($user, $m->enrol_instance, $m->role_instance)) {
                $m->enrol_plugin->update_user_enrol($m->enrol_instance, $user->id, $status);
                $this->sync_log("    Matriculamento de '{$user->username}' será sincronizado ({$m->enrol}:{$m->role_instance->shortname}:{$status_str}).", 0);
            } else {
                // enrol_user do core não é atômico (ue → evento → role_assign): sem transação, uma falha no meio
                // deixa a inscrição sem papel. Com rollback, a próxima sincronização refaz tudo.
                $transaction = $DB->start_delegated_transaction();
                try {
                    $m->enrol_plugin->enrol_user($m->enrol_instance, $user->id, $m->role_instance->id, time(), 0, $status);
                    if (!\user_has_role_assignment($user->id, $m->role_instance->id, $this->context->id)) {
                        \role_assign($m->role_instance->id, $user->id, $this->context->id);
                    }
                    $transaction->allow_commit();
                    $this->sync_log("    Matriculamento de '{$user->username}' criado como {$m->enrol}:{$m->role_instance->shortname}:{$status_str}.", 0);
                } catch (\Throwable $e) {
                    try {
                        $transaction->rollback($e);
                    } catch (\Throwable $rollbackexception) {
                        // rollback() relança a exceção original; o tratamento segue abaixo.
                    }
                    $this->falhas_matricula[] = "{$user->username}: {$e->getMessage()}";
                    $this->alunos_sincronizados[] = $user->id; // evita suspensão por falha transitória
                    $this->sync_log("    Erro ao matricular usuário '{$user->username}': {$e->getMessage()}", 534);
                    continue;
                }
            }
            $this->alunos_sincronizados[] = $user->id;
        }
        return $this->alunos_sincronizados;
    }


    function suspend_students_not_in_list_all_enrols(): array {
        global $DB;

        [$notinsql, $params] = $DB->get_in_or_equal(
            $this->alunos_sincronizados ?: [0],
            SQL_PARAMS_NAMED,
            'uid',
            false
        );

        $sql = "
            SELECT  DISTINCT ue.userid, ue.enrolid, ue.status, e.enrol
            FROM    {user_enrolments}               ue
                        JOIN {enrol}                e   ON (ue.enrolid = e.id)
                            JOIN {role_assignments} ra  ON (ue.userid = ra.userid)
            AND     ra.contextid= :contextid
            AND     ra.roleid   = :roleid
            WHERE   e.courseid  = :courseid
            AND     e.status    = :enrolactive
            AND     ue.status   = :useractive
            AND     ue.userid   $notinsql
        ";

        $studentroleid = 5;

        $params = array_merge(
            $params,
            [
                'contextid'   => $this->context->id,
                'roleid'      => $studentroleid,
                'courseid'    => $this->course->id,
                'enrolactive' => ENROL_INSTANCE_ENABLED,
                'useractive'  => ENROL_USER_ACTIVE,
            ]
        );

        $records = $DB->get_records_sql($sql, $params);
        $instances = [];
        foreach ($records as $record) {
            if (!isset($instances[$record->enrolid])) {
                $instances[$record->enrolid] = $DB->get_record('enrol', ['id' => $record->enrolid], '*', MUST_EXIST);
            }

            $plugin = enrol_get_plugin($record->enrol);
            if (!$plugin) {
                continue;
            }

            $plugin->update_user_enrol(
                $instances[$record->enrolid],
                $record->userid,
                \ENROL_USER_SUSPENDED
            );

            $this->ids_suspensos[] = $record->userid;
            $this->sync_log("Matriculamento de '{$record->userid}' suspenso ({$record->enrol}).", 0);
        }

        return $this->ids_suspensos;
    }


    function sync_groups() {
        if ($this->isCoordination) {
            $group_entrada = config('room_group_entrada');
            $group_turma = config('room_group_turma');
            $group_polo = config('room_group_polo');
            $group_programa = config('room_group_programa');
        } else {
            $group_entrada = config('course_group_entrada');
            $group_turma = config('course_group_turma');
            $group_polo = config('course_group_polo');
            $group_programa = config('course_group_programa');
        }

        $this->sync_log("   Grupos (entrada={$group_entrada}, turma={$group_turma}, polo={$group_polo}, programa={$group_programa}) serão sincronizados.", 0);

        if (isset($this->json->alunos)) {
            $grupos = [];
            foreach ($this->json->alunos as $usuario) {
                if ($group_entrada) {
                    $entrada = substr($usuario->username, 0, 5);
                    if (!isset($grupos[$entrada])) {
                        $grupos[$entrada] = [];
                    }
                    $grupos[$entrada][] = $usuario;
                }

                if ($group_turma) {
                    $turma = $this->json->turma->codigo;
                    if (!isset($grupos[$turma])) {
                        $grupos[$turma] = [];
                    }
                    $grupos[$turma][] = $usuario;
                }

                if ($group_polo) {
                    $polo = isset($usuario->polo) && isset($usuario->polo->descricao) ? $usuario->polo->descricao : '--Sem polo--';
                    if (!isset($grupos[$polo])) {
                        $grupos[$polo] = [];
                    }
                    $grupos[$polo][] = $usuario;
                }

                if ($group_programa) {
                    $programa = isset($usuario->programa) && $usuario->programa != null ? $usuario->programa : "Institucional";
                    if (!isset($grupos[$programa])) {
                        $grupos[$programa] = [];
                    }
                    $grupos[$programa][] = $usuario;
                }
            }

            $custom_fields_metadata = \core_course\customfield\course_handler::create()->export_instance_data_object($this->course->id, true);
            $this->course->synchronized_groups = $custom_fields_metadata->grupos_sincronizados == '' ? [] : explode(',', $custom_fields_metadata->grupos_sincronizados);
            foreach ($grupos as $grupo_nome => $alunos) {
                $this->sync_log("    Grupo '{$grupo_nome}' será sincronizado. ", 0);
                $group = $this->sync_group($grupo_nome);
                if (!$group) {
                    $this->sync_log("        Grupo '{$grupo_nome}' não foi encontrado ou criado. Pulando adição de usuários.", 0);
                    continue;
                }
                $idDosAlunosFaltandoAgrupar = $this->getIdDosAlunosFaltandoAgrupar($group, $alunos);
                foreach ($alunos as $group_name => $usuario) {
                    $this->sync_log("        Usuário '{$usuario->username}' será adicionado ao grupo '{$grupo_nome}'.", 0);
                    $user = $this->usuarios_sincronizados[$usuario->username] ?? null;
                    if (!$user) {
                        $this->sync_log("        Usuário '{$usuario->username}' não encontrado para adicionar ao grupo '{$grupo_nome}'.", 533);
                        continue;
                    }
                    if (!in_array($user->id, $idDosAlunosFaltandoAgrupar)) {
                        \groups_add_member($group->id, $user->id);
                    }
                }
            }
            $this->course->customfield_grupos_sincronizados = implode(',', array_keys($grupos));
            update_course($this->course);
        }
    }


    function sync_group($group_name) {
        global $DB;
        $data = ['courseid' => $this->course->id, 'name' => $group_name];
        $group = $DB->get_record('groups', $data);

        if (!$group && !in_array($group_name, $this->course->synchronized_groups)) {
            $groupid = \groups_create_group((object)$data);
            $group = $DB->get_record('groups', ['id' => $groupid]);
            $this->sync_log("      Foi necessário criar o grupo '{$group_name}'.", 0);
        }
        return $group;
    }
}

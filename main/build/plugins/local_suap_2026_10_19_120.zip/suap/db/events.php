<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Event observers definition for local_suap plugin.
 *
 * @package   local_suap
 * @copyright 2026 IFRN
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$observers = [
    [
        'eventname'   => '\core\event\user_enrolment_created',
        'callback'    => 'local_suap_observer::user_enrolment_created',
    ],
    [
        'eventname'   => '\core\event\user_enrolment_deleted',
        'callback'    => 'local_suap_observer::user_enrolment_deleted',
    ],
    [
        'eventname'   => '\core\event\user_enrolment_updated',
        'callback'    => 'local_suap_observer::user_enrolment_updated',
    ],
    [
        'eventname'   => '\core\event\user_created',
        'callback'    => 'local_suap_observer::user_created',
    ],
    [
        'eventname'   => '\core\event\user_deleted',
        'callback'    => 'local_suap_observer::user_deleted',
    ],
    [
        'eventname'   => '\core\event\user_updated',
        'callback'    => 'local_suap_observer::user_updated',
    ],
    [
        'eventname'   => '\core\event\cohort_member_added',
        'callback'    => 'local_suap_observer::cohort_member_added',
    ],
    [
        'eventname'   => '\core\event\cohort_member_removed',
        'callback'    => 'local_suap_observer::cohort_member_removed',
    ],
    [
        'eventname'   => '\core\event\role_assigned',
        'callback'    => 'local_suap_observer::role_assigned',
    ],
    [
        'eventname'   => '\core\event\role_unassigned',
        'callback'    => 'local_suap_observer::role_unassigned',
    ],
];

<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * SUAP Integration
 *
 * This module provides extensive analytics on a platform of choice
 * Currently support Google Analytics and Piwik
 *
 * @package     local_suap
 * @category    upgrade
 * @copyright   2020 Kelson Medeiros <kelsoncm@gmail.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

class suap_admin_settingspage extends admin_settingpage
{
    public function __construct($admin_mode) {
        $plugin_name = 'local_suap';
        parent::__construct($plugin_name, get_string('pluginname', $plugin_name), 'moodle/site:config', false, null);
        $this->setup($admin_mode);
    }

    function _($str, $args = null, $lazyload = false) {
        return get_string($str, $this->name);
    }

    function add_heading($name) {
        $this->add(new admin_setting_heading("{$this->name}/$name", $this->_($name), $this->_("{$name}_desc")));
    }

    function add_configtext($name, $default = '') {
        $this->add(new admin_setting_configtext("{$this->name}/$name", $this->_($name), $this->_("{$name}_desc"), $default));
    }

    function add_configtextarea($name, $default = '') {
        $this->add(new admin_setting_configtextarea("{$this->name}/$name", $this->_($name), $this->_("{$name}_desc"), $default));
    }

    function add_configcheckbox($name, $default = 0) {
        $this->add(new admin_setting_configcheckbox("{$this->name}/$name", $this->_($name), $this->_("{$name}_desc"), $default));
    }

    function setup($admin_mode) {
        global $CFG;
        if ($admin_mode) {
            $default_enrol = is_dir(dirname(__FILE__) . '/../../enrol/suap/') ? 'suap' : 'manual';
            $this->add_heading('auth_token_header');
            $this->add_configtext("auth_token", 'changeme');
            $this->add_configtext("painel_url", 'https://ava.ifrn.edu.br');

            $this->add_heading('user_audit_header');
            $this->add_configtext("user_audit_retention_months", '24');

            $this->add_heading('top_category_header');
            $this->add_configtext("top_category_idnumber", 'diarios');
            $this->add_configtext("top_category_name", 'Diários');
            $this->add_configtext("top_category_parent", '0');

            $this->add_heading('user_and_enrolment_header');
            $this->add_configtextarea("default_user_preferences", "auth_forcepasswordchange=0\nhtmleditor=0\nemail_bounce_count=1\nemail_send_count=1\nemail_bounce_count=0\nvisual_preference=1");
            $this->add_configtextarea(
                "roles_mapping",
                '
                    {
                        "diarios": {
                            "Principal":            {"role": "editingteacher",                  "enrol": "manual"},
                            "Formador":             {"role": "editingteacher-formador",         "enrol": "manual"},
                            "Mediador":             {"role": "editingteacher-mediador",         "enrol": "manual"},
                            "Conteudista":          {"role": "editingteacher-conteudista",      "enrol": "manual"},
                            "Tutor":                {"role": "editingteacher-tutor",            "enrol": "manual"},
                            "Coordenador de Curso": {"role": "editingteacher-coordenadorcurso", "enrol": "manual"},
                            "Tutor presencial":     {"role": "teacher-coordenadordepolo",       "enrol": "manual"},
                            "Coordenador de Polo":  {"role": "teacher-tutorpresencial",         "enrol": "manual"},
                            "Secretário de Curso":  {"role": "teacher-secretariocurso",         "enrol": "manual"},
                            "Aluno":                {"role": "student",                         "enrol": "manual"}
                        },
                        "coordenacoes": {
                            "Principal":            {"role": "student-docente",                 "enrol": "manual"},
                            "Formador":             {"role": "student-docente",                 "enrol": "manual"},
                            "Mediador":             {"role": "student-docente",                 "enrol": "manual"},
                            "Conteudista":          {"role": "student-docente",                 "enrol": "manual"},
                            "Tutor":                {"role": "student-docente",                 "enrol": "manual"},
                            "Coordenador de Curso": {"role": "editingteacher-coordenadorcurso", "enrol": "manual"},
                            "Tutor presencial":     {"role": "student-docente",                 "enrol": "manual"},
                            "Coordenador de Polo":  {"role": "student-docente",                 "enrol": "manual"},
                            "Secretário de Curso":  {"role": "student-docente",                 "enrol": "manual"},
                            "Aluno":                {"role": "student",                         "enrol": "manual"}
                        },
                        "autoinscricoes": {
                            "Principal":            {"role": "editingteacher",                  "enrol": "manual"},
                            "Formador":             {"role": "editingteacher-formador",         "enrol": "manual"},
                            "Mediador":             {"role": "editingteacher-mediador",         "enrol": "manual"},
                            "Conteudista":          {"role": "editingteacher-conteudista",      "enrol": "manual"},
                            "Tutor":                {"role": "editingteacher-tutor",            "enrol": "manual"},
                            "Coordenador de Curso": {"role": "editingteacher-coordenadorcurso", "enrol": "manual"},
                            "Tutor presencial":     {"role": "teacher-coordenadordepolo",       "enrol": "manual"},
                            "Coordenador de Polo":  {"role": "teacher-tutorpresencial",         "enrol": "manual"},
                            "Secretário de Curso":  {"role": "teacher-secretariocurso",         "enrol": "manual"},
                            "Aluno":                {"role": "student",                         "enrol": "manual"}
                        },
                        "praticas": {
                            "Principal":            {"role": "editingteacher",                  "enrol": "manual"},
                            "Formador":             {"role": "editingteacher-formador",         "enrol": "manual"},
                            "Mediador":             {"role": "editingteacher-mediador",         "enrol": "manual"},
                            "Conteudista":          {"role": "editingteacher-conteudista",      "enrol": "manual"},
                            "Tutor":                {"role": "editingteacher-tutor",            "enrol": "manual"},
                            "Coordenador de Curso": {"role": "editingteacher-coordenadorcurso", "enrol": "manual"},
                            "Tutor presencial":     {"role": "teacher-coordenadordepolo",       "enrol": "manual"},
                            "Coordenador de Polo":  {"role": "teacher-tutorpresencial",         "enrol": "manual"},
                            "Secretário de Curso":  {"role": "teacher-secretariocurso",         "enrol": "manual"},
                            "Aluno":                {"role": "student",                         "enrol": "manual"}
                        },
                        "modelos": {
                            "Principal":            {"role": "editingteacher",                  "enrol": "manual"},
                            "Formador":             {"role": "editingteacher-formador",         "enrol": "manual"},
                            "Mediador":             {"role": "editingteacher-mediador",         "enrol": "manual"},
                            "Conteudista":          {"role": "editingteacher-conteudista",      "enrol": "manual"},
                            "Tutor":                {"role": "editingteacher-tutor",            "enrol": "manual"},
                            "Coordenador de Curso": {"role": "editingteacher-coordenadorcurso", "enrol": "manual"},
                            "Tutor presencial":     {"role": "teacher-coordenadordepolo",       "enrol": "manual"},
                            "Coordenador de Polo":  {"role": "teacher-tutorpresencial",         "enrol": "manual"},
                            "Secretário de Curso":  {"role": "teacher-secretariocurso",         "enrol": "manual"},
                            "Aluno":                {"role": "student",                         "enrol": "manual"}
                        }
                    }
                '
            );
            $this->add_configtext("default_auth", "oauth2");
            $this->add_configtextarea(
                "auths_mapping",
                "Principal              : oauth2"
                . "\nFormador             : oauth2"
                . "\nMediador             : oauth2"
                . "\nConteudista          : oauth2"
                . "\nTutor                : oauth2"
                . "\nCoordenador de Curso : oauth2"
                . "\nTutor presencial     : oauth2"
                . "\nCoordenador de Polo  : oauth2"
                . "\nSecretário de Curso  : oauth2"
                . "\nAluno                : oauth2"
            );

            $this->add_heading('notes_to_sync_header');
            $this->add_configtext("notes_to_sync", "'N1', 'N2', 'N3' , 'N4', 'NAF'");

            $this->add_heading('groups_in_course_header');
            $this->add_configcheckbox("course_group_entrada", 1);
            $this->add_configcheckbox("course_group_turma", 1);
            $this->add_configcheckbox("course_group_polo", 1);
            $this->add_configcheckbox("course_group_programa", 1);

            $this->add_heading('groups_in_room_header');
            $this->add_configcheckbox("room_group_entrada", 1);
            $this->add_configcheckbox("room_group_turma", 1);
            $this->add_configcheckbox("room_group_polo", 1);
            $this->add_configcheckbox("room_group_programa", 1);

            $this->add_heading('student_settings_header');
            $this->add_configtext("default_student_auth", 'oauth2');
            $this->add_configtext("default_student_role_id", 5);
            $this->add_configtext("default_student_enrol_type", $default_enrol);

            $this->add_heading('teacher_settings_header');
            $this->add_configtext("default_teacher_auth", 'oauth2');
            $this->add_configtext("default_teacher_role_id", 3);
            $this->add_configtext("default_teacher_enrol_type", $default_enrol);

            $this->add_heading('assistant_settings_header');
            $this->add_configtext("default_assistant_auth", 'oauth2');
            $this->add_configtext("default_assistant_role_id", 4);
            $this->add_configtext("default_assistant_enrol_type", $default_enrol);

            $this->add_heading('former_settings_header');
            $this->add_configtext("default_former_auth", 'oauth2');
            $this->add_configtext("default_former_role_id", 4);
            $this->add_configtext("default_former_enrol_type", $default_enrol);

            $this->add_heading('moderator_settings_header');
            $this->add_configtext("default_moderator_auth", 'oauth2');
            $this->add_configtext("default_moderator_role_id", 4);
            $this->add_configtext("default_moderator_enrol_type", $default_enrol);

            $this->add_heading('instructor_settings_header');
            $this->add_configtext("default_instructor_auth", 'oauth2');
            $this->add_configtext("default_instructor_role_id", 4);
            $this->add_configtext("default_instructor_enrol_type", $default_enrol);
        }
    }
}

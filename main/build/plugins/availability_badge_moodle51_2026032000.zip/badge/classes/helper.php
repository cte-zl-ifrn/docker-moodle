<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Helper class.
 *
 * @package availability_badge
 * @copyright 2016 Blackboard, 2026 Brian Pool
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace availability_badge;

defined('MOODLE_INTERNAL') || die();

/**
 * Helper class for badge availability condition.
 *
 * @package availability_badge
 * @copyright 2016 Blackboard, 2026 Brian Pool
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class helper {
    /** @var array Array from badge id => badge object */
    protected static $badgenames = [];

    /**
     * Wipes the static cache used to store badge names.
     */
    public static function wipe_static_cache(): void {
        self::$badgenames = [];
    }

    /**
     * Gets badge names from cache.
     *
     * @return array Array of all the cached badge objects
     */
    public static function get_badge_names(): array {
        return self::$badgenames;
    }

    /**
     * Gets all badges for the given course.
     *
     * @param string|int $courseid Course id or 'all' for all badges
     * @return array Array of all the badge objects
     */
    public static function get_all_badges(string|int $courseid = 'all'): array {
        global $CFG, $DB;
        require_once($CFG->libdir . '/badgeslib.php');

        if (empty(self::$badgenames[$courseid])) {
            if ($courseid == 'all') {
                list($bsql, $params) = $DB->get_in_or_equal(BADGE_STATUS_INACTIVE, SQL_PARAMS_NAMED, 'status', false);
                $sql = "SELECT * FROM {badge} WHERE status $bsql";
                self::$badgenames[$courseid] = $DB->get_records_sql($sql, $params);
            } else {
                // Get both site badges (courseid = 0) and course-specific badges.
                $sitebadges = badges_get_badges(BADGE_TYPE_SITE, 0);
                $coursebadges = badges_get_badges(BADGE_TYPE_COURSE, $courseid);
                // Merge site and course badges.
                self::$badgenames[$courseid] = $sitebadges + $coursebadges;
            }
        }

        return self::$badgenames[$courseid];
    }
}

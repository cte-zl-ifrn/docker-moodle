<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Front-end class.
 *
 * @package availability_badge
 * @copyright 2016 Blackboard, 2026 Brian Pool
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace availability_badge;

defined('MOODLE_INTERNAL') || die();

/**
 * Front-end class for badge availability condition.
 *
 * @package availability_badge
 * @copyright 2016 Blackboard, 2026 Brian Pool
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class frontend extends \core_availability\frontend {

    /**
     * Gets JavaScript init parameters for this plugin.
     *
     * @param \stdClass $course Course object
     * @param \cm_info $cm Course-module currently being edited (null if none)
     * @param \section_info $section Section currently being edited (null if none)
     * @return array Array of parameters for JavaScript init
     */
    protected function get_javascript_init_params($course, \cm_info $cm = null,
            \section_info $section = null) {
        // Get all badges for course.
        $helper = new \availability_badge\helper;
        $badges = $helper::get_all_badges($course->id);

        // Change to JS array format and return.
        $jsarray = [];
        $context = \context_course::instance($course->id);
        foreach ($badges as $rec) {
            $jsarray[] = (object)['id' => $rec->id, 'name' =>
                    format_string($rec->name, true, ['context' => $context])];
        }
        return [$jsarray];
    }

    /**
     * Decides whether this plugin should be available in current context.
     *
     * @param \stdClass $course Course object
     * @param \cm_info $cm Course-module currently being edited (null if none)
     * @param \section_info $section Section currently being edited (null if none)
     * @return bool True if plugin should be available
     */
    protected function allow_add($course, \cm_info $cm = null,
            \section_info $section = null) {

        $helper = new \availability_badge\helper;
        $badges = $helper::get_all_badges($course->id);

        // Only show this option if there are some badges.
        return count($badges) > 0;
    }

}

# Changelog

All notable changes to the availability_badge plugin will be documented in this file.

## [1.2.0] - 2026-03-20

### Added
- Badge expiration support - users now lose access when their badges expire
- Improved badge filtering to show only relevant badges (current course + site badges)

### Fixed
- Badge restriction now properly respects badge expiration dates
- Badge dropdown now shows only site badges and current course badges (not badges from other courses)
- Only shows "Badge" restriction option when the current course or site has available badges

### Changed
- Enhanced `get_all_badges()` method to merge site badges with course-specific badges
- Improved badge availability checking to validate expiration status

## [1.1.0] - 2026-02-01

### Added
- Privacy API implementation (null_provider)
- Modern type hints throughout codebase
- Comprehensive PHPDoc documentation
- AMD JavaScript module support
- Missing language string for JavaScript validation error

### Changed
- **BREAKING**: Converted YUI JavaScript to AMD modules (Moodle 4.5 requirement)
- Updated minimum Moodle version requirement to 4.5 (2024100700)
- Modernized array syntax to use short array syntax
- Improved code documentation and inline comments
- Updated copyright information to include 2026 and Brian Pool

### Removed
- Deprecated YUI JavaScript modules and directory structure

### Fixed
- Incorrect package name in version.php (was availability_group, now availability_badge)
- Grammar in language string description ("has" → "have")
- Code style compliance with Moodle coding standards

### Technical Details
- Replaced YUI event delegation with jQuery
- Added Bootstrap 4 styling (custom-select class)
- Implemented get_javascript_strings() method in frontend class
- All JavaScript now follows AMD module pattern

## [1.0.0] - 2016-02-02

### Added
- Initial release
- Badge-based availability restriction for activities and sections
- Support for site-level and course-level badges
- Support for positive and negative conditions
- Integration with Moodle restore/backup system

### Credits
- Original development by Tim Lock (Blackboard Inc.)
- Sponsored by University of Canberra

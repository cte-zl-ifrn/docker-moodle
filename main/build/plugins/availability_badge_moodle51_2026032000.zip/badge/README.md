# Availability Badge

Restrict activity and section availability based on user badges.

## Description

This plugin adds the functionality to restrict access to activities or sections in a course based on whether a student has earned a specified badge (either site-level or course-level badges).

## Features

- Restrict access based on badge possession
- Support for both positive ("must have badge") and negative ("must NOT have badge") conditions
- Works with both site-level and course-level badges
- Integrates seamlessly with Moodle's availability conditions system

## Requirements

- Moodle 4.5 or later

## Installation

1. Copy the `badge` folder into `/availability/condition/`
2. Visit Site Administration > Notifications to complete the installation
3. The plugin is now ready to use

## Usage

1. Enable editing mode in your course
2. Edit settings for any activity or section
3. Expand "Restrict access" section
4. Click "Add restriction..."
5. Select "Badge" from the list
6. Choose the badge from the dropdown
7. Optionally click the "eye" icon to invert the condition (must NOT have badge)
8. Save your changes

## Version History

### Version 1.2.0 (2026-03-20)
- Added badge expiration support - access is revoked when badges expire
- Improved badge filtering to show only site badges and current course badges
- Fixed badge availability checking to respect expiration dates
- Updated by Brian Pool

### Version 1.1.0 (2026-02-01)
- Updated for Moodle 4.5 compatibility
- Added Privacy API implementation
- Modernized code with type hints and improved documentation
- Updated by Brian Pool

### Version 1.0.0 (2016-02-02)
- Initial release for Moodle 3.1
- Developed by Tim Lock, Blackboard Inc.
- Developed for University of Canberra

## Credits

**Original Author:**  
Tim Lock, Senior Software Engineer  
[Blackboard Inc.](http://blackboard.com)  
Developed for [University of Canberra](http://www.canberra.edu.au)

**Maintainer (v1.1.0):**  
Brian Pool

## License

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.

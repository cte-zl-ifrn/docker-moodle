<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

namespace tool_painelava;

// phpcs:ignore moodle.Files.MoodleInternal.MoodleInternalGlobalState
if (!defined('NO_MOODLE_COOKIES')) {
    define('NO_MOODLE_COOKIES', true);
}

require_once('../../../../config.php');
require_once('../locallib.php');
require_once("servicelib.php");

/**
 * Service to set user preference.
 *
 * @package    tool_painelava
 * @copyright  2024 IFRN
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class set_user_preference_service extends \tool_painelava\service
{
    /**
     * Executes the service call to update a user's preference.
     *
     * @return array Status and updated preference details.
     * @throws \Exception If parameters are missing or user is not found.
     */
    public function do_call() {
        global $DB;

        // Buscar usuário pelo username informado.
        $username = optional_param('username', null, PARAM_USERNAME);
        if ($username === null) {
            throw new \Exception("Parâmetro 'username' é obrigatório", 400);
        }

        $target = $DB->get_record('user', ['username' => strtolower($_GET['username'])]);
        if (!$target) {
            throw new \Exception('Usuário não encontrado.', 404);
        }

        // Pega os parâmetros enviados.
        $name = optional_param('name', null, PARAM_ALPHANUMEXT);
        $value = optional_param('value', null, PARAM_RAW);

        if ($name === null || $value === null) {
            throw new \Exception("Parâmetros 'name' e 'value' são obrigatórios", 400);
        }

        // Salva a preferência usando a API oficial.
        if (in_array($value, [true, 'true', 1, '1'], true)) {
            $value = '1';
        } else if (in_array($value, [false, 'false', 0, '0'], true)) {
            $value = '0';
        } else if (is_numeric($value)) {
            $value = (string)intval($value);
        } else {
            $value = (string)$value;
        }
        \tool_painelava\audit::set_preference($name, $value, $target->id);

        // Retorna uma resposta simples em JSON.
        return [
            'error' => false,
            'message' => 'Preferência atualizada com sucesso',
            'user' => [
                'id' => $target->id,
                'username' => $target->username,
                'fullname' => fullname($target),
            ],
            'preference' => [
                'name' => $name,
                'value' => $value,
            ],
        ];
    }
}

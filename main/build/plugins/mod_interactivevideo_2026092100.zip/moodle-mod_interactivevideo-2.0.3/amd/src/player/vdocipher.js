// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * VdoCipher Player class
 * Doc: https://www.vdocipher.com/docs/player/v2/
 * @module     mod_interactivevideo/player/vdocipher
 * @copyright  2025 Sokunthearith Makara <sokunthearithmakara@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

import $ from 'jquery';
import {dispatchEvent} from 'core/event_dispatcher';
import allowAutoplay from 'mod_interactivevideo/player/checkautoplay';

let player = {};
class VdoCipher {
    /**
     * Creates an instance of the Dyntube player.
     *
     * @constructor
     */
    constructor() {
        this.type = 'vdocipher';
        this.frequency = 0.25;
        this.useAnimationFrame = false;
        this.support = {
            playbackrate: true,
            quality: true,
            password: false,
        };
        this.live = false; // Added flag for live video support
    }
    /**
     * Extract the video id from a VdoCipher dashboard URL.
     *
     * Accepts https://www.vdocipher.com/dashboard/video/{videoId}/tab/settings and
     * https://www.vdocipher.com/dashboard/video/embed/{videoId}. Activities saved by
     * versions before 2.0.3 carry a player URL after a '|', which is ignored.
     *
     * @param {string} url
     * @return {string|null}
     */
    parseVideoId(url) {
        url = url.split('|')[0];
        const regex = /(?:https?:\/\/)?(?:www\.)?vdocipher\.com\/dashboard\/video\/(?:embed\/|)([a-zA-Z0-9_-]+)/i;
        const match = regex.exec(url);
        return match ? match[1] : null;
    }
    /**
     * Ask the site for one of the two VdoCipher API answers it relays.
     *
     * 'otp' mints a playback OTP for the current user, watermark included, so it must be
     * requested on every load and never stored. 'info' returns the video metadata.
     *
     * @param {string} videoId
     * @param {string} info 'otp' or 'info'
     * @return {Promise<Object>} The parsed answer, or {error: true} when it is not JSON.
     */
    async fetchVdoCipher(videoId, info) {
        const data = await $.ajax({
            url: M.cfg.wwwroot + '/mod/interactivevideo/ajax.php',
            type: 'POST',
            dataType: 'text',
            data: {
                action: 'get_vdocipher',
                sesskey: M.cfg.sesskey,
                videoid: videoId,
                contextid: M.cfg.contextid,
                info,
            },
        });
        try {
            return JSON.parse(data);
        } catch {
            return {error: true};
        }
    }
    /**
     * Mint the OTP for the current user and remember the player URL it authorises.
     *
     * @param {string} videoId
     * @return {Promise<boolean>} False when the OTP could not be minted (an error event is sent).
     */
    async authorisePlayback(videoId) {
        const data = await this.fetchVdoCipher(videoId, 'otp');
        if (data.error) {
            this.sendEvent('iv:playerError', {error: data}, this.node);
            return false;
        }
        this.otp = data.otp;
        this.playbackInfo = data.playbackInfo;
        this.iframesrc = `https://player.vdocipher.com/v2/?otp=${this.otp}&playbackInfo=${this.playbackInfo}`;
        return true;
    }
    /**
     * Read the title, poster and duration from the VdoCipher API.
     *
     * @param {string} videoId
     * @return {Promise<boolean>} False when the metadata could not be read (an error event is sent).
     */
    async readVideoInfo(videoId) {
        const info = await this.fetchVdoCipher(videoId, 'info');
        if (info.error) {
            this.sendEvent('iv:playerError', {error: info}, this.node);
            return false;
        }
        this.title = info.title;
        this.posterImage = info.posters[0] ? info.posters[0].posterUrl : info.poster;
        this.aspectratio = info.posters[0].width / info.posters[0].height;
        this.duration = info.length; // Duration in seconds.
        return true;
    }
    /**
     * Get information about the video
     * @param {string} url
     * @param {string} node
     * @return {Promise<Object>} A promise that resolves to an object containing information about the video.
     */
    async getInfo(url, node) {
        this.node = node;
        let self = this;

        const videoId = this.parseVideoId(url);
        this.videoId = videoId;

        if (!await this.authorisePlayback(videoId) || !await this.readVideoInfo(videoId)) {
            return;
        }
        // Load the Dyntube API script.
        var tag = document.createElement('script');
        tag.src = "https://player.vdocipher.com/v2/api.js";
        tag.async = true;
        tag.as = "script";
        tag.rel = "preload";
        var firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

        $(`#${node}`).replaceWith(`
            <iframe id="${node}"
            src="${self.iframesrc}`
            + `&controls=on"
             frameborder=0 allowFullScreen="true" allow="encrypted-media"></iframe>`);

        let iframe = document.getElementById(node);
        /**
         * Waits for the Dyntube API to be available before initializing the player.
         * @param {Function} resolve - The function to call when Dyntube is ready.
         */
        function waitForVdoPlayer(resolve) {
            if (window.VdoPlayer) {
                player[node] = window.VdoPlayer.getInstance(iframe);
                resolve();
            } else {
                window.requestAnimationFrame(() => waitForVdoPlayer(resolve));
            }
        }

        await new Promise(waitForVdoPlayer);

        // eslint-disable-next-line consistent-return
        return new Promise((resolve) => {
            player[node].video.addEventListener('loadedmetadata', async function() {
                resolve({
                    duration: self.duration,
                    title: self.title,
                    posterImage: self.posterImage,
                });
            });
        });
    }
    /**
     * Load the video
     * @param {string} url
     * @param {number} start
     * @param {number} end
     * @param {object} opts
     * @param {boolean} reloaded
     * @return {Promise<Boolean>}
     */
    async load(url, start, end, opts = {}, reloaded = false) {
        const showControls = opts.showControls || false;
        const node = opts.node || 'player';
        this.node = node;

        this.url = url;
        // Hide the player first.
        this.allowAutoplay = await allowAutoplay(document.getElementById(node));
        if (!this.allowAutoplay) {
            this.sendEvent('iv:autoplayBlocked', {
                requireVideoBlock: true,
            }, this.node);
        }

        var self = this;
        this.start = start;
        this.end = end;

        // The OTP is minted for the current user on every load: it carries the watermark, so
        // it is never reused between viewers or kept in the activity.
        const videoId = this.parseVideoId(url);
        this.videoId = videoId;
        if (!await this.authorisePlayback(videoId)) {
            return;
        }
        // The edit form prefills the name and duration from the video metadata.
        if (opts.editform && !await this.readVideoInfo(videoId)) {
            return;
        }

        // Load the Dyntube API script.
        var tag = document.createElement('script');
        tag.src = "https://player.vdocipher.com/v2/api.js";
        tag.async = true;
        tag.as = "script";
        tag.rel = "preload";
        var firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

        $(`#${node}`).replaceWith(`
            <iframe id="${node}"
            src="${self.iframesrc}`
            + `&controls=${showControls ? "on" : "off"}"
             frameborder=0 allowFullScreen="true" allow="encrypted-media"></iframe>`);

        let iframe = document.getElementById(node);
        /**
         * Waits for the Dyntube API to be available before initializing the player.
         * @param {Function} resolve - The function to call when Dyntube is ready.
         */
        function waitForVdoPlayer(resolve) {
            if (window.VdoPlayer) {
                player[node] = window.VdoPlayer.getInstance(iframe);
                resolve();
            } else {
                window.requestAnimationFrame(() => waitForVdoPlayer(resolve));
            }
        }

        await new Promise(waitForVdoPlayer);

        // Disable picture-in-picture.
        player[node].video.setAttribute('disablePictureInPicture', '');

        player[node].video.addEventListener('loadedmetadata', async function() {
            self.aspectratio = self.ratio();
            if (isNaN(self.aspectratio)) {
                self.aspectratio = 16 / 9;
            }
            let totaltime = Number((player[node].video.duration).toFixed(2)) - self.frequency;
            end = !end ? totaltime : Math.min(end, totaltime);
            end = Number(end.toFixed(2));
            self.end = end;
            self.totaltime = totaltime;
            self.duration = self.end - self.start;
            player[node].video.currentTime = self.start;

            let captions = await player[node].api.getCaptionLanguages();
            captions = captions.languages || [];
            let tracks = [];
            if (captions && captions.length) {
                captions.forEach((track) => {
                    tracks.push({
                        label: track.label,
                        code: track.lang
                    });
                });
            }

            player[node].api.hideCaptions();
            self.sendEvent('iv:playerLoaded', {
                tracks,
                reloaded
            }, self.node);
            self.sendEvent('iv:playerReady', null, self.node);

            // Remove the start screen on chrome.
            if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
                setTimeout(() => {
                    $('.video-block, #video-block').addClass('no-pointer');
                }, 2000);

                $('#start-screen').remove();
            }
        });

        player[node].video.addEventListener('pause', function() {
            self.paused = true;
            self.sendEvent('iv:playerPaused', null, self.node);
        });

        player[node].video.addEventListener('play', function() {

            self.paused = false;
            self.sendEvent('iv:playerPlay', null, self.node);
            $('.video-block, #video-block').removeClass('no-pointer');
        });

        player[node].video.addEventListener('timeupdate', function() {
            if (self.paused) {
                return;
            }
            if (player[node].video.currentTime < self.start) {
                player[node].video.currentTime = self.start;
            }
            if (player[node].video.currentTime >= self.end + self.frequency && !self.live) {
                player[node].video.currentTime = self.end - self.frequency;
            }
            self.sendEvent('iv:playerPlaying', {
                time: player[node].video.currentTime,
                rate: player[node].video.playbackRate || 1,
            }, self.node);
            if (self.live) {
                return;
            }
            if (self.ended) {
                self.ended = false;
            } else {
                if (!self.ended && player[node].video.currentTime >= self.end) {
                    self.ended = true;
                    self.paused = true;
                    player[node].video.pause();
                    self.sendEvent('iv:playerEnded', null, self.node);
                }
            }
        });

        player[node].video.addEventListener('error', function(e) {
            self.sendEvent('iv:playerError', {error: e}, self.node);
        });

        player[node].video.addEventListener('ratechange', function() {
            self.sendEvent('iv:playerRateChange', {rate: player[node].video.playbackRate}, self.node);
        });

        player[node].video.addEventListener('waiting', function() {
            self.sendEvent('iv:playerBuffering', null, self.node);
        });

        // Volume change event.
        player[node].video.addEventListener('volumechange', function() {
            self.sendEvent('iv:playerVolumeChange', {volume: player[node].video.volume}, self.node);
        });

        // Quality change event.
        player[node].api.addEventListener('videoQualityChange', function(quality) {
            self.sendEvent('iv:playerQualityChange', {quality: quality}, self.node);
        });
    }
    /**
     * Play the video
     * @return {Void}
     */
    play() {
        if (!player[this.node]) {
            return;
        }
        try {
            player[this.node].video.play();
        } catch (e) {
            player[this.node].api.loadVideo(this.otp, this.playbackInfo);
            player[this.node].video.play();
        }
        this.paused = false;
    }

    /**
     * Pause the video
     * @return {Void}
     */
    pause() {
        if (!player[this.node]) {
            return;
        }
        player[this.node].video.pause();
        this.paused = true;
    }
    /**
     * Stop the video
     * @param {Number} starttime
     * @return {Void}
     */
    stop(starttime) {
        if (!player[this.node]) {
            return;
        }
        player[this.node].video.currentTime = starttime || this.start;
        player[this.node].video.pause();
    }
    /**
     * Seeks the video to a specified time.
     *
     * @param {number} time - The time in seconds to seek to.
     * @returns {boolean} Returns true when the seek operation is initiated.
     */
    seek(time) {
        if (!player[this.node]) {
            return time;
        }
        let currentTime = this.getCurrentTime();
        this.sendEvent('iv:playerSeekStart', {time: currentTime}, this.node);
        this.ended = false;
        player[this.node].video.currentTime = time;
        this.sendEvent('iv:playerSeek', {time}, this.node);
        return true;
    }
    /**
     * Get the current time of the video
     * @return {Number}
     */
    getCurrentTime() {
        if (!player[this.node]) {
            return 0;
        }
        return player[this.node].video.currentTime;
    }
    /**
     * Get the duration of the video
     * @return {Number}
     */
    getDuration() {
        if (!player[this.node]) {
            return 0;
        }
        const totaltime = Number(this.totaltime);
        if (Number.isFinite(totaltime)) {
            return totaltime;
        }
        return player[this.node].video.duration;
    }
    /**
     * Check if the video is paused
     * @return {Boolean}
     */
    isPaused() {
        if (!player[this.node]) {
            return true;
        }
        if (this.paused) {
            return true;
        }
        return player[this.node].video.paused;
    }
    /**
     * Check if the video is playing
     * @return {Boolean}
     */
    isPlaying() {
        if (!player[this.node]) {
            return false;
        }
        if (this.paused) {
            return false;
        }
        return !player[this.node].video.paused;
    }
    /**
     * Check if the video is ended
     * @return {Boolean}
     */
    isEnded() {
        if (!player[this.node]) {
            return false;
        }
        return player[this.node].video.ended || player[this.node].video.currentTime >= this.end;
    }
    /**
     * Get the aspect ratio of the video
     * @return {Number}
     */
    ratio() {
        if (!player[this.node]) {
            return 16 / 9;
        }
        return player[this.node].video.videoWidth / player[this.node].video.videoHeight;
    }
    /**
     * Destroy the player
     * @return {Void}
     */
    destroy() {
        if (!player[this.node]) {
            return;
        }
        player[this.node] = null;
        $(`#${this.node}`).remove();
        this.sendEvent('iv:playerDestroyed', null, this.node);
    }
    /**
     * Get the state of the player
     * @return {Number}
     */
    getState() {
        if (!player[this.node]) {
            return 0;
        }
        return player[this.node].video.paused ? 'paused' : 'playing';
    }
    /**
     * Set playback rate of the video
     * @param {Number} rate
     */
    setRate(rate) {
        if (!player[this.node]) {
            return 1;
        }
        player[this.node].video.playbackRate = rate;
        return rate;
    }
    /**
     * Get the playback rate of the video
     * @return {Number}
     */
    getRate() {
        if (!player[this.node]) {
            return 1;
        }
        return player[this.node].video.playbackRate || 1;
    }
    /**
     * Mute the video
     */
    mute() {
        if (!player[this.node]) {
            return;
        }
        player[this.node].video.muted = true;
        player[this.node].video.volume = 0;
        this.sendEvent('iv:playerVolumeChange', {volume: 0}, this.node);
    }
    /**
     * Unmute the video
     */
    unMute() {
        if (!player[this.node]) {
            return;
        }
        player[this.node].video.muted = false;
        player[this.node].video.volume = 1;
        this.sendEvent('iv:playerVolumeChange', {volume: 1}, this.node);
    }

    isMuted() {
        if (!player[this.node]) {
            return false;
        }
        return player[this.node].video.muted;
    }
    /**
     * Get the original player object
     */
    originalPlayer() {
        return player[this.node];
    }

    setQuality(quality) {
        if (!player[this.node]) {
            return quality;
        }
        player[this.node].api.setVideoQuality(quality);
        return quality;
    }

    async getQualities() {
        if (!player[this.node]) {
            return null;
        }
        let qualities = await player[this.node].api.getVideoQualities();
        let qualitiescode = qualities.qualities.map(x => x.id);
        let qualitiesLabel = qualities.qualities.map(x => x.label);
        let currentQuality = qualities.qualities.find(x => x.active) ?
            qualities.qualities.find(x => x.active).id : null;
        return {
            qualities: qualitiescode,
            qualitiesLabel: qualitiesLabel,
            currentQuality: currentQuality,
        };
    }

    setCaption(track) {
        if (!player[this.node]) {
            return track;
        }
        if (track === '') {
            player[this.node].api.hideCaptions();
            return track;
        }
        player[this.node].api.setCaptionLanguage(track);
        return track;
    }


    /**
     * Helper to dispatch events safely.
     * @param {string} name
     * @param {object} details
     * @param {string} elementid
     */
    sendEvent(name, details = null, elementid = null) {
        // eslint-disable-next-line no-nested-ternary
        let el = elementid ? document.getElementById(elementid) : (this.node ? document.getElementById(this.node) : null);
        if (el) {
            dispatchEvent(name, details, el);
        } else {
            dispatchEvent(name, details);
        }
    }

}

export default VdoCipher;

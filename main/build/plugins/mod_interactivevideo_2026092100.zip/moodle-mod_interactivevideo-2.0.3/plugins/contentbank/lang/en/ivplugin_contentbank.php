<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * English language pack for Contentbank
 *
 * @package    ivplugin_contentbank
 * @category   string
 * @copyright  2024 Sokunthearith Makara <sokunthearithmakara@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['add'] = 'Add';
$string['completioncompleted'] = 'Completed';
$string['completionincomplete'] = 'Incomplete';
$string['confirmtime'] = 'Use this time';
$string['contentbankcontent'] = 'Content bank item';
$string['contentbankdescription'] = 'Add content from the course\'s content bank.';
$string['contentuploaded'] = 'Content uploaded successfully.';
$string['contentuploaderror'] = 'Error uploading content';
$string['continue'] = 'Continue';
$string['edit'] = 'Edit';
$string['force'] = 'Force';
$string['gotosegment_desc'] = 'If checked, the learner will be presented with an option to go back to a time in the video that you specify below when the grade is below 50%. If "Force" is selected, the video will automatically jump to the specified time.';
$string['gotosegmentpassing_desc'] = 'If checked, the learner will be presented with an option to go back to a time in the video that you specify below when the grade is more than or equal to 50%. If "Force" is selected, the video will automatically jump to the specified time.';
$string['gototimestamp'] = 'Go to a specific timestamp';
$string['invalidcontentid'] = 'The selected Content Bank item is invalid or not found.';
$string['nocontentfound'] = 'No contents found.';
$string['onfailedgrade'] = 'When receive a failing grade';
$string['onpassinggrade'] = 'When receive a passing grade';
$string['pickatime'] = 'Pick a time on the timeline';
$string['pluginname'] = 'Content Bank Item';
$string['preview'] = 'Preview';
$string['privacy:metadata'] = 'The Content Bank Item plugin doesn\'t store any personal data.';
$string['resettime'] = 'Reset time';
$string['resume'] = 'Resume';
$string['resumeconfirm'] = 'You have attempted this interaction before. Do you want to resume from the last time you left off?';
$string['resync'] = 'Resync content from content bank';
$string['rewatch'] = 'Rewatch';
$string['savecurrentstate'] = 'Save current state';
$string['savecurrentstatedesc'] = 'If enabled, the current state of the interaction will be saved when the user dismisses the interaction. When the user returns, the interaction can be resumed from the last state.';
$string['selectoruploadcontent'] = 'Select a content from the list or create one';
$string['showtextonfailed'] = 'Show a message';
$string['showtextonpassing'] = 'Show a message';
$string['textonfailed'] = 'Text to display';
$string['textonpassing'] = 'Text to display';
$string['timeonfailed'] = 'Timestamp to go to';
$string['timeonpassing'] = 'Timestamp to go to';
$string['tutorialurl'] = 'https://youtu.be/tlzT0CleRaM';
$string['upload'] = 'Upload';
$string['uploadcontent'] = 'Upload content';
$string['xapicheck'] = 'xAPI check';
$string['xapieventdetected'] = 'xAPI complete event detected';

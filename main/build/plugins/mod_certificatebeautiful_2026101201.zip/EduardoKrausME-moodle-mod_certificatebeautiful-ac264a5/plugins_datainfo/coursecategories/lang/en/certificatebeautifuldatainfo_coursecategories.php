<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language strings.
 *
 * @package    certificatebeautifuldatainfo_coursecategories
 * @copyright  2025 Eduardo Kraus https://eduardokraus.com/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

$string['description'] = 'Description of the course category.';
$string['id'] = 'Unique identifier of the course category.';
$string['idnumber'] = 'Unique identification number of the course category.';
$string['name'] = 'Name of the course category.';
$string['pluginname'] = 'Data of the course category for which the certificate is being generated';
$string['privacy:metadata'] = 'The "course categories" plugin does not store any personal data.';
$string['timemodified'] = 'Timestamp of the last modification to the course category.';

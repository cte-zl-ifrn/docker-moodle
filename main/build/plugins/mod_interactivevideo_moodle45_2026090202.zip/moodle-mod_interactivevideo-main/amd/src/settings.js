// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Interactive Video admin settings entry point for content types modal.
 *
 * @module     mod_interactivevideo/settings
 * @copyright  2025 Sokunthearith Makara <sokunthearithmakara@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define(['mod_interactivevideo/contenttypes_settings'], function(ContentTypesSettings) {
    const init = () => {
        ContentTypesSettings.init({
            textareaName: 's_mod_interactivevideo_enablecontenttypes',
            installedNodeId: 'iv-installed-contenttypes',
            wsMethod: 'mod_interactivevideo_get_plugins_catalog',
            wsArgs: {target: 'mod_interactivevideo'},
            modalTemplate: 'mod_interactivevideo/admin/enablecontenttypes_modal',
            clickNamespace: 'ivenablecontenttypes',
        });
    };

    return {init};
});

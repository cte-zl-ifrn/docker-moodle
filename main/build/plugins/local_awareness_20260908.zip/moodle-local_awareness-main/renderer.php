<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Renderer for the plugin's admin surfaces.
 *
 * @package    local_awareness
 * @copyright  2026 Anderson Blaine
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use local_awareness\table\all_notices;
use local_awareness\output\editor_page;
use local_awareness\output\manage_page;

/**
 * Plugin's renderer.
 *
 * @package    local_awareness
 * @copyright  Catalyst IT
 * @copyright  2026 Anderson Blaine
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class local_awareness_renderer extends plugin_renderer_base {
    /**
     * Render table.
     * @param all_notices $table all notice table
     * @return false|string
     */
    public function render_all_notices(all_notices $table) {
        ob_start();
        $table->out($table->pagesize, false);
        $o = ob_get_contents();
        ob_end_clean();
        return $o;
    }

    /**
     * Render the redesigned notice editor page.
     *
     * @param editor_page $page renderable
     * @return string
     */
    public function render_editor_page(editor_page $page) {
        return $this->render_from_template('local_awareness/editor/shell', $page->export_for_template($this));
    }

    /**
     * Render the manage notices page wrapper.
     *
     * @param manage_page $page renderable
     * @return string
     */
    public function render_manage_page(manage_page $page) {
        return $this->render_from_template('local_awareness/manage/page', $page->export_for_template($this));
    }
}

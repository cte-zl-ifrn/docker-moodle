<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Settings.
 *
 * @package    local_awareness
 * @copyright  Catalyst IT
 * @copyright  2026 Anderson Blaine
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$ADMIN->add('root', new admin_category('awareness', new lang_string('pluginname', 'local_awareness')));

if ($hassiteconfig) {
    $temp = new admin_settingpage(
        'awarenesssettings',
        new lang_string('setting:settings', 'local_awareness')
    );

    $temp->add(
        new admin_setting_configcheckbox(
            'local_awareness/enabled',
            new lang_string('setting:enabled', 'local_awareness'),
            new lang_string('setting:enableddesc', 'local_awareness'),
            0
        )
    );

    $temp->add(
        new admin_setting_configcheckbox(
            'local_awareness/allow_update',
            new lang_string('setting:allow_update', 'local_awareness'),
            new lang_string('setting:allow_updatedesc', 'local_awareness'),
            0
        )
    );

    $temp->add(
        new admin_setting_configcheckbox(
            'local_awareness/allow_delete',
            new lang_string('setting:allow_delete', 'local_awareness'),
            new lang_string('setting:allow_deletedesc', 'local_awareness'),
            0
        )
    );

    $temp->add(
        new admin_setting_configcheckbox(
            'local_awareness/cleanup_deleted_notice',
            new lang_string('setting:cleanup_deleted_notice', 'local_awareness'),
            new lang_string('setting:cleanup_deleted_noticedesc', 'local_awareness'),
            0
        )
    );

    /*
     * A select, not a text box: the value is a fixed vocabulary and an admin_setting_configtext
     * defaults to PARAM_RAW, which would store whatever was typed and change retention silently.
     * Zero is "keep for ever" — core's own default for log retention, and the only default an
     * upgrade may have, because anything else would discard a site's existing history the first
     * time cron ran.
     */
    $temp->add(
        new admin_setting_configselect(
            'local_awareness/linkhistory_lifetime',
            new lang_string('setting:linkhistory_lifetime', 'local_awareness'),
            new lang_string('setting:linkhistory_lifetimedesc', 'local_awareness'),
            0,
            [
                0 => new lang_string('never'),
                30 => new lang_string('numdays', '', 30),
                90 => new lang_string('numdays', '', 90),
                180 => new lang_string('numdays', '', 180),
                365 => new lang_string('numdays', '', 365),
                730 => new lang_string('numdays', '', 730),
            ]
        )
    );

    $temp->add(
        new admin_setting_configtext(
            'local_awareness/audience_sync_limit',
            new lang_string('setting:audience_sync_limit', 'local_awareness'),
            new lang_string('setting:audience_sync_limitdesc', 'local_awareness'),
            \local_awareness\audience\live_mode::LIMIT_DEFAULT,
            PARAM_INT
        )
    );

    $ADMIN->add('awareness', $temp);
    $settings = null;
}

$managenotice = new admin_externalpage(
    'local_awareness_managenotice',
    get_string('setting:managenotice', 'local_awareness', null, true),
    new moodle_url('/local/awareness/managenotice.php'),
    'local/awareness:manage'
);

$ADMIN->add('awareness', $managenotice);

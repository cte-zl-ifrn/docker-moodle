<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_awareness;

use local_awareness\audience\estimator;

/**
 * Tests for the audience estimator.
 *
 * Coverage is declared in this docblock rather than with #[CoversClass]. The attribute is the
 * form Moodle's own standards prefer, and PHPUnit 12 drops doc-comment metadata entirely — but
 * moodle-cs on the 4.05 leg cannot see attributes, and reports every method here as missing
 * coverage information, which fails phpcs under --max-warnings 0. While this plugin still
 * supports 4.5, the docblock is the only form both ends of the range accept. Switch when the
 * supported range drops 405.
 *
 * @package    local_awareness
 * @copyright  2026 Anderson Blaine
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @covers \local_awareness\audience\estimator
 */
final class audience_estimator_test extends \advanced_testcase {
    protected function setUp(): void {
        parent::setUp();
        $this->resetAfterTest(true);
    }

    /**
     * Criteria are reduced to a canonical form: empty values dropped, lists deduplicated and sorted,
     * and scalar keys that carry no restriction removed entirely.
     *
     * The sorting is what makes the hash stable, so it is asserted here rather than only through
     * the hash — a normalise() that stopped sorting would still hash consistently with itself.
     *
     * @return void
     */
    public function test_normalise_strips_empty_and_sorts(): void {
        $raw = [
            'cohorts' => [3, 1, 2, 0, ''],
            'filter_role' => ['', 4, 4, 5],
            'filter_format' => ['weekly', 'topics', 'topics'],
            'reqcourse' => 0,
            'pathmatch' => '   ',
        ];
        $normalised = estimator::normalise($raw);
        $this->assertSame([1, 2, 3], $normalised['cohorts']);
        $this->assertSame([4, 5], $normalised['filter_role']);
        $this->assertSame(['topics', 'weekly'], $normalised['filter_format']);
        $this->assertArrayNotHasKey('reqcourse', $normalised);
        $this->assertArrayNotHasKey('pathmatch', $normalised);
    }

    /**
     * Two criteria sets differing only in key and list order hash the same.
     *
     * This is what the dedup window depends on: the editor sends criteria in whatever order the
     * form happened to build them, and an order-sensitive hash would make every keystroke look
     * like a new question.
     *
     * @return void
     */
    public function test_hash_is_deterministic_across_orderings(): void {
        $a = estimator::normalise(['cohorts' => [1, 2, 3], 'filter_role' => [4, 5]]);
        $b = estimator::normalise(['filter_role' => [5, 4], 'cohorts' => [3, 1, 2]]);
        $this->assertSame(estimator::hash($a), estimator::hash($b));
    }

    /**
     * Only the rules that can be answered about a USER are reported as audience rules.
     *
     * The page-dependent keys are a different kind of restriction — they need a page URL, which no
     * count has — so counting them among the audience rules would claim a precision the estimate
     * does not have.
     *
     * @return void
     */
    public function test_audience_rules_in_returns_every_rule_answerable_about_a_user(): void {
        $criteria = [
            'cohorts' => [1],
            'filter_role' => [2],
            'pathmatch' => 'my/?',
            'filter_category' => [3],
            'filter_theme' => ['boost'],
        ];
        $this->assertSame(
            ['cohorts', 'filter_role', 'filter_category'],
            estimator::audience_rules_in($criteria)
        );
    }

    /**
     * Only the two rules that are properties of the page stay out of the count.
     *
     * The category, course, format and competency rules were context-only until an author pointed
     * out that they do bound who can ever see the notice. What remains genuinely uncountable is the
     * URL the page is served at and the theme it is served in — neither says anything about a user.
     */
    public function test_only_the_page_rules_are_context_only(): void {
        $criteria = [
            'pathmatch' => 'my/?',
            'filter_theme' => ['boost'],
            'filter_category' => [1],
            'filter_course' => [2],
            'filter_format' => ['topics'],
            'filter_competency_rules' => [['id' => 3, 'proficient' => 1, 'name' => 'x']],
        ];

        $keys = array_column(estimator::context_rules_in($criteria), 'key');
        $this->assertSame(['pathmatch', 'filter_theme'], $keys);
    }

    /**
     * A notice with nothing narrowed reaches the whole site, and says so.
     *
     * Zero was the old answer, and the editor rendered it as "— " beside an unchanged prompt, so
     * pressing Calculate reach on a fresh notice looked like a broken button rather than a notice
     * aimed at everyone. The control is the suspended user: the count has to be the ACTIVE
     * population, not simply every row in {user}.
     */
    public function test_estimate_with_no_rules_counts_every_active_user(): void {
        global $DB;

        $generator = $this->getDataGenerator();
        $generator->create_user();
        $generator->create_user();
        $generator->create_user(['suspended' => 1]);

        $expected = (int) $DB->count_records_select(
            'user',
            'deleted = 0 AND suspended = 0 AND confirmed = 1 AND username <> :guestname',
            ['guestname' => 'guest']
        );

        $result = (new estimator())->estimate([]);

        $this->assertFalse($result['has_audience_rules']);
        $this->assertSame($expected, $result['count']);
        $this->assertSame([], $result['breakdown']);
        // Control: the suspended user exists and is not in the number above.
        $this->assertSame(1, (int) $DB->count_records('user', ['suspended' => 1]));
    }

    /**
     * Page-only rules do not narrow the count, but no longer zero it either.
     */
    public function test_page_only_rules_leave_the_count_at_the_whole_site(): void {
        $this->getDataGenerator()->create_user();

        $everyone = (new estimator())->estimate([])['count'];
        $result = (new estimator())->estimate(['pathmatch' => 'my/?', 'filter_theme' => ['boost']]);

        $this->assertFalse($result['has_audience_rules']);
        $this->assertSame($everyone, $result['count']);
        $this->assertCount(2, $result['context_only_filters']);
    }

    /**
     * A single cohort rule counts its members and nobody else.
     *
     * The breakdown is asserted beside the total because estimate() produces both from ONE
     * statement — a SUM(CASE ...) total plus one SUM(CASE ...) column per rule — so the two are
     * built by sibling expressions over the same scan and can disagree if a rule's isolated form
     * drifts from the combined one.
     *
     * @return void
     */
    public function test_estimate_cohort_only(): void {
        $generator = $this->getDataGenerator();
        $cohort = $generator->create_cohort();
        $u1 = $generator->create_user();
        $u2 = $generator->create_user();
        $generator->create_user(); // Not in cohort.
        cohort_add_member($cohort->id, $u1->id);
        cohort_add_member($cohort->id, $u2->id);

        $result = (new estimator())->estimate(['cohorts' => [$cohort->id]]);
        $this->assertSame(2, $result['count']);
        $this->assertTrue($result['has_audience_rules']);
        $this->assertCount(1, $result['breakdown']);
        $this->assertSame('cohorts', $result['breakdown'][0]['key']);
        $this->assertSame(2, $result['breakdown'][0]['count']);
    }

    /**
     * A group rule counts the group's members, hidden groups included, and intersects with the rest.
     *
     * The hidden group is the control for visibility: its member is counted although nobody may
     * see the group, because delivery is membership. The cohort is the control for intersection: a
     * union would answer 3 and a dropped rule 2, so 1 can only be both rules applied.
     */
    public function test_estimate_counts_group_members_whatever_the_visibility(): void {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course();
        $shown = $generator->create_group(['courseid' => $course->id]);
        $hidden = $generator->create_group(['courseid' => $course->id, 'visibility' => GROUPS_VISIBILITY_NONE]);
        $cohort = $generator->create_cohort();

        $u1 = $generator->create_and_enrol($course, 'student');
        $u2 = $generator->create_and_enrol($course, 'student');
        $u3 = $generator->create_and_enrol($course, 'student'); // Enrolled, in no group.
        $generator->create_group_member(['groupid' => $shown->id, 'userid' => $u1->id]);
        $generator->create_group_member(['groupid' => $hidden->id, 'userid' => $u2->id]);
        cohort_add_member($cohort->id, $u1->id);
        cohort_add_member($cohort->id, $u3->id);

        $groups = [(int) $shown->id, (int) $hidden->id];
        $result = (new estimator())->estimate(['filter_groups' => $groups]);
        $this->assertSame(2, $result['count']);
        $this->assertSame('filter_groups', $result['breakdown'][0]['key']);
        $this->assertSame(2, $result['breakdown'][0]['count']);

        $both = (new estimator())->estimate(['cohorts' => [(int) $cohort->id], 'filter_groups' => $groups]);
        $this->assertSame(1, $both['count']);
        $this->assertEqualsCanonicalizing(['cohorts', 'filter_groups'], array_column($both['breakdown'], 'key'));

        // Normalised like every other id list: sorted, distinct, positive.
        $this->assertSame(
            ['filter_groups' => [3, 9]],
            estimator::normalise(['filter_groups' => ['9', 3, '3', 0, -2]])
        );
    }

    /**
     * A chip counts its own rule alone, so the group chip can exceed the total, exactly as the cohort's does.
     *
     * Group membership outlives an ACTIVE enrolment — a suspended user keeps their groups, and the
     * audience wants an active one — so a chip that answers "how many match this rule" is larger
     * here than the rule's share of the audience. That is the breakdown's documented contract, not
     * a defect, and the cohort chip in the same run is the control: it reads the same way over the
     * same person, so nothing may "fix" one of them alone.
     */
    public function test_a_chip_counts_its_own_rule_alone_as_the_cohort_chip_does(): void {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course();
        $group = $generator->create_group(['courseid' => $course->id]);

        $enrolled = $generator->create_and_enrol($course, 'student');
        $suspended = $generator->create_and_enrol($course, 'student', null, 'manual', 0, 0, ENROL_USER_SUSPENDED);
        $generator->create_group_member(['groupid' => $group->id, 'userid' => $enrolled->id]);
        $generator->create_group_member(['groupid' => $group->id, 'userid' => $suspended->id]);
        // The control: a suspended enrolment keeps the group membership, which is what makes the
        // two questions differ at all. Unenrolling would not do — core clears the groups with it.
        $this->assertContains(
            (int) $group->id,
            helper::user_group_ids((int) $course->id, (int) $suspended->id),
            'the control failed: the suspended member is no longer in the group'
        );

        $cohort = $generator->create_cohort();
        cohort_add_member($cohort->id, $enrolled->id);
        cohort_add_member($cohort->id, $suspended->id);

        $criteria = [
            'filter_course' => [(int) $course->id],
            'filter_groups' => [(int) $group->id],
            'cohorts' => [(int) $cohort->id],
        ];
        $result = (new estimator())->estimate($criteria);
        $chips = array_column($result['breakdown'], 'count', 'key');

        $this->assertSame(1, $result['count'], 'only the active enrolment is in the audience');
        $this->assertSame(1, $chips['filter_course'], 'the course rule is the one that wants an active enrolment');
        $this->assertSame(2, $chips['filter_groups'], 'the group rule alone is membership');
        $this->assertSame(2, $chips['cohorts'], 'and the cohort rule alone reads the same way over the same person');
    }

    /**
     * Audience rules combine by INTERSECTION: only the user matching both is counted.
     *
     * Three users make the two failure modes distinguishable — a union would answer 3 and a
     * dropped rule would answer 2, so an answer of 1 can only be the intersection.
     *
     * @return void
     */
    public function test_estimate_intersects_cohort_and_role(): void {
        global $DB;

        $generator = $this->getDataGenerator();
        $cohort = $generator->create_cohort();
        $course = $generator->create_course();
        $teacherrole = $DB->get_record('role', ['shortname' => 'editingteacher']);

        $u1 = $generator->create_user();
        $u2 = $generator->create_user();
        $u3 = $generator->create_user();
        cohort_add_member($cohort->id, $u1->id);
        cohort_add_member($cohort->id, $u2->id);
        // User u1 is in cohort AND has the teacher role; u2 in cohort only; u3 has role only.
        $generator->enrol_user($u1->id, $course->id, $teacherrole->id);
        $generator->enrol_user($u3->id, $course->id, $teacherrole->id);

        $result = (new estimator())->estimate([
            'cohorts' => [$cohort->id],
            'filter_role' => [(int) $teacherrole->id],
        ]);
        $this->assertSame(1, $result['count']);
    }

    /**
     * A required course removes the users who have already completed it.
     *
     * That is the point of the setting: the notice exists to push people towards the course, so
     * whoever has finished it is not part of the audience.
     *
     * @return void
     */
    public function test_estimate_excludes_users_who_completed_required_course(): void {
        global $DB;

        $generator = $this->getDataGenerator();
        $cohort = $generator->create_cohort();
        $course = $generator->create_course(['enablecompletion' => 1]);

        $u1 = $generator->create_user();
        $u2 = $generator->create_user();
        cohort_add_member($cohort->id, $u1->id);
        cohort_add_member($cohort->id, $u2->id);
        $generator->enrol_user($u1->id, $course->id);
        $generator->enrol_user($u2->id, $course->id);

        // Mark u2 as having completed the course.
        $now = time();
        $DB->insert_record('course_completions', (object) [
            'userid' => $u2->id,
            'course' => $course->id,
            'timeenrolled' => $now - 100,
            'timestarted' => $now - 90,
            'timecompleted' => $now,
            'reaggregate' => 0,
        ]);

        $result = (new estimator())->estimate([
            'cohorts' => [$cohort->id],
            'reqcourse' => (int) $course->id,
        ]);

        // Only u1 (cohort member, NOT completed) should be counted.
        $this->assertSame(1, $result['count']);
    }

    /**
     * The user-state flags the base predicate excludes, one per case.
     *
     * @return array
     */
    public static function excluded_user_state_provider(): array {
        return [
            'deleted' => ['deleted', 1],
            'suspended' => ['suspended', 1],
            'unconfirmed' => ['confirmed', 0],
        ];
    }

    /**
     * A cohort member in an excluded state is not counted.
     *
     * The member is added to the cohort FIRST and flagged AFTERWARDS. The previous version of this
     * test created the deleted user already deleted, could not add them to the cohort at all
     * (cohort_add_member refuses), and then asserted a count that the cohort-membership clause
     * alone produced — so `u.deleted = 0` could be deleted from the estimator with the test still
     * green. Flagging after joining is what puts the row in front of the predicate.
     *
     * @dataProvider excluded_user_state_provider
     * @param string $field The user field to flag.
     * @param int $value The value that should exclude them.
     */
    public function test_estimate_excludes_users_by_state(string $field, int $value): void {
        global $DB;

        $generator = $this->getDataGenerator();
        $cohort = $generator->create_cohort();
        $counted = $generator->create_user();
        $excluded = $generator->create_user();
        cohort_add_member($cohort->id, $counted->id);
        cohort_add_member($cohort->id, $excluded->id);

        // Control: while both are ordinary users, both count. If this is ever 1, the assertion
        // below is being satisfied by the membership and not by the state predicate.
        $this->assertSame(2, (new estimator())->estimate(['cohorts' => [$cohort->id]])['count']);

        $DB->set_field('user', $field, $value, ['id' => $excluded->id]);

        $result = (new estimator())->estimate(['cohorts' => [$cohort->id]]);
        $this->assertSame(1, $result['count'], "a {$field} member must not be counted");
    }

    /**
     * The guest account is never counted, even as a cohort member.
     *
     * Guest is excluded twice over — by id and by username — because the id is only 1 on a site
     * Moodle installed itself. This asserts the behaviour rather than either mechanism, so the
     * pair can be rearranged without rewriting the test.
     */
    public function test_estimate_excludes_the_guest_account(): void {
        global $CFG;

        $generator = $this->getDataGenerator();
        $cohort = $generator->create_cohort();
        $counted = $generator->create_user();
        cohort_add_member($cohort->id, $counted->id);

        $this->assertSame(1, (new estimator())->estimate(['cohorts' => [$cohort->id]])['count']);

        cohort_add_member($cohort->id, $CFG->siteguest);

        $result = (new estimator())->estimate(['cohorts' => [$cohort->id]]);
        $this->assertSame(1, $result['count'], 'the guest account must not be counted');
    }

    /**
     * The course rule counts the people enrolled in that course, not the whole site.
     *
     * check_filters() only ever shows a course-targeted notice on a course page the user can enter,
     * so the reach is bounded by enrolment. The two controls matter more than the assertion: an
     * outsider proves the rule narrows at all, and a second enrolled user proves it is not simply
     * counting one row.
     */
    public function test_the_course_rule_counts_the_people_enrolled_in_it(): void {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course();
        $elsewhere = $generator->create_course();

        $in1 = $generator->create_user();
        $in2 = $generator->create_user();
        $out = $generator->create_user();
        $generator->enrol_user($in1->id, $course->id);
        $generator->enrol_user($in2->id, $course->id);
        $generator->enrol_user($out->id, $elsewhere->id);

        $criteria = estimator::normalise(['filter_course' => [$course->id]]);
        $result = (new estimator())->estimate($criteria);

        $this->assertTrue($result['has_audience_rules']);
        $this->assertSame(2, $result['count']);
        // Control: the site holds more active users than the rule admits.
        $this->assertGreaterThan(2, (new estimator())->estimate([])['count']);
    }

    /**
     * A suspended enrolment, and one whose window has closed, are not reach.
     *
     * This is the half of get_enrolled_join($onlyactive = true) that is easiest to drop when
     * inlining it, and dropping it is invisible: the count merely reads high.
     */
    public function test_the_course_rule_ignores_inactive_enrolments(): void {
        global $DB;

        $generator = $this->getDataGenerator();
        $course = $generator->create_course();

        $active = $generator->create_user();
        $suspended = $generator->create_user();
        $expired = $generator->create_user();

        $generator->enrol_user($active->id, $course->id);
        $generator->enrol_user($suspended->id, $course->id, null, 'manual', 0, 0, ENROL_USER_SUSPENDED);
        $generator->enrol_user($expired->id, $course->id, null, 'manual', time() - 200, time() - 100);

        $criteria = estimator::normalise(['filter_course' => [$course->id]]);

        $this->assertSame(1, (new estimator())->estimate($criteria)['count']);
        // Control: all three enrolments exist, so the rule is discriminating rather than missing.
        $this->assertSame(3, $DB->count_records('user_enrolments'));
    }

    /**
     * A hidden course is not reach for the people enrolled in it.
     *
     * can_access_course() refuses one to anyone without moodle/course:viewhiddencourses, which is
     * nobody in the population this counts by default.
     */
    public function test_the_course_rule_skips_hidden_courses(): void {
        $generator = $this->getDataGenerator();
        $visible = $generator->create_course();
        $hidden = $generator->create_course(['visible' => 0]);

        $seen = $generator->create_user();
        $unseen = $generator->create_user();
        $generator->enrol_user($seen->id, $visible->id);
        $generator->enrol_user($unseen->id, $hidden->id);

        $count = (new estimator())->estimate(
            estimator::normalise(['filter_course' => [$visible->id, $hidden->id]])
        )['count'];

        $this->assertSame(1, $count);
    }

    /**
     * Every rule at once, in one statement, without a placeholder collision.
     *
     * The total and the per-rule chips are now conditional columns of a single query, so each rule's
     * predicate appears in it at least twice. Moodle counts placeholder OCCURRENCES against the
     * parameter array and throws duplicateparaminsql when a name repeats, which makes "many rules
     * set together" the failure mode of the whole design — and the one no other test here reaches,
     * since they set two rules at most.
     *
     * The counts are asserted as well as the shape: a query that merely runs could still be
     * correlating a subquery against the wrong copy of an alias.
     */
    public function test_every_rule_at_once_counts_in_one_statement(): void {
        global $DB;

        $generator = $this->getDataGenerator();
        $category = $generator->create_category();
        $course = $generator->create_course(['category' => $category->id, 'format' => 'topics']);
        $required = $generator->create_course(['enablecompletion' => 1]);
        $cohort = $generator->create_cohort();
        $roleid = (int) $DB->get_field('role', 'id', ['shortname' => 'student']);

        $matches = $generator->create_user();
        $generator->enrol_user($matches->id, $course->id, 'student');
        cohort_add_member($cohort->id, $matches->id);

        // A second user failing exactly one rule — the cohort — so the total has something to cut.
        $nearly = $generator->create_user();
        $generator->enrol_user($nearly->id, $course->id, 'student');

        $competency = $this->create_competency();
        $this->record_proficiency($matches->id, (int) $course->id, $competency, 1);
        $this->record_proficiency($nearly->id, (int) $course->id, $competency, 1);

        $criteria = estimator::normalise([
            'cohorts' => [$cohort->id],
            'filter_role' => [$roleid],
            'filter_role_context' => CONTEXT_COURSE,
            'reqcourse' => $required->id,
            'filter_category' => [$category->id],
            'filter_course' => [$course->id],
            'filter_format' => ['topics'],
            'filter_competency_rules' => [['id' => $competency, 'proficient' => 1, 'name' => 'c']],
        ]);

        $result = (new estimator())->estimate($criteria);

        $this->assertSame(1, $result['count'], 'only the user who satisfies every rule');

        $chips = array_column($result['breakdown'], 'count', 'key');
        $this->assertSame(estimator::audience_rules_in($criteria), array_keys($chips));
        $this->assertSame(1, $chips['cohorts'], 'one cohort member');
        $this->assertSame(2, $chips['filter_course'], 'both users are enrolled in the course');
        $this->assertSame(2, $chips['filter_competency_rules'], 'both users are proficient');
    }

    /**
     * The estimate costs the same number of reads whatever the rule count.
     *
     * This is the property the conditional-aggregation rewrite exists for, and the only one that
     * cannot be seen in a result: the counts were already correct as N+1 separate statements. Each
     * of those was a full pass over {user}, so on a site with hundreds of thousands of users the
     * rule count multiplied the cost of a number the author reads once.
     *
     * Compared against a one-rule estimate rather than asserted as a literal, so it keeps meaning
     * if the surrounding code ever reads a config value on the way past.
     */
    public function test_the_estimate_does_not_cost_more_reads_as_rules_are_added(): void {
        global $DB;

        $generator = $this->getDataGenerator();
        $category = $generator->create_category();
        $course = $generator->create_course(['category' => $category->id, 'format' => 'topics']);
        $cohort = $generator->create_cohort();
        $roleid = (int) $DB->get_field('role', 'id', ['shortname' => 'student']);
        $user = $generator->create_user();
        $generator->enrol_user($user->id, $course->id, 'student');
        cohort_add_member($cohort->id, $user->id);
        $competency = $this->create_competency();
        $this->record_proficiency($user->id, (int) $course->id, $competency, 1);

        $one = estimator::normalise(['cohorts' => [$cohort->id]]);
        $all = estimator::normalise([
            'cohorts' => [$cohort->id],
            'filter_role' => [$roleid],
            'filter_role_context' => CONTEXT_COURSE,
            'reqcourse' => $generator->create_course()->id,
            'filter_category' => [$category->id],
            'filter_course' => [$course->id],
            'filter_format' => ['topics'],
            'filter_competency_rules' => [['id' => $competency, 'proficient' => 1, 'name' => 'c']],
        ]);

        // Warm anything either path reads once and caches, so the comparison is of the queries the
        // estimate itself issues.
        (new estimator())->estimate($one);
        (new estimator())->estimate($all);

        $before = $DB->perf_get_reads();
        (new estimator())->estimate($one);
        $onerule = $DB->perf_get_reads() - $before;

        $before = $DB->perf_get_reads();
        (new estimator())->estimate($all);
        $sevenrules = $DB->perf_get_reads() - $before;

        $this->assertSame(1, $onerule, 'one statement, whatever the rules');
        $this->assertSame($onerule, $sevenrules, 'seven rules cost what one rule costs');
    }

    /**
     * The course count never claims more people than the per-user rule would admit.
     *
     * The bulk predicate models the enrolment branch of can_access_course() and not the viewer
     * branch, so it is a lower bound rather than an equality — stated in course_scope_sql() and
     * pinned here so the size of the gap cannot drift unnoticed. The gap in this fixture is exactly
     * the site admin, who can enter any course without being enrolled in it; asserting that, rather
     * than only the inequality, is what stops this from passing on a count of zero.
     */
    public function test_the_course_count_never_claims_more_than_the_rule_admits(): void {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course();

        $enrolled = $generator->create_user();
        $outsider = $generator->create_user();
        $generator->enrol_user($enrolled->id, $course->id);
        $outsider->id; // Present in the population, admitted by neither side.

        $filters = ['filter_course' => [(int) $course->id]];

        $this->setAdminUser();
        $count = (new estimator())->estimate(estimator::normalise($filters))['count'];
        $admitted = $this->users_admitted_by_the_rule($filters, (int) $course->id);

        $this->assertSame(1, $count);
        $this->assertLessThanOrEqual($admitted, $count);
        $this->assertSame($admitted - 1, $count, 'the only divergence is the unenrolled site admin');
    }

    /**
     * The category rule reaches everyone enrolled anywhere inside the category.
     */
    public function test_the_category_rule_spans_the_courses_in_it(): void {
        $generator = $this->getDataGenerator();
        $category = $generator->create_category();
        $first = $generator->create_course(['category' => $category->id]);
        $second = $generator->create_course(['category' => $category->id]);
        $outside = $generator->create_course();

        $a = $generator->create_user();
        $b = $generator->create_user();
        $c = $generator->create_user();
        $generator->enrol_user($a->id, $first->id);
        $generator->enrol_user($b->id, $second->id);
        $generator->enrol_user($c->id, $outside->id);

        $count = (new estimator())->estimate(
            estimator::normalise(['filter_category' => [$category->id]])
        )['count'];

        $this->assertSame(2, $count);
    }

    /**
     * The format rule reaches the people enrolled in courses using that format.
     */
    public function test_the_format_rule_counts_by_course_format(): void {
        $generator = $this->getDataGenerator();
        $weekly = $generator->create_course(['format' => 'weeks']);
        $topics = $generator->create_course(['format' => 'topics']);

        $inweekly = $generator->create_user();
        $intopics = $generator->create_user();
        $generator->enrol_user($inweekly->id, $weekly->id);
        $generator->enrol_user($intopics->id, $topics->id);

        $count = (new estimator())->estimate(
            estimator::normalise(['filter_format' => ['weeks']])
        )['count'];

        $this->assertSame(1, $count);
    }

    /**
     * The site course is never reach for these rules, even though everyone is "enrolled" on it.
     *
     * get_enrolled_join() skips its enrolment join entirely for SITEID because core treats every
     * user as enrolled on the front page. Carrying that exemption into this count would report the
     * whole site for a category rule that names the front page's category — a rule check_filters()
     * can never satisfy, because it resolves a course only above id 1.
     */
    public function test_the_site_course_is_not_reach(): void {
        global $DB;

        $generator = $this->getDataGenerator();
        $onfrontpage = $generator->create_user();
        $generator->create_user();

        /*
         * The front-page enrolment is the whole test. Nobody normally holds one — which is why core
         * treats everyone as enrolled there — so without it the count is zero whether the site
         * course is excluded or not, and the assertion below would pass while proving nothing.
         *
         * It is written straight to the tables because the API refuses to build it: add_instance()
         * throws "Invalid request to add enrol instance to frontpage", and the generator silently
         * enrols nobody when it finds no instance. The rows still turn up on migrated sites, which
         * is the case this guards, and the row count below is what catches a setup that quietly
         * stopped creating them.
         */
        $enrolid = $DB->insert_record('enrol', (object) [
            'enrol' => 'manual',
            'status' => ENROL_INSTANCE_ENABLED,
            'courseid' => SITEID,
            'sortorder' => 0,
            'timecreated' => time(),
            'timemodified' => time(),
        ]);
        $DB->insert_record('user_enrolments', (object) [
            'enrolid' => $enrolid,
            'userid' => $onfrontpage->id,
            'status' => ENROL_USER_ACTIVE,
            'timestart' => time() - 100,
            'timeend' => 0,
            'modifierid' => 2,
            'timecreated' => time(),
            'timemodified' => time(),
        ]);
        $this->assertSame(1, $DB->count_records('user_enrolments'));

        $count = (new estimator())->estimate(
            estimator::normalise(['filter_course' => [SITEID]])
        )['count'];

        $this->assertSame(0, $count);
    }

    /**
     * A competency rule counts the people who hold that proficiency in a course they are in.
     */
    public function test_the_competency_rule_counts_proficient_users(): void {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course();

        $proficient = $generator->create_user();
        $not = $generator->create_user();
        $generator->enrol_user($proficient->id, $course->id);
        $generator->enrol_user($not->id, $course->id);

        $competency = $this->create_competency();
        $this->record_proficiency($proficient->id, (int) $course->id, $competency, 1);
        $this->record_proficiency($not->id, (int) $course->id, $competency, 0);

        $criteria = estimator::normalise([
            'filter_competency_rules' => [['id' => $competency, 'proficient' => 1, 'name' => 'c']],
        ]);

        $this->assertSame(1, (new estimator())->estimate($criteria)['count']);

        // The mirror image: a rule written as "not proficient" admits the other user, and only them.
        $inverse = estimator::normalise([
            'filter_competency_rules' => [['id' => $competency, 'proficient' => 0, 'name' => 'c']],
        ]);
        $this->assertSame(1, (new estimator())->estimate($inverse)['count']);
    }

    /**
     * requireall demands every named competency, not merely one of them.
     */
    public function test_the_competency_rule_honours_require_all(): void {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course();

        $both = $generator->create_user();
        $one = $generator->create_user();
        $generator->enrol_user($both->id, $course->id);
        $generator->enrol_user($one->id, $course->id);

        $first = $this->create_competency();
        $second = $this->create_competency();
        $this->record_proficiency($both->id, (int) $course->id, $first, 1);
        $this->record_proficiency($both->id, (int) $course->id, $second, 1);
        $this->record_proficiency($one->id, (int) $course->id, $first, 1);

        $rules = [
            ['id' => $first, 'proficient' => 1, 'name' => 'a'],
            ['id' => $second, 'proficient' => 1, 'name' => 'b'],
        ];

        $all = estimator::normalise([
            'filter_competency_rules' => $rules,
            'filter_competency_requireall' => 1,
        ]);
        $this->assertSame(1, (new estimator())->estimate($all)['count']);

        // Control: without requireall the same data still demands both, since each rule names
        // proficiency in its own right — so the discriminating input is the missing second record.
        $this->assertSame(1, (new estimator())->estimate(
            estimator::normalise(['filter_competency_rules' => $rules])
        )['count']);
    }

    /**
     * With the competency subsystem off, a competency rule reaches nobody rather than everybody.
     *
     * check_filters() returns false outright in that case. An estimate that ignored the switch
     * would report the unfiltered site for a notice nobody can receive.
     */
    public function test_a_competency_rule_reaches_nobody_when_competencies_are_off(): void {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course();
        $user = $generator->create_user();
        $generator->enrol_user($user->id, $course->id);

        $competency = $this->create_competency();
        $this->record_proficiency($user->id, (int) $course->id, $competency, 1);

        $criteria = estimator::normalise([
            'filter_competency_rules' => [['id' => $competency, 'proficient' => 1, 'name' => 'c']],
        ]);

        // Control: the rule admits the user while the subsystem is on.
        $this->assertSame(1, (new estimator())->estimate($criteria)['count']);

        // The switch core_competency\api::is_enabled() actually reads — not $CFG->enablecompetencies.
        set_config('enabled', 0, 'core_competency');
        $this->assertSame(0, (new estimator())->estimate($criteria)['count']);
    }

    /**
     * Create a competency in a fresh framework and return its id.
     *
     * @return int
     */
    private function create_competency(): int {
        $generator = $this->getDataGenerator()->get_plugin_generator('core_competency');
        $this->setAdminUser();
        $framework = $generator->create_framework();
        $competency = $generator->create_competency(['competencyframeworkid' => $framework->get('id')]);
        $this->setUser(null);

        return (int) $competency->get('id');
    }

    /**
     * Record a user's proficiency for a competency in a course.
     *
     * Writes the {competency_usercompcourse} row that helper::get_user_competency_proficiency()
     * reads directly, which is the state the notice rule and the estimate both ask about. It used
     * to be read through core_competency\api::get_user_competency_in_course(), which creates the
     * relation when it is missing — a write from a read-typed web service, audit finding M16.
     *
     * The grade is not decoration. user_competency_course::validate_proficiency() refuses a
     * proficiency without one and validate_grade() refuses a grade outside the competency's scale,
     * so it is read off that scale rather than guessed: the top item for proficient, the first for
     * not. Core's own tests create these rows with both fields left null, which is why they never
     * had to solve this.
     *
     * @param int $userid The user.
     * @param int $courseid The course the proficiency was earned in.
     * @param int $competencyid The competency.
     * @param int $proficiency 1 when proficient, 0 when not.
     * @return void
     */
    private function record_proficiency(int $userid, int $courseid, int $competencyid, int $proficiency): void {
        $scaleitems = (new \core_competency\competency($competencyid))->get_scale()->scale_items;

        $this->getDataGenerator()->get_plugin_generator('core_competency')->create_user_competency_course([
            'userid' => $userid,
            'courseid' => $courseid,
            'competencyid' => $competencyid,
            // PARAM_BOOL: persistent::validate() converts false to 0 for itself, but an int 0 is
            // compared as the string "0" against clean_param()'s "" and rejected.
            'proficiency' => (bool) $proficiency,
            'grade' => $proficiency ? count($scaleitems) : 1,
        ]);
    }

    /**
     * Count the users the per-user rule admits, over exactly the population the estimator counts.
     *
     * @param array $filters Filter values, in the shape stored in filtervalues.
     * @param int $courseid Course to judge the page context from; 0 for none.
     * @return int
     */
    private function users_admitted_by_the_rule(array $filters, int $courseid = 0): int {
        global $DB;

        $users = $DB->get_records_select(
            'user',
            'deleted = 0 AND suspended = 0 AND confirmed = 1 AND username <> :guestname',
            ['guestname' => 'guest']
        );

        $filtervalues = json_encode($filters);
        $admitted = 0;
        foreach ($users as $user) {
            $this->setUser($user);
            if (helper::check_filters($filtervalues, $courseid)) {
                $admitted++;
            }
        }

        return $admitted;
    }

    /**
     * The breakdown chip for a role rule keeps the scope that rule was given.
     *
     * The editor renders one chip per audience rule beside the total. Isolating filter_role used to
     * drop filter_role_context and the course and category lists with it, so a rule meaning
     * "teachers of this one course" was counted as "teachers anywhere", and the chip disagreed with
     * the total sitting next to it — upward, and by the whole size of the site.
     */
    public function test_the_role_breakdown_keeps_the_scope_the_rule_was_given(): void {
        global $DB;

        $teacherroleid = (int) $DB->get_field('role', 'id', ['shortname' => 'editingteacher']);
        $listed = $this->getDataGenerator()->create_course();
        $unlisted = $this->getDataGenerator()->create_course();

        $inlisted = $this->getDataGenerator()->create_user();
        $elsewhere = $this->getDataGenerator()->create_user();
        $this->getDataGenerator()->enrol_user($inlisted->id, $listed->id, 'editingteacher');
        $this->getDataGenerator()->enrol_user($elsewhere->id, $unlisted->id, 'editingteacher');

        $criteria = estimator::normalise([
            'filter_role' => [$teacherroleid],
            'filter_role_context' => CONTEXT_COURSE,
            'filter_course' => [$listed->id],
        ]);

        $result = (new estimator())->estimate($criteria);

        $chips = [];
        foreach ($result['breakdown'] as $row) {
            $chips[$row['key']] = (int) $row['count'];
        }

        // Control: the combined count has always respected the scope. The chip is what drifted, so
        // asserting they agree is only meaningful while this stays at 1.
        $this->assertSame(1, (int) $result['count']);
        $this->assertSame(1, $chips['filter_role']);
    }

    /**
     * The bulk count agrees, user for user, with the per-user rule it mirrors.
     *
     * This class is a second implementation of the role rule — helper::check_filters() is the
     * first, and the two are kept in step by nothing but care. Rather than compare the two bodies,
     * this asks each of them about every user the count claims to cover and requires the same
     * answer, for an unscoped rule and for a course-scoped one.
     */
    public function test_the_bulk_count_agrees_with_the_per_user_rule(): void {
        global $DB;

        $teacherroleid = (int) $DB->get_field('role', 'id', ['shortname' => 'editingteacher']);
        $course = $this->getDataGenerator()->create_course();
        $other = $this->getDataGenerator()->create_course();

        $teacherhere = $this->getDataGenerator()->create_user();
        $teacherthere = $this->getDataGenerator()->create_user();
        $student = $this->getDataGenerator()->create_user();

        $this->getDataGenerator()->enrol_user($teacherhere->id, $course->id, 'editingteacher');
        $this->getDataGenerator()->enrol_user($teacherthere->id, $other->id, 'editingteacher');
        $this->getDataGenerator()->enrol_user($student->id, $course->id);

        // Unscoped: holding the role anywhere counts, so both teachers do.
        $unscoped = ['filter_role' => [$teacherroleid]];
        $this->setAdminUser();
        $count = (int) (new estimator())->estimate(estimator::normalise($unscoped))['count'];
        $this->assertSame(2, $count, 'both teachers, whichever course they teach');
        $this->assertSame($this->users_admitted_by_the_rule($unscoped), $count);

        /*
         * Course-scoped. Everyone judged here is enrolled in $course, so the page-context block
         * accepts them all and the role rule is what separates them — without that the block would
         * reject first and both sides would agree on zero, which proves nothing.
         */
        $scoped = [
            'filter_role' => [$teacherroleid],
            'filter_role_context' => CONTEXT_COURSE,
            'filter_course' => [$course->id],
        ];
        $this->getDataGenerator()->enrol_user($teacherthere->id, $course->id);

        $this->setAdminUser();
        $count = (int) (new estimator())->estimate(estimator::normalise($scoped))['count'];
        $this->assertSame(1, $count, 'only the teacher of the listed course');
        $this->assertSame($this->users_admitted_by_the_rule($scoped, (int) $course->id), $count);
    }
}

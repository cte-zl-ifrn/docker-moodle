<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_awareness\form;

use local_awareness\helper;
use local_awareness\local\author_scope;
use local_awareness\persistent\awareness;
use local_awareness\persistent\slide;

/**
 * The layout, position, animation, video link and slides: what the form offers, refuses and saves.
 *
 * Test metadata stays in docblocks while 405 is supported (moodle-cs cannot see attributes there).
 *
 * @package    local_awareness
 * @copyright  2026 Anderson Blaine
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \local_awareness\form\notice_form
 * @covers     \local_awareness\helper
 */
final class layout_form_test extends \advanced_testcase {
    /**
     * A form for the given notice, or for a new one.
     *
     * @param awareness|null $notice The notice being edited.
     * @return notice_form
     */
    private function form(?awareness $notice = null): notice_form {
        return new notice_form(null, [
            'persistent' => $notice,
            'id' => $notice ? (int) $notice->get('id') : 0,
            'scope' => author_scope::site(),
        ]);
    }

    /**
     * The form's default data, which is protected.
     *
     * @param notice_form $form The form.
     * @return \stdClass
     */
    private function default_data(notice_form $form): \stdClass {
        $method = new \ReflectionMethod($form, 'get_default_data');
        $method->setAccessible(true);

        return $method->invoke($form);
    }

    /**
     * The form's extra validation, which is protected, on a submission.
     *
     * @param notice_form $form The form.
     * @param array $data The submitted fields.
     * @return array Element name => message.
     */
    private function validate(notice_form $form, array $data): array {
        $method = new \ReflectionMethod($form, 'extra_validation');
        $method->setAccessible(true);
        $errors = [];

        $defaults = ['title' => 'Policy update', 'content' => ['text' => '<p>Read it.</p>', 'format' => FORMAT_HTML]];

        return $method->invokeArgs($form, [(object) ($data + $defaults), [], &$errors]);
    }

    /**
     * A draft area of the current user holding one image.
     *
     * @return int The draft item id.
     */
    private function draft_with_image(): int {
        global $USER;

        $draftid = file_get_unused_draft_itemid();
        get_file_storage()->create_file_from_string([
            'contextid' => \context_user::instance($USER->id)->id,
            'component' => 'user',
            'filearea' => 'draft',
            'itemid' => $draftid,
            'filepath' => '/',
            'filename' => 'slide.png',
        ], 'not really a png');

        return $draftid;
    }

    /**
     * A new notice is offered a fade; a saved one keeps the stillness it stored.
     *
     * The column default stays 'none' so the upgrade changes nothing a reader sees, and only the
     * empty form suggests motion. The second half is the control: without it, a default that
     * leaked into every edit would pass the first.
     */
    public function test_a_new_notice_is_offered_a_fade_and_a_saved_one_keeps_its_stillness(): void {
        $this->resetAfterTest();
        $this->setAdminUser();

        $this->assertSame('fade', $this->default_data($this->form())->animation);

        $notice = new awareness(0, (object) ['title' => 'Policy update', 'content' => '<p>Read it.</p>']);
        $notice->create();
        $this->assertSame('none', $this->default_data($this->form($notice))->animation);
    }

    /**
     * The combinations the picker cannot express are refused on the field the author can act on.
     *
     * @dataProvider refused_combination_provider
     * @param array $data The submitted appearance fields.
     * @param string $element The element the message lands on.
     */
    public function test_a_combination_the_layout_cannot_carry_is_refused(array $data, string $element): void {
        $this->resetAfterTest();
        $this->setAdminUser();

        $errors = $this->validate($this->form(), $data);

        $this->assertArrayHasKey($element, $errors, json_encode($errors));
    }

    /**
     * One refused combination per rule.
     *
     * @return array[]
     */
    public static function refused_combination_provider(): array {
        return [
            'card cannot demand an acknowledgement' => [
                ['template' => 'card', 'insistence' => awareness::INSISTENCE_ACKNOWLEDGE, 'position' => 'center'],
                'insistence',
            ],
            'classic cannot sit in a corner' => [
                ['template' => 'classic', 'insistence' => 0, 'position' => 'top-end'],
                'positiongroup',
            ],
            'video needs a link' => [
                ['template' => 'video', 'insistence' => 0, 'position' => 'center', 'videourl' => ''],
                'videourl',
            ],
            'a scheme-less link would resolve against the page' => [
                ['template' => 'video', 'insistence' => 0, 'position' => 'center', 'videourl' => 'youtu.be/3b1aH9K0xQ4'],
                'videourl',
            ],
            'a carousel needs two slides' => [
                [
                    'template' => 'carousel', 'insistence' => 0, 'position' => 'center',
                    'slide_caption' => ['Only one', ''], 'slide_videourl' => ['', ''], 'slide_image' => [0, 0],
                ],
                'templategroup',
            ],
            'minimal cannot demand an acknowledgement' => [
                ['template' => 'minimal', 'insistence' => awareness::INSISTENCE_ACKNOWLEDGE, 'position' => 'center'],
                'insistence',
            ],
            'a banner cannot block' => [
                ['template' => 'banner', 'insistence' => awareness::INSISTENCE_BLOCKING, 'position' => 'top'],
                'insistence',
            ],
            'an image cannot block' => [
                ['template' => 'image', 'insistence' => awareness::INSISTENCE_BLOCKING, 'position' => 'center', 'bgimage' => 0],
                'insistence',
            ],
            'a banner cannot sit in the centre' => [
                ['template' => 'banner', 'insistence' => 0, 'position' => 'center'],
                'positiongroup',
            ],
            'an image needs an image' => [
                ['template' => 'image', 'insistence' => 0, 'position' => 'center', 'bgimage' => 0],
                'bgimage',
            ],
            'the text is required by every layout but the image' => [
                [
                    'template' => 'classic', 'insistence' => 0, 'position' => 'center',
                    'content' => ['text' => '', 'format' => FORMAT_HTML],
                ],
                'content',
            ],
        ];
    }

    /**
     * The layouts that show a close and nothing else say so, and the one with no room for the box says that.
     *
     * Two messages, because the two refusals have different remedies: one asks for another layout
     * or a lower level, the other says only Informational will do.
     */
    public function test_each_insistence_refusal_names_its_reason(): void {
        $this->resetAfterTest();
        $this->setAdminUser();

        $errors = $this->validate($this->form(), [
            'template' => 'image', 'insistence' => awareness::INSISTENCE_BLOCKING, 'bgimage' => 0,
        ]);
        $this->assertStringContainsString('only be Informational', $errors['insistence']);

        $errors = $this->validate($this->form(), ['template' => 'card', 'insistence' => awareness::INSISTENCE_ACKNOWLEDGE]);
        $this->assertStringContainsString('no room for the acknowledgement box', $errors['insistence']);

        $errors = $this->validate($this->form(), ['template' => 'banner', 'insistence' => 0, 'position' => 'top-end']);
        $this->assertStringContainsString('top or the bottom edge', $errors['positiongroup']);
    }

    /**
     * The text carries its required marker for the layouts that need one, and not for the image.
     *
     * The marker comes from a rule the form adds once the layout is known, so it is asked of the
     * rendered form: a fresh one is classic and marks the text; one submitted as the image layout
     * does not, or the author would be told a field is mandatory that the save then accepts empty.
     */
    public function test_the_text_is_marked_required_for_every_layout_but_the_image(): void {
        global $PAGE;

        $this->resetAfterTest();
        $this->setAdminUser();
        $PAGE->set_url('/local/awareness/editnotice.php');
        $property = new \ReflectionProperty(\moodleform::class, '_form');
        $property->setAccessible(true);

        $fresh = $this->form();
        $fresh->render();
        $this->assertTrue($property->getValue($fresh)->isElementRequired('content'), 'a classic notice does not mark its text');

        notice_form::mock_submit(['template' => 'image', 'title' => 'Poster']);
        $image = $this->form();
        $image->render();
        $this->assertFalse(
            $property->getValue($image)->isElementRequired('content'),
            'the image layout marks a text it does not need'
        );
        $_POST = [];
    }

    /**
     * An image layout with an uploaded image and no text passes; the same with no image is refused.
     *
     * The picture is read from the draft area the picker posts, so the control is a draft area
     * with nothing in it: a check that merely tested the draft id would let it through.
     */
    public function test_the_image_layout_needs_a_picture_and_no_text(): void {
        $this->resetAfterTest();
        $this->setAdminUser();
        $form = $this->form();
        $empty = ['text' => '', 'format' => FORMAT_HTML];

        $this->assertSame([], $this->validate($form, [
            'template' => 'image', 'insistence' => 0, 'position' => 'top',
            'bgimage' => $this->draft_with_image(), 'content' => $empty,
        ]));

        $errors = $this->validate($form, [
            'template' => 'image', 'insistence' => 0, 'position' => 'top',
            'bgimage' => file_get_unused_draft_itemid(), 'content' => $empty,
        ]);
        $this->assertArrayHasKey('bgimage', $errors, 'an empty draft area passed as a picture');
        $this->assertArrayNotHasKey('content', $errors, 'the image layout demanded a text');
    }

    /**
     * The combinations the rules allow pass, so the refusals above are not a form that refuses everything.
     */
    public function test_the_allowed_combinations_pass(): void {
        $this->resetAfterTest();
        $this->setAdminUser();
        $form = $this->form();

        $this->assertSame([], $this->validate($form, [
            'template' => 'card', 'insistence' => awareness::INSISTENCE_BLOCKING, 'position' => 'top-end',
        ]));
        // Fullscreen has no position, so whatever the hidden radio carried is not a problem.
        $this->assertSame([], $this->validate($form, [
            'template' => 'fullscreen', 'insistence' => awareness::INSISTENCE_ACKNOWLEDGE, 'position' => 'top-end',
        ]));
        $this->assertSame([], $this->validate($form, [
            'template' => 'video', 'insistence' => 0, 'position' => 'top', 'videourl' => 'https://youtu.be/3b1aH9K0xQ4',
        ]));
        $this->assertSame([], $this->validate($form, [
            'template' => 'banner', 'insistence' => 0, 'position' => 'bottom',
        ]));
        $this->assertSame([], $this->validate($form, [
            'template' => 'minimal', 'insistence' => awareness::INSISTENCE_BLOCKING, 'position' => 'top',
        ]));
        $this->assertSame([], $this->validate($form, [
            'template' => 'split', 'insistence' => awareness::INSISTENCE_ACKNOWLEDGE, 'position' => 'center',
        ]));
        $this->assertSame([], $this->validate($form, [
            'template' => 'carousel', 'insistence' => 0, 'position' => 'center',
            'slide_caption' => ['First', ''], 'slide_videourl' => ['', 'https://vimeo.com/123456'], 'slide_image' => [0, 0],
        ]));
    }

    /**
     * When the slide says what it shows, the other control is not read — on the way in or out.
     *
     * hideIf hides a control without stopping its value, so a link typed and then switched away
     * from still arrives. Two halves are asserted because they are two code paths: validation must
     * not refuse the save, and the save must not store the abandoned value. The last assertion is
     * the control that the CHOICE is doing this and not some general leniency — the same payload
     * without a choice is still refused.
     */
    public function test_the_slide_says_what_it_shows_and_the_other_control_is_not_read(): void {
        $this->resetAfterTest();
        $this->setAdminUser();
        $draftid = $this->draft_with_image();

        $chosen = [
            'template' => 'carousel', 'insistence' => 0, 'position' => 'center',
            'slide_media' => [slide::MEDIA_IMAGE, slide::MEDIA_VIDEO],
            'slide_caption' => ['First', 'Second'],
            // Each slide carries BOTH: the leftovers of a choice the author changed on screen.
            'slide_videourl' => ['https://vimeo.com/123456', 'https://vimeo.com/654321'],
            'slide_image' => [$draftid, $draftid],
        ];
        $this->assertSame([], $this->validate($this->form(), $chosen), 'the abandoned control was read');

        $rows = helper::slide_rows((object) $chosen);
        $this->assertSame('', $rows->slide_videourl[0], 'the image slide kept a link');
        $this->assertSame(0, $rows->slide_image[1], 'the video slide kept a draft');
        $this->assertSame($draftid, $rows->slide_image[0], 'the image slide lost its image');
        $this->assertSame('https://vimeo.com/654321', $rows->slide_videourl[1], 'the video slide lost its link');

        // The control: no choice, and the old refusal still stands.
        unset($chosen['slide_media']);
        $this->assertArrayHasKey('slide_videourl[0]', $this->validate($this->form(), $chosen));
    }

    /**
     * A slide asked to show both an image and a video is refused on its link, with the slide named.
     */
    public function test_a_slide_cannot_show_both_an_image_and_a_video(): void {
        $this->resetAfterTest();
        $this->setAdminUser();
        $draftid = $this->draft_with_image();

        $errors = $this->validate($this->form(), [
            'template' => 'carousel', 'insistence' => 0, 'position' => 'center',
            'slide_caption' => ['', 'Second'],
            'slide_videourl' => ['https://vimeo.com/123456', ''],
            'slide_image' => [$draftid, 0],
        ]);

        $this->assertArrayHasKey('slide_videourl[0]', $errors);
        $this->assertArrayNotHasKey('templategroup', $errors, 'two slides are present; only the first is malformed');
    }

    /**
     * A slide listed twice is refused on the row that repeats it; listed once each, both pass.
     *
     * Two rows carrying one stored id would both write the same record, the later winning. The
     * control is the same payload with distinct ids, which the rule must let through.
     */
    public function test_a_slide_listed_twice_is_refused_on_the_row_that_repeats_it(): void {
        $this->resetAfterTest();
        $this->setAdminUser();
        $payload = [
            'template' => 'carousel',
            'slide_media' => [slide::MEDIA_IMAGE, slide::MEDIA_IMAGE],
            'slide_caption' => ['First', 'Second'],
            'slide_videourl' => ['', ''],
            'slide_image' => [0, 0],
        ];

        $errors = $this->validate($this->form(), $payload + ['slide_id' => [7, 7]]);
        $this->assertArrayHasKey('slide_caption[1]', $errors, 'the repeated row was not refused');
        $this->assertArrayNotHasKey('slide_caption[0]', $errors, 'the first row, which is legitimate, was refused');

        $errors = $this->validate($this->form(), $payload + ['slide_id' => [7, 8]]);
        $this->assertArrayNotHasKey('slide_caption[1]', $errors, 'distinct ids were refused');
        $this->assertArrayNotHasKey('slide_caption[0]', $errors);

        // Anywhere in the strip, not only next door: the third row repeats the first.
        $three = ['slide_media' => [slide::MEDIA_IMAGE, slide::MEDIA_IMAGE, slide::MEDIA_IMAGE],
            'slide_caption' => ['First', 'Second', 'Third'], 'slide_videourl' => ['', '', ''], 'slide_image' => [0, 0, 0]];
        $errors = $this->validate($this->form(), ['template' => 'carousel', 'slide_id' => [7, 8, 7]] + $three);
        $this->assertArrayHasKey('slide_caption[2]', $errors, 'a repeat two rows down was not refused');
        $this->assertArrayNotHasKey('slide_caption[1]', $errors);
        $this->assertArrayNotHasKey('slide_caption[0]', $errors);
    }

    /**
     * Saving writes the slides in order with their files, and a later save without a row deletes it.
     */
    public function test_saving_reconciles_the_slides_with_the_rows_submitted(): void {
        global $DB;

        $this->resetAfterTest();
        $this->setAdminUser();
        $draftid = $this->draft_with_image();

        helper::create_new_notice((object) [
            'title' => 'Semester news',
            'content' => '<p>News.</p>',
            'perpetual' => 1,
            'template' => 'carousel',
            'slide_caption' => ['Lab', 'Tour', ''],
            'slide_videourl' => ['', 'https://youtu.be/3b1aH9K0xQ4', ''],
            'slide_image' => [$draftid, 0, 0],
            'slide_id' => [0, 0, 0],
        ]);
        $notice = awareness::get_record(['title' => 'Semester news']);
        $slides = slide::for_notice($notice->get('id'));

        // The empty third row is not a slide.
        $this->assertCount(2, $slides);
        $this->assertSame([0, 1], array_map(static fn(slide $s): int => (int) $s->get('sortorder'), $slides));
        $this->assertSame(slide::MEDIA_IMAGE, $slides[0]->get_mediatype());
        $this->assertSame('slide.png', $slides[0]->get_image()->get_filename());
        $this->assertSame(slide::MEDIA_VIDEO, $slides[1]->get_mediatype());
        $this->assertSame('Tour', $slides[1]->get('caption'));

        // Edit: keep the video slide only, and the image slide goes with its file.
        set_config('allow_update', 1, 'local_awareness');
        $imageid = (int) $slides[0]->get('id');
        helper::update_notice($notice, (object) [
            'title' => 'Semester news',
            'content' => '<p>News.</p>',
            'perpetual' => 1,
            'template' => 'carousel',
            'slide_caption' => ['Tour'],
            'slide_videourl' => ['https://youtu.be/3b1aH9K0xQ4'],
            'slide_image' => [0],
            'slide_id' => [(int) $slides[1]->get('id')],
        ]);

        $remaining = slide::for_notice($notice->get('id'));
        $this->assertCount(1, $remaining);
        $this->assertSame(
            (int) $slides[1]->get('id'),
            (int) $remaining[0]->get('id'),
            'the kept row was replaced rather than kept'
        );
        $this->assertSame(0, (int) $remaining[0]->get('sortorder'));
        $this->assertFalse($DB->record_exists('local_awareness_slides', ['id' => $imageid]));
        $this->assertEmpty(get_file_storage()->get_area_files(
            \context_system::instance()->id,
            'local_awareness',
            slide::FILEAREA,
            $imageid,
            'id',
            false
        ), 'the removed slide\'s image outlived its row');
    }

    /**
     * What a hidden field would have carried is decided by the layout, on every write path.
     */
    public function test_the_layout_decides_the_values_of_the_fields_it_hides(): void {
        $this->resetAfterTest();
        $this->setAdminUser();

        helper::create_new_notice((object) [
            'title' => 'Fullscreen policy', 'content' => '<p>Read it.</p>', 'perpetual' => 1,
            'template' => 'fullscreen', 'position' => 'top', 'videourl' => 'https://youtu.be/3b1aH9K0xQ4',
        ]);
        $fullscreen = awareness::get_record(['title' => 'Fullscreen policy']);
        $this->assertSame('center', $fullscreen->get('position'), 'a fullscreen dialogue has no position');
        $this->assertNull($fullscreen->get('videourl'), 'only the video layout keeps a link');

        helper::create_new_notice((object) [
            'title' => 'Library tour', 'content' => '<p>Watch.</p>', 'perpetual' => 1,
            'template' => 'video', 'position' => 'top', 'videourl' => ' https://youtu.be/3b1aH9K0xQ4 ',
        ]);
        $video = awareness::get_record(['title' => 'Library tour']);
        $this->assertSame('top', $video->get('position'));
        $this->assertSame('https://youtu.be/3b1aH9K0xQ4', $video->get('videourl'), 'the link is kept, trimmed');
    }

    /**
     * The appearance section opens for a notice that chose something, and stays closed for the defaults.
     *
     * The stored columns are never empty, so "holds a value" has to mean "differs from the
     * default"; without that, every edit of every notice would open the section.
     */
    public function test_the_appearance_section_opens_only_for_a_choice_away_from_the_defaults(): void {
        $this->resetAfterTest();
        $this->setAdminUser();

        $plain = new awareness(0, (object) ['title' => 'Plain', 'content' => '<p>Plain.</p>']);
        $plain->create();
        $hero = new awareness(0, (object) ['title' => 'Hero', 'content' => '<p>Hero.</p>', 'template' => 'hero']);
        $hero->create();

        $this->assertTrue($this->is_collapsed($this->form($plain), 'header_appearance'), 'the defaults opened the section');
        $this->assertFalse($this->is_collapsed($this->form($hero), 'header_appearance'), 'a chosen layout left the section closed');
    }

    /**
     * Whether a header starts collapsed, from the form's own bookkeeping.
     *
     * @param notice_form $form The form.
     * @param string $header The header element name.
     * @return bool
     */
    private function is_collapsed(notice_form $form, string $header): bool {
        $mform = new \ReflectionProperty($form, '_form');
        $mform->setAccessible(true);
        $quickform = $mform->getValue($form);

        $collapsible = new \ReflectionProperty($quickform, '_collapsibleElements');
        $collapsible->setAccessible(true);
        $state = $collapsible->getValue($quickform);

        $this->assertArrayHasKey($header, $state, "{$header} is not a collapsible section");

        return (bool) $state[$header];
    }
}

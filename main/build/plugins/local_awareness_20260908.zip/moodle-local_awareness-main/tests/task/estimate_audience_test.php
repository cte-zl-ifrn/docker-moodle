<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_awareness\task;

use local_awareness\audience\estimator;
use local_awareness\persistent\audience_job;

/**
 * Tests for the estimate_audience ad-hoc task.
 *
 * @package    local_awareness
 * @copyright  2026 Anderson Blaine
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @covers \local_awareness\task\estimate_audience
 */
final class estimate_audience_test extends \advanced_testcase {
    protected function setUp(): void {
        parent::setUp();
        $this->resetAfterTest(true);
    }

    /**
     * Create and persist a pending audience job for the given criteria.
     *
     * @param array $criteria Raw audience criteria.
     * @return audience_job The persisted pending job.
     */
    private function create_pending_job(array $criteria): audience_job {
        global $USER;
        $normalised = estimator::normalise($criteria);
        $job = new audience_job(0, (object) [
            'jobid' => audience_job::new_jobid(),
            'userid' => (int) $USER->id,
            'criteriahash' => estimator::hash($normalised),
            'criteria' => json_encode($normalised),
            'status' => audience_job::STATUS_PENDING,
        ]);
        $job->create();
        return $job;
    }

    /**
     * The task computes a pending job's count and marks it ready.
     *
     * @return void
     */
    public function test_execute_resolves_pending_job_to_ready(): void {
        $this->setAdminUser();
        $generator = $this->getDataGenerator();
        $cohort = $generator->create_cohort();
        cohort_add_member($cohort->id, $generator->create_user()->id);
        cohort_add_member($cohort->id, $generator->create_user()->id);

        $job = $this->create_pending_job(['cohorts' => [$cohort->id]]);

        $task = new estimate_audience();
        $task->set_custom_data(['jobid' => $job->get('jobid')]);
        $task->execute();

        $reloaded = audience_job::get_record(['jobid' => $job->get('jobid')]);
        $this->assertSame(audience_job::STATUS_READY, $reloaded->get('status'));
        $this->assertSame(2, (int) $reloaded->get('resultcount'));
        $this->assertNotNull($reloaded->get('timecompleted'));
    }

    /**
     * Running the task again over a job already marked ready changes nothing.
     *
     * An adhoc task can be retried, so a second run must not recompute a stored answer or move a
     * job backwards out of its completed state.
     *
     * @return void
     */
    public function test_execute_is_idempotent_on_already_completed_job(): void {
        $this->setAdminUser();
        $generator = $this->getDataGenerator();
        $cohort = $generator->create_cohort();

        $job = $this->create_pending_job(['cohorts' => [$cohort->id]]);
        $job->set('status', audience_job::STATUS_READY);
        $job->set('resultcount', 99);
        $job->set('timecompleted', time() - 60);
        $job->update();

        $task = new estimate_audience();
        $task->set_custom_data(['jobid' => $job->get('jobid')]);
        // The task reports through mtrace(); capturing it keeps the test from being marked
        // risky and lets the skip be asserted rather than inferred from the count alone.
        ob_start();
        $task->execute();
        $output = (string) ob_get_clean();

        $this->assertStringContainsString('already in status ready', $output);

        $reloaded = audience_job::get_record(['jobid' => $job->get('jobid')]);
        $this->assertSame(
            99,
            (int) $reloaded->get('resultcount'),
            'Already-ready job must not be recomputed.'
        );
    }

    /**
     * A task whose job has been purged reports and returns instead of throwing.
     *
     * A throwing adhoc task is retried for ever, so a permanent failure has to end quietly with a
     * trace rather than by raising.
     *
     * @return void
     */
    public function test_execute_with_unknown_jobid_does_not_throw(): void {
        $jobid = 'does-not-exist-' . time();

        // Precondition: without this the test would pass even if the lookup were removed.
        $this->assertFalse(audience_job::get_record(['jobid' => $jobid]));

        $task = new estimate_audience();
        $task->set_custom_data(['jobid' => $jobid]);
        ob_start();
        $task->execute();
        $output = (string) ob_get_clean();

        $this->assertStringContainsString('not found', $output);
    }
}

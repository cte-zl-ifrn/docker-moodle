<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_awareness\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;
use local_awareness\persistent\noticeview;

/**
 * Tests for the privacy provider's request and userlist implementations.
 *
 * The audit closed four findings here — the audience-jobs table missing from the provider
 * entirely, and the contextlist, the userlist and the erasure each looking only at
 * local_awareness_lastview — and nothing guarded any of them afterwards. Core's own
 * compliance test checks that a table carrying a userid is DECLARED; it never calls
 * export_user_data() or any delete method, so every one of those repairs could have been
 * reverted with the suite green.
 *
 * Each table therefore gets its own case, seeded ALONE. Seeding a user with all four rows
 * at once would pass just as happily against the lastview-only SQL the findings describe,
 * because lastview would carry the whole assertion.
 *
 * @package    local_awareness
 * @copyright  2026 Anderson Blaine
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @covers \local_awareness\privacy\provider
 */
final class provider_test extends \advanced_testcase {
    /**
     * Start every test with an empty writer.
     *
     * The privacy writer is a static singleton that survives between tests in a run. Without this,
     * an export assertion can be satisfied by data a PREVIOUS test wrote — the exact vacuity this
     * repository has shipped before, and the reason the guard test below would otherwise pass
     * against an export that writes nothing at all.
     *
     * @return void
     */
    protected function setUp(): void {
        parent::setUp();
        writer::reset();
    }

    /**
     * Every user-linked table, and a closure seeding exactly one row of it for a user.
     *
     * @return array
     */
    public static function table_provider(): array {
        return [
            'lastview' => ['local_awareness_lastview'],
            'acknowledgement' => ['local_awareness_ack'],
            'link click history' => ['local_awareness_hlinks_his'],
            'audience job' => ['local_awareness_audience_jobs'],
        ];
    }

    /**
     * Write one row into the named table for the given user, and nothing into any other.
     *
     * @param string $table One of the four user-linked table names.
     * @param int $userid User to attribute the row to.
     */
    private function seed_one(string $table, int $userid): void {
        global $DB;

        switch ($table) {
            case 'local_awareness_lastview':
                $DB->insert_record('local_awareness_lastview', (object) [
                    'noticeid' => 7,
                    'userid' => $userid,
                    'action' => '1',
                    'timecreated' => time(),
                    'timemodified' => time(),
                ]);
                break;
            case 'local_awareness_ack':
                $DB->insert_record('local_awareness_ack', (object) [
                    'userid' => $userid,
                    'username' => 'someone',
                    'firstname' => 'Some',
                    'lastname' => 'One',
                    'idnumber' => 'ID1',
                    'noticeid' => 7,
                    'noticetitle' => 'Policy update',
                    'action' => 1,
                    'timecreated' => time(),
                ]);
                break;
            case 'local_awareness_hlinks_his':
                $DB->insert_record('local_awareness_hlinks_his', (object) [
                    'hlinkid' => 3,
                    'userid' => $userid,
                    'timecreated' => time(),
                ]);
                break;
            case 'local_awareness_audience_jobs':
                $DB->insert_record('local_awareness_audience_jobs', (object) [
                    'jobid' => 'job-' . $userid,
                    'userid' => $userid,
                    'noticeid' => 7,
                    'criteriahash' => str_repeat('a', 64),
                    'criteria' => '[]',
                    'status' => 'ready',
                    'timecreated' => time(),
                ]);
                break;
            default:
                throw new \coding_exception('Unknown table ' . $table);
        }
    }

    /**
     * Count this plugin's rows held for one user across all four tables.
     *
     * @param int $userid User id.
     * @return int Total rows.
     */
    private function row_count(int $userid): int {
        global $DB;

        $total = 0;
        foreach (array_column(self::table_provider(), 0) as $table) {
            $total += $DB->count_records($table, ['userid' => $userid]);
        }
        return $total;
    }

    /**
     * A row in any single user-linked table is enough to put the user's context in the list.
     *
     * @dataProvider table_provider
     * @param string $table The table seeded on its own.
     */
    public function test_get_contexts_for_userid_sees_every_table(string $table): void {
        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();
        $untouched = $this->getDataGenerator()->create_user();

        // The precondition the whole case rests on: before seeding, the user has no context.
        // Without this a provider that returned every user context unconditionally would pass.
        $this->assertCount(0, provider::get_contexts_for_userid((int) $user->id)->get_contextids());

        $this->seed_one($table, (int) $user->id);

        $contextids = provider::get_contexts_for_userid((int) $user->id)->get_contextids();
        $this->assertEquals(
            [\context_user::instance($user->id)->id],
            array_map('intval', $contextids),
            "a row in {$table} alone must yield the user context"
        );

        // Control: a user with no rows at all stays out, so the assertion above is about the row.
        $this->assertCount(0, provider::get_contexts_for_userid((int) $untouched->id)->get_contextids());
    }

    /**
     * The userlist path reaches every table too — it is what makes delete_data_for_users run.
     *
     * @dataProvider table_provider
     * @param string $table The table seeded on its own.
     */
    public function test_get_users_in_context_sees_every_table(string $table): void {
        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();
        $context = \context_user::instance($user->id);

        $empty = new userlist($context, 'local_awareness');
        provider::get_users_in_context($empty);
        $this->assertEmpty($empty->get_userids());

        $this->seed_one($table, (int) $user->id);

        $userlist = new userlist($context, 'local_awareness');
        provider::get_users_in_context($userlist);
        $this->assertEquals(
            [(int) $user->id],
            array_map('intval', $userlist->get_userids()),
            "a row in {$table} alone must put the user in the userlist"
        );
    }

    /**
     * A context that is not a user context yields nobody.
     */
    public function test_get_users_in_context_ignores_non_user_contexts(): void {
        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();
        $this->seed_one('local_awareness_lastview', (int) $user->id);

        // Control: the same seeded row IS found through the user context, so an empty result
        // below means the context check rejected it rather than the seeding having failed.
        $userlist = new userlist(\context_user::instance($user->id), 'local_awareness');
        provider::get_users_in_context($userlist);
        $this->assertCount(1, $userlist->get_userids());

        $systemlist = new userlist(\context_system::instance(), 'local_awareness');
        provider::get_users_in_context($systemlist);
        $this->assertEmpty($systemlist->get_userids());
    }

    /**
     * Export ships all four tables, and only the requesting user's rows.
     */
    public function test_export_user_data_ships_every_table(): void {
        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();
        $other = $this->getDataGenerator()->create_user();
        foreach (array_column(self::table_provider(), 0) as $table) {
            $this->seed_one($table, (int) $user->id);
            $this->seed_one($table, (int) $other->id);
        }

        $context = \context_user::instance($user->id);
        provider::export_user_data(new approved_contextlist(
            $user,
            'local_awareness',
            [$context->id]
        ));

        $writer = writer::with_context($context);
        $this->assertTrue($writer->has_any_data());

        $data = $writer->get_data([get_string('pluginname', 'local_awareness')]);
        foreach (['lastview', 'acknowledgement', 'linktracking', 'audiencejobs'] as $key) {
            $this->assertNotEmpty($data->$key, "export is missing the {$key} rows");
            foreach ($data->$key as $row) {
                $this->assertEquals(
                    (int) $user->id,
                    (int) $row->userid,
                    "export leaked another user's {$key} row"
                );
            }
        }
    }

    /**
     * Erasure by context removes every table's rows and leaves other users alone.
     */
    public function test_delete_data_for_all_users_in_context_clears_every_table(): void {
        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();
        $bystander = $this->getDataGenerator()->create_user();
        foreach (array_column(self::table_provider(), 0) as $table) {
            $this->seed_one($table, (int) $user->id);
            $this->seed_one($table, (int) $bystander->id);
        }
        $this->assertSame(4, $this->row_count((int) $user->id));

        provider::delete_data_for_all_users_in_context(\context_user::instance($user->id));

        $this->assertSame(0, $this->row_count((int) $user->id));
        // Control: erasure that deleted the whole table would pass the line above.
        $this->assertSame(4, $this->row_count((int) $bystander->id));
    }

    /**
     * A non-user context must not trigger erasure.
     */
    public function test_delete_data_for_all_users_in_context_ignores_non_user_contexts(): void {
        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();
        foreach (array_column(self::table_provider(), 0) as $table) {
            $this->seed_one($table, (int) $user->id);
        }

        provider::delete_data_for_all_users_in_context(\context_system::instance());

        $this->assertSame(4, $this->row_count((int) $user->id));
    }

    /**
     * Erasure through the contextlist path clears every table.
     */
    public function test_delete_data_for_user_clears_every_table(): void {
        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();
        $bystander = $this->getDataGenerator()->create_user();
        foreach (array_column(self::table_provider(), 0) as $table) {
            $this->seed_one($table, (int) $user->id);
            $this->seed_one($table, (int) $bystander->id);
        }

        provider::delete_data_for_user(new approved_contextlist(
            $user,
            'local_awareness',
            [\context_user::instance($user->id)->id]
        ));

        $this->assertSame(0, $this->row_count((int) $user->id));
        $this->assertSame(4, $this->row_count((int) $bystander->id));
    }

    /**
     * Erasure through the approved userlist clears every table.
     */
    public function test_delete_data_for_users_clears_every_table(): void {
        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();
        $bystander = $this->getDataGenerator()->create_user();
        foreach (array_column(self::table_provider(), 0) as $table) {
            $this->seed_one($table, (int) $user->id);
            $this->seed_one($table, (int) $bystander->id);
        }

        provider::delete_data_for_users(new approved_userlist(
            \context_user::instance($user->id),
            'local_awareness',
            [(int) $user->id]
        ));

        $this->assertSame(0, $this->row_count((int) $user->id));
        $this->assertSame(4, $this->row_count((int) $bystander->id));
    }

    /**
     * A userlist the data-request approver did NOT approve must delete nothing.
     *
     * The context of a user context names exactly one user, so it is tempting to take the
     * userid from the context and ignore the list. That reads the same in the passing case
     * and inverts the meaning of approval in this one: the approver withheld consent and the
     * rows go anyway.
     */
    public function test_delete_data_for_users_respects_an_empty_approved_list(): void {
        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();
        foreach (array_column(self::table_provider(), 0) as $table) {
            $this->seed_one($table, (int) $user->id);
        }

        provider::delete_data_for_users(new approved_userlist(
            \context_user::instance($user->id),
            'local_awareness',
            []
        ));

        $this->assertSame(4, $this->row_count((int) $user->id));
    }

    /**
     * Erasure drops the user's MUC view cache, not only their database rows.
     *
     * The view records are read through a MODE_APPLICATION cache keyed by user id. A bulk
     * $DB->delete_records() does not notify it, so without an explicit purge the deleted
     * user's viewing history stays readable from the cache for the rest of its life.
     */
    public function test_erasure_purges_the_view_cache(): void {
        global $USER;

        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();
        $this->setUser($user);
        noticeview::add_notice_view(7, (int) $user->id, 1);

        // Populate the cache through the read path, and prove it really is populated —
        // otherwise the assertion after erasure is satisfied by a cache that was never warm.
        noticeview::get_user_viewed_notice_records();
        $cache = \cache::make('local_awareness', 'notice_view');
        $this->assertNotFalse($cache->get((string) $USER->id));

        provider::delete_data_for_all_users_in_context(\context_user::instance($user->id));

        $this->assertFalse($cache->get((string) $USER->id));
    }

    /**
     * The declaration names every column the export actually ships.
     *
     * These are two halves of one promise and they had drifted. export_user_data() selects
     * `lv.*`, `ack.*`, `his.*` and `job.*` — whole rows — while get_metadata() named a subset, and
     * the declaration is the half a data subject reads BEFORE deciding whether to ask. A narrower
     * declaration than the export is not a smaller disclosure, it is an inaccurate one.
     *
     * The comparison is made against the real table columns rather than a list written here, so
     * adding a column to any of the four tables without declaring it turns this red — which is the
     * drift that produced the finding in the first place.
     */
    public function test_the_declaration_names_every_exported_column(): void {
        global $DB;

        $this->resetAfterTest();

        $declared = [];
        foreach (provider::get_metadata(new collection('local_awareness'))->get_collection() as $item) {
            if (method_exists($item, 'get_privacy_fields') && $item->get_privacy_fields() !== null) {
                $declared[$item->get_name()] = array_keys($item->get_privacy_fields());
            }
        }

        foreach (array_column(self::table_provider(), 0) as $table) {
            $this->assertArrayHasKey($table, $declared, "{$table} is exported but not declared at all");

            // Every column of the row the export ships, minus the surrogate key.
            $columns = array_keys($DB->get_columns($table));
            $columns = array_values(array_diff($columns, ['id']));
            $this->assertNotEmpty($columns, "no columns read for {$table} — the check would pass blind");

            $missing = array_values(array_diff($columns, $declared[$table]));
            $this->assertSame(
                [],
                $missing,
                "{$table}: export ships these columns and get_metadata() does not declare them: "
                    . implode(', ', $missing)
            );
        }
    }

    /**
     * The notice table is declared for its author column, and deliberately never acted on.
     *
     * core\persistent stamps local_awareness.usermodified on every create and update, so a user id
     * is stored there and has to be declared. It is NOT exported or erased, and that is the
     * decision rather than an omission: a notice is site configuration, and blanking the column
     * would rewrite the record of who published a site-wide announcement. Core treats its own
     * admin-authored configuration the same way — analytics_models and the oauth2_* tables each
     * carry a usermodified-only entry with no export and no erasure.
     *
     * Asserting the second half is what stops a future reader "completing" the provider by wiring
     * this table into the delete paths.
     */
    public function test_the_notice_table_is_declared_but_never_erased(): void {
        global $DB;

        $this->resetAfterTest();

        $declared = [];
        foreach (provider::get_metadata(new collection('local_awareness'))->get_collection() as $item) {
            if (method_exists($item, 'get_privacy_fields') && $item->get_privacy_fields() !== null) {
                $declared[$item->get_name()] = array_keys($item->get_privacy_fields());
            }
        }

        $this->assertArrayHasKey('local_awareness', $declared);
        $this->assertSame(['usermodified'], $declared['local_awareness']);

        // The author's notice survives erasure of the author.
        $author = $this->getDataGenerator()->create_user();
        $noticeid = $DB->insert_record('local_awareness', (object) [
            'title' => 'Policy update',
            'content' => '<p>Read the policy.</p>',
            'contentformat' => FORMAT_HTML,
            'usermodified' => $author->id,
            'timecreated' => time(),
            'timemodified' => time(),
        ]);

        provider::delete_data_for_all_users_in_context(\context_user::instance($author->id));

        $this->assertSame(
            (int) $author->id,
            (int) $DB->get_field('local_awareness', 'usermodified', ['id' => $noticeid]),
            'erasing the author must not rewrite who published the notice'
        );
    }

    /**
     * The export goes only into the subject's own user context.
     *
     * The loop used to iterate the contextlist without ever reading $context, so every context in
     * it received the identical, complete payload. get_contexts_for_userid() only ever adds this
     * user's own context, so the list cannot hold a foreign one today — but delete_data_for_user()
     * carries this very check, and an export that trusts what an erasure verifies is the asymmetry
     * worth removing.
     *
     * @return void
     */
    public function test_export_writes_nothing_into_a_foreign_context(): void {
        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();
        foreach (array_column(self::table_provider(), 0) as $table) {
            $this->seed_one($table, (int) $user->id);
        }

        $course = $this->getDataGenerator()->create_course();
        $foreign = \context_course::instance($course->id);

        provider::export_user_data(new approved_contextlist($user, 'local_awareness', [$foreign->id]));

        $this->assertFalse(
            writer::with_context($foreign)->has_any_data(),
            'the export wrote this user\'s data into a context that is not theirs'
        );

        /*
         * Control: the same seeded user, exported into their OWN context, DOES produce data.
         * Without it, "wrote nothing" is satisfied by an export_user_data() that does nothing at
         * all — including one whose body has been deleted.
         */
        $own = \context_user::instance($user->id);
        provider::export_user_data(new approved_contextlist($user, 'local_awareness', [$own->id]));
        $this->assertTrue(writer::with_context($own)->has_any_data(), 'the control export produced nothing');
    }

    /**
     * Exported rows carry dates and names, not unix integers and bare ids.
     *
     * A data export is read by the person it is about. A row saying noticeid 7 at 1787500000 tells
     * them nothing about what they actually saw or when.
     *
     * @return void
     */
    public function test_the_export_is_readable(): void {
        global $DB;

        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();

        $notice = new \local_awareness\persistent\awareness(0, (object) [
            'title' => 'Safety & Conduct',
            'content' => '<p>Read it.</p>',
        ]);
        $notice->create();

        $DB->insert_record('local_awareness_lastview', (object) [
            'noticeid' => $notice->get('id'),
            'userid' => $user->id,
            'action' => 1,
            'timecreated' => 1787500000,
            'timemodified' => 1787500000,
        ]);

        $context = \context_user::instance($user->id);
        provider::export_user_data(new approved_contextlist($user, 'local_awareness', [$context->id]));

        $data = writer::with_context($context)->get_data([get_string('pluginname', 'local_awareness')]);
        $row = reset($data->lastview);

        $this->assertNotEmpty($row, 'the export shipped no view row — this assertion is blind');

        // The timestamp is a date, not the integer that went in.
        $this->assertNotEquals('1787500000', (string) $row->timecreated, 'the timestamp is still a raw integer');
        $this->assertStringContainsString('2026', (string) $row->timecreated, 'the timestamp is not a readable date');

        // The internal id is accompanied by the thing it names, escaped for the sink.
        $this->assertSame('Safety &amp; Conduct', $row->noticename);
        $this->assertEquals($notice->get('id'), $row->noticeid, 'the id itself must stay, so the row can be reconciled');
    }

    /**
     * A view row whose notice has since been deleted still exports, simply unnamed.
     *
     * Click history deliberately outlives the notice it belongs to, so a missing target is an
     * ordinary state and must not be treated as an error.
     *
     * @return void
     */
    public function test_the_export_tolerates_a_deleted_notice(): void {
        $this->resetAfterTest();

        $user = $this->getDataGenerator()->create_user();
        $this->seed_one('local_awareness_lastview', (int) $user->id);

        $context = \context_user::instance($user->id);
        provider::export_user_data(new approved_contextlist($user, 'local_awareness', [$context->id]));

        $data = writer::with_context($context)->get_data([get_string('pluginname', 'local_awareness')]);
        $row = reset($data->lastview);

        $this->assertNotEmpty($row, 'the export shipped no view row at all');
        $this->assertObjectNotHasProperty('noticename', $row, 'a deleted notice was given a name');
    }
}

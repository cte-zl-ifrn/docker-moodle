<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_awareness\local;

/**
 * Guards the plugin's Bootstrap 4 / Bootstrap 5 contract.
 *
 * Moodle 4.5 ships Bootstrap 4 and 5.0+ ship Bootstrap 5, and the bridging is asymmetric:
 * 4.5's forward bridge (theme/boost/scss/moodle/bs5-bridge.scss) is 116 lines covering only
 * g-0, btn-close, the ms/me/ps/pe spacers and float/text/border/rounded-start/end, while 5.x's
 * backward bridge runs past a thousand. A BS5 utility outside that short list resolves to
 * nothing on 4.5.
 *
 * This defect class has shipped three times - see CHANGELOG.md and commit f84d30a - and was
 * correctly root-caused and documented each time. It recurred anyway, and a 2026-08-06 sweep
 * still found 90 sites. The reason is enforcement, not diligence: the sibling rule about JS
 * data attributes has held at 100% compliance because the 4.05 Behat leg throws when a dropdown
 * fails to open, while the class rules failed silently with CI fully green. Nothing else in the
 * pipeline can see a class name that resolves to nothing - not phpcs, not the mustache lint, not
 * stylelint, which never reads a Mustache or JS file. This test is that missing observer.
 *
 * @package    local_awareness
 * @copyright  2026 Anderson Blaine
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @covers \local_awareness\local\bootstrap
 */
final class bootstrap_compat_test extends \basic_testcase {
    /**
     * Bootstrap 5 utilities that do not exist on Moodle 4.5.
     *
     * Each entry maps a regular expression matching the class in a class attribute or a JS class
     * string to the human-readable family name reported when it is found unpolyfilled. Source of
     * truth for what 4.5 does bridge: theme/boost/scss/moodle/bs5-bridge.scss.
     *
     * @return array Regex => family label.
     */
    private function bs5_only_utilities(): array {
        /*
         * Re-measured on the running stacks on 2026-08-15 by diffing the class vocabulary of the
         * compiled theme CSS — 9108 selectors on 4.5 (boost_union) against 9815 on 5.2 (boost).
         * Two caveats that make the raw diff lie, both handled here: the compiled sheet contains
         * every plugin mounted on that stack, so plugin-owned names look like core's; and a family
         * this plugin already polyfills disappears from the diff, which is why gap-*, fw-*,
         * form-select, form-label and lh-1 had to be confirmed by reading the rule that defines
         * them (all of them resolved to body.local-awareness-bs4, i.e. to us, not to 4.5).
         *
         * The list is wider than current usage on purpose: it is a detector, not a polyfill, and
         * it costs nothing until somebody reaches for one of these.
         */
        return [
            '/\\bform-select(-sm|-lg)?\\b/' => 'form-select',
            '/\\bform-label\\b/' => 'form-label',
            '/\\bform-switch\\b/' => 'form-switch',
            '/\\bform-check-reverse\\b/' => 'form-check-reverse',
            '/\\bfw-(bold|semibold|light|lighter|bolder|medium|normal)\\b/' => 'fw-*',
            '/\\bfs-[1-6]\\b/' => 'fs-*',
            '/\\bfst-italic\\b/' => 'fst-italic',
            '/\\bfont-monospace\\b/' => 'font-monospace',
            '/\\bgap-([a-z]{2}-)?[0-9]\\b/' => 'gap-*',
            '/\\b(row|column)-gap-[0-9]\\b/' => 'row-gap-* / column-gap-*',
            '/\\bg-[1-6]\\b/' => 'g-*',
            '/\\blh-(1|base|lg|sm)\\b/' => 'lh-*',
            '/\\bd-grid\\b/' => 'd-grid',
            '/\\bvisually-hidden(-focusable)?\\b/' => 'visually-hidden',
            '/\\btext-bg-[a-z]+\\b/' => 'text-bg-*',
            '/\\bbg-body(-secondary|-tertiary)?\\b/' => 'bg-body*',
            '/\\bborder-[1-5]\\b/' => 'border-*',
            '/\\bobject-fit-[a-z]+\\b/' => 'object-fit-*',
            '/\\bz-[0-3]\\b/' => 'z-*',
            '/\\btranslate-middle(-[xy])?\\b/' => 'translate-middle',
            // The lookbehind keeps border-top-0 / border-bottom-0 out: those are border utilities,
            // present on both branches, and share the suffix with the BS5-only positional ones.
            '/(?<!border-)\\b(top|bottom|start|end)-(0|50|100)\\b/' => 'top-* / bottom-* / start-* / end-*',
            '/\\bratio(-[0-9]+x[0-9]+)?\\b/' => 'ratio*',
            '/\\bvr\\b/' => 'vr',
            '/\\bfst-normal\\b/' => 'fst-normal',
            /*
             * The three the layouts reached for first, measured absent from 4.5's compiled Boost
             * and Boost Union sheets (0 rules each) and present on 5.2: rounded-1..5 (Bootstrap 4
             * has rounded-lg only), sticky-bottom, and modal-fullscreen with its -down variants.
             */
            '/\\brounded-[1-5]\\b/' => 'rounded-*',
            '/\\bsticky-bottom\\b/' => 'sticky-bottom',
            '/\\bmodal-fullscreen(-[a-z]{2,3}-down)?\\b/' => 'modal-fullscreen*',
        ];
    }

    /**
     * Bootstrap 4 class names that Moodle 5.x back-ports but marks deprecated.
     *
     * The asymmetry runs both ways. These names DO resolve on 5.x, through bs4-compat.scss — but
     * every one of them is wrapped in @include deprecated-styles(), which paints a red outline
     * under behat-site and themedesignermode, and Moodle 6.0 removes that sheet entirely
     * (MDL-84465). Their Bootstrap 5 spellings are all inside the 116-line forward bridge Moodle
     * 4.5 ships, so the BS5 name alone is correct on both branches.
     *
     * Writing both spellings side by side therefore buys nothing and costs a deprecation: it is
     * the mistake this rule exists to stop, and it had shipped once, in the collision badge.
     *
     * @return array Regex matching the deprecated name => the Bootstrap 5 spelling to use instead.
     */
    private function deprecated_bs4_names(): array {
        return [
            '/\\bml-([0-9]|auto)\\b/' => 'ms-*',
            '/\\bmr-([0-9]|auto)\\b/' => 'me-*',
            '/\\bpl-[0-9]\\b/' => 'ps-*',
            '/\\bpr-[0-9]\\b/' => 'pe-*',
            '/\\btext-left\\b/' => 'text-start',
            '/\\btext-right\\b/' => 'text-end',
            '/\\bfloat-left\\b/' => 'float-start',
            '/\\bfloat-right\\b/' => 'float-end',
            '/\\bborder-left\\b/' => 'border-start',
            '/\\bborder-right\\b/' => 'border-end',
            '/\\brounded-left\\b/' => 'rounded-start',
            '/\\brounded-right\\b/' => 'rounded-end',
            '/\\bsr-only(-focusable)?\\b/' => 'visually-hidden',
            '/\\bno-gutters\\b/' => 'g-0',
        ];
    }

    /**
     * Saturated background utilities that need an explicit light text colour.
     *
     * Bootstrap 4's .badge sets no colour at all, so a saturated badge renders near-black text
     * on a dark fill; Bootstrap 5's .badge defaults to white, so a LIGHT background renders white
     * on near-white. Both directions were measured on the running stacks: bg-success gives 3.07:1
     * on 4.5 and bg-secondary gives 1.49:1 on 5.2, against the 4.5:1 AA floor. The only markup
     * that is correct on both branches states its text colour explicitly.
     *
     * @return array Background utility => the text utility it requires.
     */
    private function badge_text_colours(): array {
        return [
            'bg-success' => 'text-white',
            'bg-primary' => 'text-white',
            'bg-danger' => 'text-white',
            'bg-info' => 'text-white',
            'bg-dark' => 'text-white',
            'bg-secondary' => 'text-dark',
            'bg-warning' => 'text-dark',
        ];
    }

    /**
     * Absolute path to the plugin root.
     *
     * @return string Plugin directory without a trailing separator.
     */
    private function plugin_root(): string {
        return dirname(__DIR__, 2);
    }

    /**
     * Every file whose contents can put a class name in front of a user.
     *
     * Skips amd/build (generated from amd/src) and docs (not shipped, and .gitattributes keeps it
     * out of the release zip).
     *
     * @return array List of absolute file paths.
     */
    private function markup_files(): array {
        $root = $this->plugin_root();

        /*
         * An EXCLUSION list walked from the plugin root, not an inclusion list of three
         * directories. The inclusion form named templates/, amd/src/ and classes/, which meant
         * report/, renderer.php and every entry point at the root were outside every assertion in
         * this file — and report/*_systemreport.php is exactly the kind of page that emits markup
         * by hand. An inclusion list also fails silently the day a new directory appears: nothing
         * reports that it is unscanned, because nothing knows it should have been.
         */
        $skip = ['amd/build', 'tests', 'docs', 'lang', '.git', 'node_modules', 'vendor'];

        $files = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            if (!$file->isFile()) {
                continue;
            }
            if (!in_array($file->getExtension(), ['mustache', 'js', 'php'], true)) {
                continue;
            }
            $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
            foreach ($skip as $prefix) {
                if (str_starts_with($relative, $prefix . '/')) {
                    continue 2;
                }
            }
            $files[] = $file->getPathname();
        }
        sort($files);
        return $files;
    }

    /**
     * Whether a line is prose rather than markup.
     *
     * The rules below are about what reaches the browser. A comment that names an attribute in
     * order to explain the rule - as amd/src/central/context.js does - is not a violation of it.
     *
     * @param string $line One raw source line.
     * @return bool True when the line opens with a PHP, JS or Mustache comment marker.
     */
    private function is_comment_line(string $line): bool {
        $trimmed = ltrim($line);

        return $trimmed === ''
            || str_starts_with($trimmed, '//')
            || str_starts_with($trimmed, '/*')
            || str_starts_with($trimmed, '*')
            || str_starts_with($trimmed, '{{!');
    }

    /**
     * The exact class tokens the polyfill block defines behind the Bootstrap 4 gate.
     *
     * Deliberately token-level, not family-level. A family-level check ("is gap-* covered?")
     * passes while gap-2 alone is missing, which is precisely the silent gap this whole test
     * exists to close.
     *
     * @return array List of class tokens, e.g. gap-2, without the leading dot.
     */
    private function polyfilled_tokens(): array {
        $css = file_get_contents($this->plugin_root() . '/styles.css');
        /* Strip comments first: the block's own prose names files and classes it does not define. */
        $css = preg_replace('~/\*.*?\*/~s', '', $css);
        $gate = preg_quote(bootstrap::BODY_CLASS_BS4, '/');
        $tokens = [];
        foreach (explode('}', $css) as $block) {
            $selector = explode('{', $block)[0];
            if (!preg_match('/body\.' . $gate . '\b/', $selector)) {
                continue;
            }
            preg_match_all('/\.([a-z][a-z0-9-]*)/', $selector, $matches);
            foreach ($matches[1] as $token) {
                $tokens[] = $token;
            }
        }
        return array_values(array_unique($tokens));
    }

    /**
     * The exact Bootstrap 5 class tokens the plugin emits that 4.5 does not define.
     *
     * @return array Token => list of file basenames using it.
     */
    private function used_bs5_tokens(): array {
        $used = [];
        foreach ($this->markup_files() as $path) {
            foreach (file($path) as $line) {
                if ($this->is_comment_line($line)) {
                    continue;
                }
                foreach ($this->bs5_only_utilities() as $pattern => $unusedlabel) {
                    if (!preg_match_all($pattern, $line, $matches)) {
                        continue;
                    }
                    foreach ($matches[0] as $token) {
                        $used[$token][basename($path)] = true;
                    }
                }
            }
        }
        return array_map('array_keys', $used);
    }

    /**
     * Every Bootstrap 5 class the plugin emits must be defined by the polyfill for 4.5.
     *
     * @return void
     */
    public function test_every_bs5_utility_used_is_polyfilled(): void {
        $polyfilled = $this->polyfilled_tokens();
        $used = $this->used_bs5_tokens();

        /*
         * Non-vacuity on both sides. "Every used token is polyfilled" is satisfied by a plugin that
         * uses none, and by a scan that finds none — and those two look identical from here.
         */
        $this->assertNotEmpty($used, 'Found no Bootstrap 5 utility in the markup — the scan is broken, not the code.');
        $this->assertNotEmpty($polyfilled, 'Found no polyfill rules in styles.css — the scan is broken, not the code.');

        $missing = [];
        foreach ($used as $token => $files) {
            if (!in_array($token, $polyfilled, true)) {
                $missing[] = $token . ' (used in ' . implode(', ', array_slice($files, 0, 3)) . ')';
            }
        }
        sort($missing);
        $this->assertSame(
            [],
            $missing,
            'These Bootstrap 5 classes are used but resolve to nothing on Moodle 4.5. Either add them '
                . 'to the Bootstrap 4 utility polyfill at the tail of styles.css, or stop using them: '
                . implode('; ', $missing)
        );
    }

    /**
     * The polyfill must not grow rules for classes the plugin no longer uses.
     *
     * A compatibility layer that outlives its callers is how a temporary shim becomes permanent.
     *
     * @return void
     */
    public function test_polyfill_carries_nothing_unused(): void {
        $used = array_keys($this->used_bs5_tokens());
        $polyfilled = $this->polyfilled_tokens();

        /*
         * One structural entry, not ten. The list used to name form-check, btn-close, modal and
         * friends as "helpers the polyfill needs", plus local-dimensions-central-page, which
         * belongs to a different plugin entirely. Measured against styles.css, NINE of the ten
         * named nothing this polyfill defines — so they excluded classes that were never in the
         * result, and the prose describing them described rules that do not exist here. The body
         * gate is the only real one: it is the selector every polyfill rule hangs off, so it can
         * never appear as a class the markup "uses".
         */
        $structural = [bootstrap::BODY_CLASS_BS4];

        $this->assertNotEmpty($polyfilled, 'Found no polyfill rules in styles.css — the scan is broken, not the code.');

        $unused = array_values(array_diff($polyfilled, $used, $structural));
        sort($unused);
        $this->assertSame(
            [],
            $unused,
            'The Bootstrap 4 polyfill defines classes nothing uses any more; delete them: '
                . implode(', ', $unused)
        );
    }

    /**
     * The Bootstrap data-API spellings missing from one line.
     *
     * Extracted from the sweep so the rule can be asserted against fixtures. With no live offender
     * anywhere in the plugin, a test that only walks the tree cannot tell a working detector from a
     * deleted one.
     *
     * @param string $line One line of markup.
     * @return array The attribute names present without their counterpart, in declaration order.
     */
    private function data_api_offences(string $line): array {
        $pairs = [
            'data-toggle' => 'data-bs-toggle',
            'data-target' => 'data-bs-target',
            'data-dismiss' => 'data-bs-dismiss',
            'data-parent' => 'data-bs-parent',
        ];

        /*
         * data-target and data-parent are only Bootstrap's when a toggle sits beside them; on their
         * own they are ordinary custom attributes, and this plugin uses data-target as its own hook.
         */
        $wired = preg_match('/(?<![-\w])data-(bs-)?toggle(?![-\w])/', $line);

        $offences = [];
        foreach ($pairs as $bs4 => $bs5) {
            if (!$wired && in_array($bs4, ['data-target', 'data-parent'], true)) {
                continue;
            }
            /* Match the attribute itself, never a longer name that merely starts with it. */
            $hasbs4 = preg_match('/(?<![-\w])' . preg_quote($bs4, '/') . '(?![-\w])/', $line);
            $hasbs5 = preg_match('/(?<![-\w])' . preg_quote($bs5, '/') . '(?![-\w])/', $line);
            if ($hasbs4 !== $hasbs5) {
                $offences[] = $hasbs4 ? $bs4 : $bs5;
            }
        }

        return $offences;
    }

    /**
     * Every badge background must state its text colour, so it reads on both branches.
     *
     * @return void
     */
    public function test_badges_state_their_text_colour(): void {
        /*
         * Checked on every line carrying a background utility, NOT only lines that also say
         * "badge". An earlier version filtered on that word and stayed green against a method whose
         * NAME carried it while the returned class did not.
         *
         * The required colour is matched exactly, not against a set. Accepting any of
         * text-white|dark|body|muted let text-muted and text-body satisfy a saturated background,
         * and neither of those is a contrast answer: the whole point is that Bootstrap 4 gives
         * .badge no colour while Bootstrap 5 defaults it to white, so the pairing has to be the
         * specific one the table names. There is no exception list — every live badge in this
         * plugin already states the right colour, so an exception would only be a place to hide.
         */
        $offenders = [];
        $checked = 0;
        foreach ($this->markup_files() as $path) {
            foreach (file($path) as $number => $line) {
                if ($this->is_comment_line($line)) {
                    continue;
                }
                foreach ($this->badge_text_colours() as $background => $required) {
                    if (!preg_match('/\b' . preg_quote($background, '/') . '\b/', $line)) {
                        continue;
                    }
                    $checked++;
                    if (!preg_match('/\b' . preg_quote($required, '/') . '\b/', $line)) {
                        $offenders[] = basename($path) . ':' . ($number + 1) . ' needs ' . $required;
                    }
                }
            }
        }

        /*
         * Non-vacuity: the sweep found background utilities at all. Without it the assertion below
         * is satisfied by a scan that reads nothing — which is what a renamed template directory or
         * a broken markup_files() would produce, and it would read as a pass.
         */
        $this->assertGreaterThan(0, $checked, 'Found no background utility to check — the scan is broken, not the code.');

        $this->assertSame(
            [],
            $offenders,
            'Bootstrap 4 gives .badge no text colour and Bootstrap 5 defaults it to white, so a badge '
                . 'that does not state its own colour fails contrast on one branch or the other: '
                . implode('; ', $offenders)
        );
    }

    /**
     * A component wired through Bootstrap's markup data-API must carry both attribute spellings.
     *
     * This rule has never been broken, because the 4.05 Behat leg catches it. It is asserted here
     * so the guarantee survives a change in what Behat covers.
     *
     * @return void
     */
    public function test_data_api_attributes_are_paired(): void {
        $offenders = [];
        foreach ($this->markup_files() as $path) {
            foreach (file($path) as $number => $line) {
                if ($this->is_comment_line($line)) {
                    continue;
                }
                foreach ($this->data_api_offences($line) as $offence) {
                    $offenders[] = basename($path) . ':' . ($number + 1) . ' has only ' . $offence;
                }
            }
        }

        /*
         * NO non-vacuity guard here, deliberately, and this is the one place in the file where its
         * absence is correct: the plugin currently wires nothing through Bootstrap's markup
         * data-API, so a count guard would be red on a tree that has no defect to find. The rule is
         * kept honest by test_the_data_api_detector_works instead, which proves the detector can
         * still fail — a guarantee a tree-count could not give at zero sites anyway.
         */
        $this->assertSame(
            [],
            $offenders,
            'Bootstrap 4 listens on data-toggle and Bootstrap 5 on data-bs-toggle, so markup-wired '
                . 'components need both spellings side by side: ' . implode('; ', $offenders)
        );
    }

    /**
     * The pairing detector reports what it should and stays quiet about what it should not.
     *
     * The sweep above reads zero lines today, so without this the rule is an assertion over an
     * empty set: it would keep passing if the detector were deleted, and it would keep passing on
     * the day someone adds an unpaired data-toggle, because by then nobody would think to re-check
     * that the detector still worked. Fixtures let the rule be proven without a live offender.
     *
     * @return void
     */
    public function test_the_data_api_detector_works(): void {
        $paired = 'data-toggle="dropdown" data-bs-toggle="dropdown"';
        $this->assertSame([], $this->data_api_offences($paired), 'a correctly paired toggle was reported');

        $this->assertSame(
            ['data-toggle'],
            $this->data_api_offences('<button data-toggle="dropdown">'),
            'a Bootstrap 4 toggle with no Bootstrap 5 spelling was not reported'
        );
        $this->assertSame(
            ['data-bs-toggle'],
            $this->data_api_offences('<button data-bs-toggle="dropdown">'),
            'a Bootstrap 5 toggle with no Bootstrap 4 spelling was not reported'
        );

        /*
         * data-target on its own is this plugin's own hook, read back with getAttribute, and is not
         * Bootstrap's unless a toggle sits beside it. Requiring a data-bs-target there would be a
         * false positive with no correct fix, so that exemption is asserted rather than trusted.
         */
        $this->assertSame(
            [],
            $this->data_api_offences('<div data-target="competency-list">'),
            'a bare data-target was treated as a Bootstrap hook'
        );
        $this->assertSame(
            ['data-target'],
            $this->data_api_offences('<div data-toggle="collapse" data-bs-toggle="collapse" data-target="#x">'),
            'data-target beside a toggle IS Bootstrap\'s and must be paired'
        );

        // A longer attribute that merely starts with the same characters is not a match.
        $this->assertSame([], $this->data_api_offences('<div data-toggle-mode="x">'), 'a longer name matched');
    }

    /**
     * The markup must never carry a Bootstrap 4 name that Moodle 5.x has deprecated.
     *
     * Includes the paired form — "ml-1 ms-1" — which reads like belt and braces and is instead a
     * deprecation with no upside: ms-1 alone already resolves on 4.5. Skipping comment lines keeps
     * the rule's own prose, and the block comment above the polyfill, from tripping it.
     *
     * @return void
     */
    public function test_markup_carries_no_deprecated_bootstrap4_names(): void {
        $offenders = [];
        $scanned = 0;
        foreach ($this->markup_files() as $path) {
            $scanned++;
            foreach (file($path) as $number => $line) {
                if ($this->is_comment_line($line)) {
                    continue;
                }
                foreach ($this->deprecated_bs4_names() as $pattern => $replacement) {
                    if (preg_match($pattern, $line, $matches)) {
                        $offenders[] = basename($path) . ':' . ($number + 1)
                            . ' has ' . $matches[0] . ', use ' . $replacement;
                    }
                }
            }
        }

        /* A scan that found no files would assert nothing and stay green for ever. */
        $this->assertGreaterThan(0, $scanned, 'Found no markup files to scan — the scan is broken, not the code.');
        $this->assertSame(
            [],
            $offenders,
            'Moodle 5.x back-ports these Bootstrap 4 names only through bs4-compat.scss, which marks '
                . 'them deprecated and which Moodle 6.0 removes; their Bootstrap 5 spellings are in '
                . '4.5\'s own forward bridge, so the BS5 name alone is correct on both branches: '
                . implode('; ', $offenders)
        );
    }

    /**
     * The plugin must not declare custom properties inside core's design-system namespace.
     *
     * Moodle 5.2 ships theme/boost/scss/design-system/ with $mds-* tokens and 5.3 LTS brings MDS
     * React, so an --mds-* declaration in the plugin's stylesheet is squatting a namespace core is
     * actively expanding. The design kit's own --mds-* references document core's palette and are
     * not covered here - only shipped CSS is.
     *
     * @return void
     */
    public function test_stylesheet_declares_no_core_design_system_tokens(): void {
        $root = $this->plugin_root();
        $sheets = array_merge([$root . '/styles.css'], glob($root . '/styles_*.css') ?: []);
        $offenders = [];
        $lines = 0;
        foreach ($sheets as $sheet) {
            foreach (file($sheet) as $number => $line) {
                $lines++;
                /* A declaration, not a mention: the property name followed by its colon. */
                if (preg_match('/--mds-[a-z0-9-]+\s*:/i', $line)) {
                    $offenders[] = basename($sheet) . ':' . ($number + 1);
                }
            }
        }
        // Non-vacuity: a renamed stylesheet would otherwise satisfy this by being unreadable.
        $this->assertGreaterThan(0, $lines, 'Found no stylesheet to read — the scan is broken, not the code.');

        $this->assertSame(
            [],
            $offenders,
            'These lines declare custom properties in core\'s --mds- namespace; use the plugin\'s own '
                . 'prefix instead: ' . implode(', ', $offenders)
        );
    }

    /**
     * The Bootstrap 4 marker must be added wherever the plugin sets one of its page body classes.
     *
     * The polyfill is gated on that marker, so an entry point that forgets it renders unstyled on
     * 4.5 while every static gate stays green.
     *
     * @return void
     */
    public function test_entry_points_mark_the_bootstrap_version(): void {
        $root = $this->plugin_root();
        $offenders = [];
        $pages = 0;
        /*
         * Every PHP file the plugin ships, not glob('*.php') on the root. The root-only form left
         * report/*_systemreport.php outside the check — pages that call $PAGE->set_url() and were
         * never asked whether they mark the Bootstrap version. markup_files() already walks the
         * whole tree with the right exclusions, so the scan reuses it rather than growing a second
         * list that can drift from the first.
         */
        foreach ($this->markup_files() as $path) {
            if (pathinfo($path, PATHINFO_EXTENSION) !== 'php') {
                continue;
            }
            $contents = file_get_contents($path);
            /* A real page, not lib.php or version.php: it gives $PAGE a URL of its own. */
            if (!str_contains($contents, '$PAGE->set_url(')) {
                continue;
            }
            $pages++;
            if (!str_contains($contents, 'bootstrap::mark_page()')) {
                $offenders[] = str_replace($root . '/', '', $path);
            }
        }
        /*
         * Guard against the assertion passing by finding nothing to check. Keyed on a page
         * count rather than on a body class: this plugin sets none, so the local_dimensions
         * version of this test would have looped over an empty set and stayed green forever.
         */
        $this->assertGreaterThan(0, $pages, 'Found no plugin pages to check — the scan is broken, not the code.');
        $this->assertSame(
            [],
            $offenders,
            'These entry points set a plugin body class but never call bootstrap::mark_page(), so the '
                . 'Bootstrap 4 polyfill will not reach them: ' . implode(', ', $offenders)
        );
    }

    /**
     * The Bootstrap 4 verdict follows the core branch and flips at Moodle 5.0.
     *
     * Every rule above is a scan over source text; this one runs the class those scans name, so
     * the coverage this file claims is coverage it actually has. The threshold is the whole
     * behaviour: inverted, the polyfill would ship to 5.x and freeze 4.5's metrics onto it.
     *
     * @return void
     */
    public function test_is_bs4_flips_at_the_first_bootstrap5_branch(): void {
        global $CFG;

        $original = $CFG->branch;
        try {
            $CFG->branch = '405';
            $this->assertTrue(bootstrap::is_bs4(), 'Moodle 4.5 ships Bootstrap 4.');
            $CFG->branch = '499';
            $this->assertTrue(bootstrap::is_bs4(), 'Anything below 5.0 still ships Bootstrap 4.');
            $CFG->branch = '500';
            $this->assertFalse(bootstrap::is_bs4(), 'Moodle 5.0 is the first branch shipping Bootstrap 5.');
            $CFG->branch = '502';
            $this->assertFalse(bootstrap::is_bs4(), 'Moodle 5.2 ships Bootstrap 5.');
        } finally {
            $CFG->branch = $original;
        }
    }

    /**
     * The marker reaches the page body on Bootstrap 4 sites, and only there.
     *
     * The negative half runs first and the positive half is its control. A mark_page() that added
     * nothing at all - an empty body, or a marker spelt differently from the gate styles.css keys
     * off - passes the first assertion and fails the second, so the first cannot stay green by the
     * method never having run.
     *
     * @return void
     */
    public function test_mark_page_marks_only_bootstrap4_pages(): void {
        global $CFG, $PAGE;

        /*
         * A fresh page, restored afterwards. mark_page() writes to the global $PAGE and this is a
         * basic_testcase, which does not call reset_all_data() — so without this the body class
         * added below would outlive the test, and the negative assertion would be reading a class
         * left behind by an earlier run rather than by this one.
         */
        $originalpage = $PAGE;
        $PAGE = new \moodle_page();

        $original = $CFG->branch;
        try {
            $CFG->branch = '502';
            bootstrap::mark_page();
            $this->assertStringNotContainsString(
                bootstrap::BODY_CLASS_BS4,
                $PAGE->bodyclasses,
                'The Bootstrap 4 polyfill gate must not reach a Bootstrap 5 site.'
            );

            $CFG->branch = '405';
            bootstrap::mark_page();
            $this->assertStringContainsString(
                bootstrap::BODY_CLASS_BS4,
                $PAGE->bodyclasses,
                'Without this marker on the body, the Bootstrap 4 polyfill in styles.css never applies.'
            );
        } finally {
            $CFG->branch = $original;
            $PAGE = $originalpage;
        }
    }
}

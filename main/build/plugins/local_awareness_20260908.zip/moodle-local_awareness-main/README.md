[![ci](https://github.com/uaiblaine/moodle-local_awareness/actions/workflows/ci.yml/badge.svg)](https://github.com/uaiblaine/moodle-local_awareness/actions/workflows/ci.yml)

# Awareness

Awareness is a Moodle local plugin to display policy, compliance, communication, and onboarding notices in modal form.

The plugin supports three levels of insistence, from an informational notice through to one that cannot be clicked away and must be acknowledged, plus audience targeting and reporting for dismissed and acknowledged interactions.

## Credits

This plugin is a derivative work based on:

https://github.com/catalyst/moodle-local_sitenotice

Original project and historical contributors include Catalyst IT and contributors from the fork history
(such as Nathan Nguyen, Jwalit Shah, Dmitrii Metelkin, and Cameron Ball).

This repository is currently maintained and evolved under the Awareness direction.

## Feature overview

- Site-wide modal notices.
- Three levels of insistence: informational, blocking, and must-acknowledge.
- A named exit at every level, so a reader can always decline. At the two insistent levels the decline is recorded and the notice is shown again; an informational notice is dismissed once and stays dismissed.
- Audience targeting by cohort, role (optionally scoped to a course or category),
  course category, course, course format, theme, competency rules and, for a course
  notice, the course's groups.
- An audience estimate in the editor, computed asynchronously, showing the reach of the
  rules as they are edited.
- Optional requirement to complete a selected course before the notice stops appearing.
- URL path matching to scope notices to specific pages.
- Scheduling via start date and expiry date.
- Perpetual notices (always active while enabled).
- Recurring re-display using reset intervals.
- Hyperlink extraction and click tracking from notice content.
- Reports for acknowledgements and dismissals with export options.
- Report Builder integration for custom report creation.
- System reports for acknowledged and dismissed interactions, integrated into notice management actions.
- Additional report data sources for notice views and hyperlink click history.
- Optional clean-up of related tracking/interaction data when deleting notices.
- Optional modal background image.
- Optional modal dimensions (width and height).
- Outside-click close behavior control.
- Session-based optimization through cached user notice resolution.

## Compatibility

This repository is maintained for modern Moodle branches through CI matrix testing. Check the CI badge and workflow matrix for currently validated combinations.

Current declared support in plugin metadata:

- Moodle 4.5 to 5.2

## Administration paths

- Settings: Site administration > Awareness > Settings
- Management: Site administration > Awareness > Manage notice

## Configuration

### Enable plugin
- Setting: Enabled
- Effect: enables Awareness notices site-wide.

### Allow notice update
- Setting: Allow notice update
- Effect: permits editing existing notices.

### Allow notice deletion
- Setting: Allow notice deletion
- Effect: permits deleting notices.

### Clean up deleted notice data
- Setting: Clean up info related to the deleted notice
- Effect: when deletion is allowed, removes related records such as hyperlinks, hyperlink history, acknowledgements, and last view records.

## Notice authoring

When creating or editing a notice, you can configure:

- Title and rich content.
- Start/end window and perpetual mode.
- Reset interval.
- Insistence: informational, blocking, or must-acknowledge.
- Cohort visibility.
- Required course completion.
- URL path matching.
- Modal presentation options (background image, width, height).

## Reports

From Manage notice, each notice provides access to:

- Acknowledgement report.
- Dismiss report.

Reports include filtering and downloadable exports.

### Report Builder

Awareness also provides Report Builder entities and data sources for:

- all notices
- acknowledged notices
- dismissed notices
- notice views
- hyperlink click history

This enables custom report composition with filters, columns, export, and reuse of core Report Builder capabilities.

## Development notes

- PHPUnit and Behat tests live under `tests/`, and ship in the release zip as Moodle expects.
- CI is the moodle-an-hochschulen reusable workflow, one job per supported Moodle branch.
  Run it locally before pushing, at both ends of the supported range:

  ```sh
  mdl ci moodle-local_awareness --branch MOODLE_405_STABLE
  mdl ci moodle-local_awareness --branch MOODLE_502_STABLE
  ```

- Targeted runs: `mdl phpunit m501 local_awareness`, `mdl behat m501 @local_awareness`.
- For release automation, tags matching `v*` trigger the Moodle Plugin Release workflow.

## Course notices

A notice can belong to a course. Grant `local/awareness:managecourse` in the course to whoever may
author its notices, and `local/awareness:viewreportscourse` to whoever may read their reports;
neither has a default archetype. The holder also needs to be enrolled, or to hold
`moodle/course:view`, because the pages live inside the course and `require_login()` is a gate of
its own. A course notice appears on its course's main page, to anyone who can open it — guests
included where the course allows guest access — so add a role, cohort or group rule to narrow it
further; category, theme and course-format filters do not apply to it, and it does not travel with a
course backup. Groups follow the course's group mode the way Moodle applies it everywhere else: in
separate groups mode an author without `moodle/site:accessallgroups` may address only their own
groups and sees only the notices aimed at them; otherwise, any group of the course. The course's
group mode does not have to be set for a notice to address a group — that setting governs how
activities separate participants, not who a notice reaches. A holder of `viewreportscourse` alone sees the course's list read-only, with the two reports
of each notice and nothing to create or change.

## Contributing

Issues and pull requests are welcome:

https://github.com/uaiblaine/moodle-local_awareness/issues

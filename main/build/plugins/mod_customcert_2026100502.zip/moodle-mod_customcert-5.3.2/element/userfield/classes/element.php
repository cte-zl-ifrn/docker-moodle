<?php
// This file is part of the customcert module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This file contains the customcert element userfield's core interaction API.
 *
 * @package    customcertelement_userfield
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace customcertelement_userfield;

use availability_profile\condition;
use core_collator;
use core_user\fields;
use mod_customcert\element\persistable_element_interface;
use mod_customcert\element as base_element;
use mod_customcert\element\renderable_element_interface;
use mod_customcert\element\form_element_interface;
use mod_customcert\element\validatable_element_interface;
use mod_customcert\element\preparable_form_interface;
use mod_customcert\element\stylable_payload;
use mod_customcert\element_helper;
use mod_customcert\service\element_renderer;
use MoodleQuickForm;
use pdf;
use stdClass;

/**
 * The customcert element userfield's core interaction API.
 *
 * @package    customcertelement_userfield
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class element extends base_element implements
    form_element_interface,
    persistable_element_interface,
    preparable_form_interface,
    renderable_element_interface,
    validatable_element_interface
{
    /**
     * Core user table fields that may be displayed.
     */
    private const USER_FIELDS = [
        'firstname', 'lastname', 'username', 'email', 'city', 'country', 'url',
        'idnumber', 'institution', 'department', 'phone1', 'phone2', 'address',
    ];

    /**
     * Build the configuration form for this element.
     *
     * @param MoodleQuickForm $mform
     * @return void
     */
    public function build_form(MoodleQuickForm $mform): void {
        global $PAGE;

        // Get the user profile fields.
        $userfields = [];
        foreach (self::USER_FIELDS as $userfield) {
            $userfields[$userfield] = fields::get_display_name($userfield);
        }
        // Get the user custom fields, excluding ones the configuring user isn't permitted to disclose.
        $context = $PAGE->context;
        $canviewalldetails = has_capability('moodle/user:viewalldetails', $context);
        $arrcustomfields = condition::get_custom_profile_fields();
        $customfields = [];
        foreach ($arrcustomfields as $key => $customfield) {
            if ((int) $customfield->visible === (int) PROFILE_VISIBLE_NONE && !$canviewalldetails) {
                continue;
            }
            $customfields[$customfield->id] = $customfield->name;
        }
        // Combine the two.
        $fields = $userfields + $customfields;
        core_collator::asort($fields);

        $mform->addElement('select', 'userfield', get_string('userfield', 'customcertelement_userfield'), $fields);
        $mform->addHelpButton('userfield', 'userfield', 'customcertelement_userfield');
        $mform->setType('userfield', PARAM_ALPHANUM);

        element_helper::render_common_form_elements($mform, $this->showposxy);
    }

    /**
     * Normalise userfield element data.
     *
     * @param stdClass $formdata Form submission data
     * @return array JSON-serialisable payload
     */
    public function normalise_data(stdClass $formdata): array {
        return array_merge(
            ['userfield' => (string)($formdata->userfield ?? '')],
            stylable_payload::from_form($formdata)->to_array(),
        );
    }

    /**
     * Prepare the form by populating the userfield field from stored data.
     *
     * @param MoodleQuickForm $mform
     * @return void
     */
    public function prepare_form(MoodleQuickForm $mform): void {
        $payload = $this->get_payload();
        if (isset($payload['userfield'])) {
            $mform->getElement('userfield')->setValue((string)$payload['userfield']);
        }
    }

    /**
     * Handles rendering the element on the pdf.
     *
     * @param pdf $pdf the pdf object
     * @param bool $preview true if it is a preview, false otherwise
     * @param stdClass $user the user we are rendering this for
     * @param element_renderer|null $renderer the renderer service
     */
    public function render(pdf $pdf, bool $preview, stdClass $user, ?element_renderer $renderer = null): void {
        $value = $this->get_user_field_value($user, $preview);
        if ($renderer) {
            $renderer->render_content($this, $value);
        } else {
            element_helper::render_content($pdf, $this, $value);
        }
    }

    /**
     * Render the element in html.
     *
     * This function is used to render the element when we are using the
     * drag and drop interface to position it.
     *
     * @param element_renderer|null $renderer the renderer service
     * @return string the html
     */
    public function render_html(?element_renderer $renderer = null): string {
        global $USER;

        $value = $this->get_user_field_value($USER, true);
        if ($renderer) {
            return (string) $renderer->render_content($this, $value);
        }

        return element_helper::render_html_content($this, $value);
    }


    /**
     * Helper function that returns the text.
     *
     * @param stdClass $user the user we are rendering this for
     * @param bool $preview Is this a preview?
     * @return string
     */
    protected function get_user_field_value(stdClass $user, bool $preview): string {
        global $CFG, $DB;

        $context = element_helper::get_context($this->get_id());

        // The user field to display.
        $payload = $this->get_payload();
        $field = isset($payload['userfield']) ? $payload['userfield'] : '';
        // The value to display - we always want to show a value here so it can be repositioned.
        if ($preview) {
            $value = $field;
        } else {
            $value = '';
        }
        if (is_number($field)) { // Must be a custom user profile field.
            if ($field = $DB->get_record('user_info_field', ['id' => $field])) {
                // Found the field name, let's update the value to display.
                $value = $field->name;
                $file = $CFG->dirroot . '/user/profile/field/' . $field->datatype . '/field.class.php';
                if (file_exists($file)) {
                    require_once($CFG->dirroot . '/user/profile/lib.php');
                    require_once($file);
                    $class = "profile_field_{$field->datatype}";
                    $formfield = new $class($field->id, $user->id);
                    // Only disclose the value if the field is visible to the current viewer.
                    if ($formfield->is_visible($context)) {
                        $value = $formfield->display_data();
                    }
                }
            }
        } else if (in_array($field, self::USER_FIELDS, true) && !empty($user->$field)) { // Field in the user table.
            $value = $user->$field;
        }

        return format_string($value, true, ['context' => $context]);
    }

    /**
     * Validate submitted form data for this element.
     * Core validations are handled by validation_service; no extra rules here.
     *
     * @param array $data
     * @return array<string,string>
     */
    public function validate(array $data): array {
        return [];
    }
}

<?php
// This file is part of the customcert module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Element rendering contract used by the v2 element pipeline.
 *
 * Implementations provide two rendering surfaces for elements:
 * - PDF rendering for runtime issuance and preview (see pdf_renderer)
 * - HTML rendering for the drag-and-drop designer preview (see html_renderer)
 *
 * The interface also exposes a small helper, {@see element_renderer::render_content()},
 * which element implementations can use to delegate common content rendering to
 * shared helpers without coupling to a specific renderer implementation.
 *
 * @package    mod_customcert
 * @copyright  2025 Mark Nelson <mdjnelson@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace mod_customcert\service;

use mod_customcert\element\renderable_element_interface;
use mod_customcert\element\stylable_element_interface;
use mod_customcert\element\layout_element_interface;
use pdf;
use stdClass;

/**
 * Rendering surface abstraction for elements.
 */
interface element_renderer {
    /**
     * Render the element into a PDF context.
     *
     * @param renderable_element_interface $element
     * @param pdf $pdf
     * @param bool $preview
     * @param stdClass $user
     * @return void
     */
    public function render_pdf(renderable_element_interface $element, pdf $pdf, bool $preview, stdClass $user): void;

    /**
     * Render the element into HTML for the designer UI.
     *
     * @param renderable_element_interface $element
     * @return string
     */
    public function render_html(renderable_element_interface $element): string;

    /**
     * Common behaviour for rendering specified content.
     *
     * @param stylable_element_interface $element The element. Must also implement layout_element_interface.
     * @param string $content the content to render
     * @return mixed
     */
    public function render_content(
        stylable_element_interface $element,
        string $content
    );
}

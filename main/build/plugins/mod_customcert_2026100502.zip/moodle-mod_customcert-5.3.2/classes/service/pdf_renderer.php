<?php
// This file is part of the customcert module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * PDF renderer for element issuance and previews.
 *
 * Implements {@see element_renderer} to render elements into a TCPDF context.
 * Elements that implement {@see mod_customcert\element\renderable_element_interface}
 * can delegate their PDF rendering via {@see render()}.
 *
 * @package    mod_customcert
 * @copyright  2025 Mark Nelson <mdjnelson@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace mod_customcert\service;

use coding_exception;
use mod_customcert\element\renderable_element_interface;
use mod_customcert\element\stylable_element_interface;
use mod_customcert\element\layout_element_interface;
use mod_customcert\element_helper;
use pdf;
use stdClass;

/**
 * PDF renderer implementation.
 */
final class pdf_renderer implements element_renderer {
    /** @var pdf|null */
    private ?pdf $pdf = null;

    /**
     * Set the PDF.
     *
     * @param pdf $pdf
     */
    public function set_pdf(pdf $pdf): void {
        $this->pdf = $pdf;
    }

    /**
     * Renders PDF.
     *
     * @param renderable_element_interface $element
     * @param pdf $pdf
     * @param bool $preview
     * @param stdClass $user
     * @return void
     */
    public function render_pdf(renderable_element_interface $element, pdf $pdf, bool $preview, stdClass $user): void {
        $element->render($pdf, $preview, $user, $this);
    }

    /**
     * Common behaviour for rendering specified content on the pdf.
     *
     * @param stylable_element_interface $element The element. Must also implement layout_element_interface.
     * @param string $content the content to render
     * @return void
     */
    public function render_content(
        stylable_element_interface $element,
        string $content
    ): void {
        if ($this->pdf === null) {
            throw new coding_exception('PDF object not set in pdf_renderer');
        }
        element_helper::render_content($this->pdf, $element, $content);
    }

    /**
     * Render HTML.
     *
     * @param renderable_element_interface $element
     * @return string
     */
    public function render_html(renderable_element_interface $element): string {
        return '';
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Class represents a customcert template.
 *
 * @package    mod_customcert
 * @copyright  2016 Mark Nelson <markn@moodle.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace mod_customcert;

use context;
use mod_customcert\event\template_created;
use mod_customcert\service\pdf_generation_service;
use mod_customcert\service\template_repository;
use mod_customcert\service\template_service;
use pdf;
use stdClass;

/**
 * Class represents a customcert template.
 *
 * @package    mod_customcert
 * @copyright  2016 Mark Nelson <markn@moodle.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class template {
    /**
     * @var int $id The id of the template.
     */
    protected int $id;

    /**
     * @var string $name The name of this template
     */
    protected string $name;

    /**
     * @var int $contextid The context id of this template
     */
    protected int $contextid;

    /**
     * @var template_service|null Lazily cached service used by the deprecated shim methods below.
     */
    private ?template_service $service = null;

    /**
     * @var pdf_generation_service|null Lazily cached service used by the deprecated {@see self::generate_pdf()} shim.
     */
    private ?pdf_generation_service $pdfs = null;

    /**
     * The constructor.
     *
     * @param int $id The id of the template.
     * @param string $name The name of the template.
     * @param int $contextid The context id of the template.
     */
    public function __construct(int $id, string $name, int $contextid) {
        $this->id = $id;
        $this->name = $name;
        $this->contextid = $contextid;
    }

    /**
     * Creates a template instance from a database record.
     *
     * @param stdClass $record A record from the customcert_templates table.
     * @return template
     */
    public static function from_record(stdClass $record): template {
        return new template((int)$record->id, $record->name, (int)$record->contextid);
    }

    /**
     * Handles saving data.
     *
     * @deprecated since Moodle 5.2. Use {@see template_service::update()} instead.
     * @param stdClass $data the template data
     */
    public function save(stdClass $data): void {
        debugging(
            'template::save() is deprecated since Moodle 5.2. Use template_service::update() instead. '
            . 'This compatibility shim is retained through Moodle 5.3; removal is planned no earlier than '
            . 'the Moodle 6.0-compatible release.',
            DEBUG_DEVELOPER
        );
        $this->get_service()->update($this, $data);
    }

    /**
     * Handles adding another page to the template.
     *
     * @deprecated since Moodle 5.2. Use {@see template_service::add_page()} instead.
     * @param bool $triggertemplateupdatedevent
     * @return int the id of the page
     */
    public function add_page(bool $triggertemplateupdatedevent = true): int {
        debugging(
            'template::add_page() is deprecated since Moodle 5.2. Use template_service::add_page() instead. '
            . 'This compatibility shim is retained through Moodle 5.3; removal is planned no earlier than '
            . 'the Moodle 6.0-compatible release.',
            DEBUG_DEVELOPER
        );
        return $this->get_service()->add_page($this, $triggertemplateupdatedevent);
    }

    /**
     * Handles saving page data.
     *
     * @deprecated since Moodle 5.2. Use {@see template_service::save_pages()} instead.
     * @param stdClass $data the template data
     */
    public function save_page(stdClass $data): void {
        debugging(
            'template::save_page() is deprecated since Moodle 5.2. Use template_service::save_pages() instead. '
            . 'This compatibility shim is retained through Moodle 5.3; removal is planned no earlier than '
            . 'the Moodle 6.0-compatible release.',
            DEBUG_DEVELOPER
        );
        $this->get_service()->save_pages($this, $data);
    }

    /**
     * Handles deleting the template.
     *
     * @deprecated since Moodle 5.2. Use {@see template_service::delete()} instead.
     * @return bool return true if the deletion was successful, false otherwise
     */
    public function delete(): bool {
        debugging(
            'template::delete() is deprecated since Moodle 5.2. Use template_service::delete() instead. '
            . 'This compatibility shim is retained through Moodle 5.3; removal is planned no earlier than '
            . 'the Moodle 6.0-compatible release.',
            DEBUG_DEVELOPER
        );
        return $this->get_service()->delete($this);
    }

    /**
     * Handles deleting a page from the template.
     *
     * @deprecated since Moodle 5.2. Use {@see template_service::delete_page()} instead.
     * @param int $pageid the template page
     * @param bool $triggertemplateupdatedevent False if page is being deleted
     * during deletion of template.
     */
    public function delete_page(int $pageid, bool $triggertemplateupdatedevent = true): void {
        debugging(
            'template::delete_page() is deprecated since Moodle 5.2. Use template_service::delete_page() instead. '
            . 'This compatibility shim is retained through Moodle 5.3; removal is planned no earlier than '
            . 'the Moodle 6.0-compatible release.',
            DEBUG_DEVELOPER
        );
        $this->get_service()->delete_page($this, $pageid, $triggertemplateupdatedevent);
    }

    /**
     * Handles deleting an element from the template.
     *
     * @deprecated since Moodle 5.2. Use {@see template_service::delete_element()} instead.
     * @param int $elementid the template page
     */
    public function delete_element(int $elementid): void {
        debugging(
            'template::delete_element() is deprecated since Moodle 5.2. Use template_service::delete_element() '
            . 'instead. This compatibility shim is retained through Moodle 5.3; removal is planned no earlier '
            . 'than the Moodle 6.0-compatible release.',
            DEBUG_DEVELOPER
        );
        $this->get_service()->delete_element($this, $elementid);
    }

    /**
     * Generate the PDF for the template.
     *
     * @deprecated since Moodle 5.2. Use {@see pdf_generation_service::generate_pdf()} instead.
     * @param bool $preview true if it is a preview, false otherwise
     * @param int|null $userid the id of the user whose certificate we want to view
     * @param bool $return Do we want to return the contents of the PDF?
     * @return string|void Can return the PDF in string format if specified.
     */
    public function generate_pdf(bool $preview = false, ?int $userid = null, bool $return = false) {
        debugging(
            'template::generate_pdf() is deprecated since Moodle 5.2. Use pdf_generation_service::generate_pdf() '
            . 'instead. This compatibility shim is retained through Moodle 5.3; removal is planned no earlier '
            . 'than the Moodle 6.0-compatible release.',
            DEBUG_DEVELOPER
        );
        return $this->get_pdf_service()->generate_pdf($this, $preview, $userid, $return);
    }

    /**
     * Handles copying this template into another.
     *
     * @deprecated since Moodle 5.2. Use {@see template_service::copy_to_template()} instead.
     * @param template $copytotemplate The template instance to copy to
     */
    public function copy_to_template(template $copytotemplate): void {
        debugging(
            'template::copy_to_template() is deprecated since Moodle 5.2. Use template_service::copy_to_template() '
            . 'instead. This compatibility shim is retained through Moodle 5.3; removal is planned no earlier '
            . 'than the Moodle 6.0-compatible release.',
            DEBUG_DEVELOPER
        );
        $this->get_service()->copy_to_template($this, $copytotemplate);
    }

    /**
     * Handles moving an item on a template.
     *
     * @deprecated since Moodle 5.2. Use {@see template_service::move_item()} instead.
     * @param string $itemname the item we are moving
     * @param int $itemid the id of the item
     * @param string $direction the direction
     */
    public function move_item(string $itemname, int $itemid, string $direction): void {
        debugging(
            'template::move_item() is deprecated since Moodle 5.2. Use template_service::move_item() instead. '
            . 'This compatibility shim is retained through Moodle 5.3; removal is planned no earlier than '
            . 'the Moodle 6.0-compatible release.',
            DEBUG_DEVELOPER
        );
        $this->get_service()->move_item($this, $itemname, $itemid, $direction);
    }

    /**
     * Returns the id of the template.
     *
     * @return int the id of the template
     */
    public function get_id(): int {
        return (int)$this->id;
    }

    /**
     * Returns the name of the template.
     *
     * @return string the name of the template
     */
    public function get_name(): string {
        return $this->name;
    }

    /**
     * Update the in-memory template name.
     *
     * @param string $name
     * @return void
     */
    public function set_name(string $name): void {
        $this->name = $name;
    }

    /**
     * Returns the context id.
     *
     * @return int the context id
     */
    public function get_contextid(): int {
        return $this->contextid;
    }

    /**
     * Returns the context id.
     *
     * @return \context the context
     */
    public function get_context(): \context {
        return context::instance_by_id($this->contextid);
    }

    /**
     * Returns the context id.
     *
     * @return \context_module|null the context module, null if there is none
     */
    public function get_cm(): ?stdClass {
        $context = $this->get_context();
        if ($context->contextlevel === CONTEXT_MODULE) {
            return get_coursemodule_from_id('customcert', $context->instanceid, 0, false, MUST_EXIST);
        }

        return null;
    }

    /**
     * Ensures the user has the proper capabilities to manage this template.
     *
     * @throws \required_capability_exception if the user does not have the necessary capabilities (ie. Fred)
     */
    public function require_manage(): void {
        require_capability('mod/customcert:manage', $this->get_context());
    }

    /**
     * Ensures the user is allowed to use this template as the source when copying its
     * content into another template (eg. via load_template.php).
     *
     * System context templates are shared, reusable presets that the load-template form
     * lists to any user regardless of their capabilities at the system context, so they can
     * be used as a source without holding mod/customcert:manage there. Templates in any other
     * context (course or activity) still require manage capability, otherwise a user could
     * copy the content of a private template belonging to a course they cannot access.
     *
     * @throws \required_capability_exception if the user does not have the necessary capabilities
     */
    public function require_use_as_source(): void {
        if ($this->get_context()->contextlevel !== CONTEXT_SYSTEM) {
            $this->require_manage();
        }
    }

    /**
     * Creates a template.
     *
     * @param string $templatename the name of the template
     * @param int $contextid the context id
     * @return template the template object
     */
    public static function create(string $templatename, int $contextid): template {
        $repository = new template_repository();
        $id = $repository->create((object) ['name' => $templatename, 'contextid' => $contextid]);
        $record = $repository->get_by_id_or_fail($id);

        $template = self::from_record($record);

        template_created::create_from_template($template)->trigger();

        return $template;
    }

    /**
     * Lazily build a template_service instance for the deprecated shim methods.
     *
     * @return template_service
     */
    private function get_service(): template_service {
        return $this->service ??= template_service::create();
    }

    /**
     * Lazily build a pdf_generation_service instance for the deprecated {@see self::generate_pdf()} shim.
     *
     * @return pdf_generation_service
     */
    private function get_pdf_service(): pdf_generation_service {
        return $this->pdfs ??= pdf_generation_service::create();
    }
}

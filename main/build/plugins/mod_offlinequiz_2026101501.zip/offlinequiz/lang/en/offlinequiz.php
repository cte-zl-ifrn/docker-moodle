<?PHP
// This file is part of mod_offlinequiz for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * The English language strings for offlinequizzes
 *
 * @package       mod_offlinequiz
 * @subpackage    offlinequiz
 * @author        Juergen Zimmer <zimmerj7@univie.ac.at>
 * @copyright     2015 Academic Moodle Cooperation {@link http://www.academic-moodle-cooperation.org}
 * @since         Moodle 2.2+
 * @license       http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 **/

$string['addarandomquestion'] = 'a random question';
$string['addarandomselectedquestion'] = 'Add a randomly selected question ...';
$string['addlist'] = 'Add attendance list';
$string['addnewquestion'] = 'a new question';
$string['addpagebreak'] = 'Add page break';
$string['addquestionfrombankatend'] = 'Add from the question bank at the end';
$string['addquestionfrombanktopage'] = 'Add from the question bank to page {$a}';
$string['addrandomquestiontopage'] = 'Add a random question to page {$a}';
$string['addtoofflinequiz'] = 'Add to offline quiz';
$string['allinone'] = 'Unlimited';
$string['alllists'] = 'All lists';
$string['allornothing'] = 'All-or-nothing';
$string['allresults'] = 'Show all results';
$string['allstudents'] = 'Show all students';
$string['alwaysavailable'] = 'Always available';
$string['answerform'] = 'Form for answers';
$string['answerformforgroup'] = 'Answer form for group {$a}';
$string['answerforms'] = 'Answer forms';
$string['answerpdfxy'] = 'Form for answers ({$a}->maxquestions questions / {$a}->maxanswers options)';
$string['areyousureremoveselected'] = 'Are you sure you want to remove all selected questions?';
$string['attemptexists'] = 'Attempt exists';
$string['attemptsnum'] = 'Results: {$a}';
$string['attemptsonly'] = 'Show students with results only';
$string['attendanceoverview'] = 'Attendances';
$string['attendances'] = 'Attendances';
$string['attendancesevaluationheadline'] = '2. Evaluation';
$string['attendancesheadline'] = 'Attendances';
$string['attendancespreparationheadline'] = '1. Preparation';
$string['attendenceoverviewattwithoutresults'] = 'Present without results:';
$string['attendenceoverviewattwithresults'] = 'Present with results:';
$string['attendenceoverviewcorrectionnecessary'] = 'Correction necessary (pages):';
$string['attendenceoverviewnoattwithoutresults'] = 'Absent without results:';
$string['attendenceoverviewnoattwithresults'] = 'Absent with results:';
$string['backtopreview'] = 'Show preview';
$string['basicideasofofflinequiz'] = 'The basic ideas of offline quiz-making';
$string['blackwhitethreshold'] = 'Black/white threshold.';
$string['bulksavegrades'] = 'Save grades';
$string['cannoteditafterattempts'] = 'You cannot add or remove questions because there are already complete results. ({$a})';
$string['cannotreview'] = 'You are not allowed to view this report.';
$string['checkparts'] = 'Mark selected participants as present';
$string['checkuserid'] = 'Check group/user ID';
$string['closebeforeopen'] = 'Could not update the offline quiz. You have specified a close date before the open date.';
$string['closestudentview'] = 'Close report view';
$string['closewindow'] = 'Close window';
$string['cmmissing'] = 'The course module for the offline quiz with ID {$a} is missing';
$string['completiondetail:passgrade'] = 'Receive a passing grade';
$string['completionpass'] = 'Pass to complete';
$string['completionpass_help'] = 'Students only complete this offline quiz, if they reach a grade higher than or equal to the passing grade set in the grade options';
$string['configblackwhitethreshold'] = 'Sets the threshold for the black/white converting between 1-99 - The higher the value, the more white the imported pixel needs to be, in order to be recognized as white. Any other value leads to no black/white conversion at all.';
$string['configdecimalplaces'] = 'Number of digits to be shown after the decimal point when displaying grades for the offline quiz.';
$string['configdisableimgnewlines'] = 'This option disables new lines before and after images and equations in the pdf question forms. Warning: This might lead to formatting problems.';
$string['configexperimentalevaluation'] = 'Experimental evaluation of answer forms';
$string['configexperimentalevaluationdesc'] = 'DO NOT USE IN PRODUCTION! This option is used for alpha tests of the new evaluation algorithm. If this option is activated, the experimental evaluation can be enabled the settings of the offline quiz instance. We highly discourage use of this setting. There is no support at all for lost data if this setting is activated.';
$string['configintro'] = 'The values set here are used as default values for the settings of new offline quizzes.';
$string['configkeepfilesfordays'] = 'Determine how many days the uploaded image files are kept in temporary storage. During this time the image files are available in the offline quiz admin report.';
$string['configmaximumgrade'] = 'The default grade after which the offline quiz grade is scaled.';
$string['configonlylocalcategories'] = 'No shared question categories allowed.';
$string['configpapergray'] = 'White-value of paper, which is used for the evaluation of answer forms';
$string['configshufflequestions'] = 'If this setting is enabled, then the order of questions in the offline quiz groups will be randomly shuffled each time you re-create the preview in the "Create forms" tab.';
$string['configshufflewithin'] = 'If this setting is enabled, the answers of multiple choice questions are shuffled separately for each offline quiz group.';
$string['configurerandomquestion'] = 'Configure random questions';
$string['configuseridentification'] = 'A formula describing the user identification. This formula is used to assign answer forms to users in the system. The left hand side of the equation defines the number of digits (integer only, up to 10 digits). The right hand side of the equation must denote a field in the user table of Moodle (e.g. ID, idnumber, phone1).
In addition, the equation can also deal with prefix and suffix which is added to the marked digits (e.g. "a[7]=username" or "b[5]cd=username"). These concatenations of strings and numbers denote the value of the used field in the user table, that is used for user identification.';
$string['confirmremovequestion'] = 'Are you sure you want to remove this {$a} question?';
$string['copyright'] = '<strong>Warning: The texts on this page are just for your personal information. Like any other texts, these questions are under copyright restrictions. You are not allowed to copy them or to show them to other people!</strong>';
$string['copyselectedtogroup'] = 'Add selected questions to group: {$a}';
$string['correct'] = 'correct';
$string['correctbutton'] = 'Correct ({$a})';
$string['correctheader'] = 'Correction necessary: ';
$string['correctionforms'] = 'Correction forms';
$string['correctionheader'] = 'Correction';
$string['correctionheader_help'] = '<p>The answer forms displayed here need your your attention and must be corrected manually. An automatic evaluation is not possible.</p>
<u>The following errors may occur...</u>
<ul>
  <li><strong>Inaccurate markings:</strong> Some marks could not be evaluated.</li>
  <li><strong>Invalid group number:</strong> The group number could not be evaluated.</li>
  <li><strong>Invalid page number:</strong> The page number could not be evaluated.</li>
  <li><strong>Not adjusted:</strong> The answer form was scanned crooked and cannot be evaluated.</li>
  <li><strong>Different result exists:</strong> An evaluated result with a deviating group number already exists.</li>
  <li><strong>Pages incomplete:</strong> The current answer form has been evaluated, but at least 1 additional form is missing to complete the evaluation for the identified participant. (Only occurs with multi-page answer forms.)</li>
  <li><strong>Result exists:</strong> An evaluated result already exists.</li>
  <li><strong>User not in course:</strong> The identified participant is not currently registered in the course.</li>
  <li><strong>User does not exist:</strong> The identified participant is unknown.</li>
</ul>';
$string['correctionoptionsheading'] = 'Correction options';
$string['couldnotimportpage'] = 'Could not import the page';
$string['createlistfirst'] = 'Add participant lists first';
$string['createpartpdferror'] = 'The PDF form for the list of participants {$a} could not be created. The list may be empty.';
$string['createpdferror'] = 'The form for group {$a} could not be created. Maybe there are no questions in the group.';
$string['createpdffirst'] = 'Create PDF list first';
$string['createpdfforms'] = 'Create forms';
$string['createpdfs'] = 'Forms';
$string['createpdfsparticipants'] = 'Forms';
$string['createquiz'] = 'Create forms';
$string['csvformat'] = 'Comma separated values text file (CSV)';
$string['csvplus1format'] = 'Text file with raw data (CSV)';
$string['csvpluspointsformat'] = 'Text file with points (CSV)';
$string['darkgray'] = 'Dark grey';
$string['decimalplaces'] = 'Decimal places in grades';
$string['decimalplaces_help'] = 'This setting specifies the number of digits shown after the decimal point when displaying grades. It only affects the display of grades, not the grades stored in the database, nor the internal calculations, which are carried out to full accuracy.';
$string['defaultparticipantsusage'] = 'Record attendance';
$string['defaultparticipantsusagedesc'] = 'Determines if attendances should be recorded via attendance lists by default.';
$string['defaultpdffont'] = 'Default form font';
$string['defaultpdffont_help'] = 'The default font an offline quiz will use for its forms. You may want to manually download tcpdf package and extract its fonts/ directory into your $CFG->dataroot/fonts/ for more fonts. It is recommended to use Freeserif as the default as it supports the most characters. See https://www.gnu.org/software/freefont/coverage.html for the full compatibility list.';
$string['defaultpdffontsize'] = 'Default font size';
$string['defaultpdffontsize_help'] = 'The default font size all forms will use.';
$string['deletelistcheck'] = 'Do you really want to delete the selected list and all its participants?';
$string['deletepagecheck'] = 'Do you really want to delete the selected pages?';
$string['deletepartcheck'] = 'Do you really want to delete the selected participants?';
$string['deletepdfs'] = 'Delete documents';
$string['deleteresultcheck'] = 'Do you really want to delete the selected results?';
$string['deleteselectedresults'] = 'Delete selected results';
$string['deletethislist'] = 'Delete this list';
$string['deleteupdatepdf'] = 'Delete and update PDF-forms';
$string['difficultytitle'] = 'Difficulty';
$string['difficultytitlea'] = 'Difficulty A';
$string['difficultytitleb'] = 'Difficulty B';
$string['difficultytitlediff'] = 'Difference';
$string['disableimgnewlines'] = 'Disable new lines before and after images or equations (Latex, MathJax, Tex)';
$string['disableimgnewlines_help'] = 'Enable continuous text for images or equations (Latex, MathJax, Tex). Warning: This might lead to formatting problems.';
$string['discriminationindex_info'] = 'Since the discrimination index calculates a prediction of the question between good and inferior grades, it cannot be calculated if either
- there are no different responses of the students in this question
- there are no different grades in the exam';
$string['displayoptions'] = 'Display options';
$string['documentschanged'] = 'One ore more question(s) in the offline quiz was/ were changed since creating the documents.<br>Future results will be regraded automatically during the evaluation to the current version of the question(s) chosen here. The original version of the question(s) is still shown in the documents.';
$string['documentschangedwithresults'] = 'One ore more question(s) in the offline quiz was/ were changed since creating the documents.<br>Existing results were regraded automatically to the current version of the question(s) chosen here. The original version of the question(s) is still shown in the documents.';
$string['downloadallzip'] = 'Download all files as ZIP';
$string['downloadpartpdf'] = 'Download PDF file for list \'{$a}\'';
$string['downloadpdfs'] = 'Forms';
$string['downloadresultsas'] = 'Download results as: ';
$string['dragtoafter'] = 'After {$a}';
$string['dragtostart'] = 'To the start';
$string['editingofflinequiz'] = 'Editing group questions';
$string['editingofflinequiz_help'] = 'When creating an offline quiz, the main concepts are:
<ul><li> The offline quiz, containing questions over one or more pages</li>
<li> The question bank, which stores copies of all questions organised into categories</li></ul>';
$string['editingofflinequizx'] = 'Questions';
$string['editlist'] = 'Edit list';
$string['editlists'] = 'Attendance lists';
$string['editmaxmark'] = 'Edit maximum mark';
$string['editofflinequiz'] = 'Edit offline quiz';
$string['editparticipants'] = 'Edit participants';
$string['editquestion'] = 'Edit question';
$string['editquestionlistitem'] = '{$a}';
$string['editquestions'] = 'Questions';
$string['editscannedform'] = 'Edit scanned form';
$string['editthislist'] = 'Edit this list';
$string['enroluser'] = 'Enrol user';
$string['erroraccessingreport'] = 'You are not allowed to view this report.';
$string['errorcouldnotcreatetex'] = 'Coud not create image file for LaTeX equation';
$string['errormultiuserinlist'] = 'User is listed more than once in the attendance lists!';
$string['errorreport'] = 'Report of import errors';
$string['evaluated'] = 'Evaluated: ';
$string['evaluation'] = '2. Evaluation';
$string['eventattemptdeleted'] = 'Offline quiz attempt deleted';
$string['eventattemptreviewed'] = 'Offline quiz attempt reviewed';
$string['eventattemptviewed'] = 'Offline quiz attempt viewed';
$string['eventdocscreated'] = 'Offline quiz question and answer forms created';
$string['eventdocsdeleted'] = 'Offline quiz question and answer forms deleted';
$string['eventeditpageviewed'] = 'Offline quiz edit page viewed';
$string['eventofflinequizattemptsubmitted'] = 'Offline quiz attempt submitted';
$string['eventparticipantmarked'] = 'Offline quiz participant marked manually';
$string['eventquestionmanuallygraded'] = 'Question manually graded';
$string['eventreportviewed'] = 'Offline quiz report viewed';
$string['eventresultsregraded'] = 'Offline quiz results regraded';
$string['everythingon'] = 'enabled';
$string['excelformat'] = 'Excel spreadsheet (XLSX)';
$string['experimentalevaluation'] = 'Experimental evaluation of answer forms';
$string['experimentalevaluation_help'] = 'Experimental evaluation of answer forms';
$string['fileformat'] = 'Format for question forms';
$string['fileformat_help'] = 'Choose whether you want your question forms in PDF, DOCX or TEX format. Answer forms and correction forms will always be generated in PDF format.';
$string['fileprefixanswer'] = 'answer_form';
$string['fileprefixcorrection'] = 'correction_form';
$string['fileprefixform'] = 'question_form';
$string['fileprefixparticipants'] = 'participants_list';
$string['filterbytags'] = 'Filter by tags...';
$string['fontfamilycourier'] = 'Courier';
$string['fontfamilyfreemono'] = '(Free-)Mono';
$string['fontfamilyfreesans'] = '(Free-)Sans';
$string['fontfamilyfreeserif'] = '(Free-)Serif (recommended)';
$string['fontfamilyhelvetica'] = 'Helvetica';
$string['fontfamilyhysmyeongjostdmedium'] = 'MyungJo Medium (Korean)';
$string['fontfamilykozgopromedium'] = 'Kozuka Gothic Pro (Japanese Sans-Serif)';
$string['fontfamilykozminproregular'] = 'Kozuka Mincho Pro (Japanese Serif)';
$string['fontfamilymsungstdlight'] = 'MSung Light (Trad. Chinese)';
$string['fontfamilystsongstdlight'] = 'STSong Light (Simp. Chinese)';
$string['fontfamilysymbol'] = 'Symbol';
$string['fontfamilytimes'] = 'Times';
$string['fontfamilyzapfdingbats'] = 'ZapfDingbats';
$string['fontsize'] = 'Font size';
$string['forautoanalysis'] = 'For automatic analysis';
$string['formforcorrection'] = 'Correction form for group {$a}';
$string['formforgroup'] = 'Question form for group {$a}';
$string['formforgroupdocx'] = 'Question form for group {$a} (DOCX)';
$string['formforgrouplatex'] = 'Question form for group {$a} (LATEX)';
$string['forms'] = 'Forms';
$string['formsexist'] = 'Forms already created.';
$string['formsexistx'] = 'Forms already created (<a href="{$a}">Download forms</a>)';
$string['formsheetsettings'] = 'Form settings';
$string['formspreview'] = 'Preview';
$string['fromquestionbank'] = 'from question bank';
$string['functiondisabledbysecuremode'] = 'That functionality is currently disabled';
$string['furtheroptionsheading'] = 'Further Options';
$string['grade'] = 'Grade';
$string['gradedscannedform'] = 'Scanned form with grades';
$string['gradeiszero'] = 'Note: The maximum grade for this offline quiz is 0 points!';
$string['gradingoptionsheading'] = 'Grading options';
$string['greeniscross'] = 'counted as a cross';
$string['group'] = 'Group';
$string['hasresult'] = 'Result exists';
$string['hotspotdeletiontask'] = 'Deletion of hotspots';
$string['html'] = 'HTML';
$string['idnumber'] = 'ID number';
$string['imagenotfound'] = 'Image file: {$a} not found!';
$string['importedon'] = 'Evaluated on';
$string['importfromto'] = 'Evaluating {$a->from} to {$a->to} of {$a->total}.';
$string['importisfinished'] = 'Evaluation for offline quiz {$a} is finished.';
$string['importlinkresults'] = 'Link to results: {$a}';
$string['importlinkverify'] = 'Link to verifying: {$a}';
$string['importmailsubject'] = 'offline quiz import notification';
$string['importnew'] = 'Evaluate';
$string['importnew_help'] = '<p>
You can import single scanned image files or several scanned image files in a ZIP-archive. The offline quiz module will process the image files in the background.
File names are not relevant but should not contain special characters such as umlauts. Images should be GIFs, PNGs
or TIFs. A resolution between 200 and 300dpi is recommended.</p>';
$string['importnumberexisting'] = 'Number of double forms: {$a}';
$string['importnumberpages'] = 'Number of successfully imported pages: {$a}';
$string['importnumberverify'] = 'Number of forms that need verifying: {$a}';
$string['importtimefinish'] = 'Process finished: {$a}';
$string['importtimestart'] = 'Process started: {$a}';
$string['infoshort'] = 'i';
$string['insecuremarkings'] = 'Insecure markings need manual corrections';
$string['insecuremarkingsforquestion'] = 'Insecure markings need manual corrections for question';
$string['instruction1'] = 'This answer form will be scanned automatically. Please do not fold or spot. Use a black or blue pen to mark the fields:';
$string['instruction2'] = 'Only clear markings can be interpreted correctly! If you want to correct a marking, completely fill out the box with color. This field will be interpreted as an empty box:';
$string['instruction3'] = 'Corrected boxes cannot be marked again. Please do not write anything outside of the boxes.';
$string['invalidformula'] = 'Invalid formula for user identification. The formula must have the form <prefix>[<#digits>]<suffix>=<db-field&>.';
$string['invalidgroupnumber'] = 'Invalid group number';
$string['invalidnumberofdigits'] = 'Invalid number of digits used. Only 1 up to 9 digit(s) are allowed.';
$string['invalidofflinequizid'] = 'Invalid offline quiz ID';
$string['invaliduserfield'] = 'Invalid field of the user table used.';
$string['invigilator'] = 'Invigilator';
$string['ischecked'] = 'Participation is checked';
$string['isnotchecked'] = 'Participation is not checked';
$string['keepfilesfordays'] = 'Keep files for days';
$string['legend'] = 'Legend';
$string['legenddone'] = 'Step successfully done (no further action required).';
$string['legendnextitem'] = 'Action required in the further workflow (possibly dependence on previous steps).';
$string['legendnoaction'] = 'No action required.';
$string['legendwarning'] = 'Immediate action required.';
$string['letter'] = 'Letter';
$string['lightgray'] = 'Light grey';
$string['linktoscannedform'] = 'View scanned form';
$string['listnotdetected'] = 'Could not detect barcode for list!';
$string['logdeleted'] = 'Log entry {$a} deleted.';
$string['logo'] = 'Logo';
$string['logodesc'] = 'Image file that is displayed on the top right corner of answer forms.';
$string['logourl'] = 'Logo URL';
$string['logourldesc'] = 'URL of an image file that is displayed on the top right corner of answer forms, i.e. <b>http://www.yoursite.tld/mylogo.png</b> or <b>../path/to/your/logo.png</b>. The maximum allowed size is 520x140 pixels. Answer forms cannot be evaluated if the image exceeds the maximum size!';
$string['marginwarning'] = 'Please print out the following PDF files without additional margins!<br /> Avoid handing out photocopies to students.';
$string['marks'] = 'Marks';
$string['maxgradewarning'] = 'The maximum grade has to be a number!';
$string['maxmark'] = 'Maximum mark';
$string['messageprovider:jobs'] = 'Offline quiz notifications';
$string['missingquestion'] = 'This question no longer seems to exist';
$string['missingquestions'] = 'There are no questions in this group.';
$string['missinguserid'] = 'Missing user identification number! Could not read barcode!';
$string['modulename'] = 'Offline quiz';
$string['modulename_help'] = '###### Key Features
* Supported question types: multiple choice, description, and all-or-nothing multiple choice.
* Up to six exam groups are possible. * Exam forms are automatically generated by the system.
* Questionnaire formats: PDF, DOCX, LaTeX. * Answer sheets: standardized PDFs.
* Participants mark their answers on printed answer sheets.
* Completed answer sheets are scanned as TIFF, PDF, PNG, or JPG files, uploaded in the offline quiz, and automatically graded.
* Sheets with recognition errors can be manually corrected online.
* Online access to exam results is available.
* Attendance lists can be generated as needed.

###### Application Scenarios
* Large presence exams with a high number of participants, especially when results are needed quickly.';
$string['modulename_summary'] = 'This module is used to generate multiple-choice quizzes in Moodle, which are administered in printed form in the lecture hall. The completed answer sheets are scanned, uploaded to the offline quiz, and automatically graded.';
$string['modulename_tip'] = '<p><a href="https://academic-moodle-cooperation.org/anleitungen/offline-test-einstellungen/?lng=en" target="_blank"><i class="icon fa fa-info-circle"></i>Guide: "Offline quiz: settings"</a></p>
<p><a href="https://academic-moodle-cooperation.org/anleitungen/offline-test-fragen-hinzufugen-und-formulare-generieren/?lng=en" target="_blank"><i class="icon fa fa-info-circle"></i>Guide: "Offline quiz: add questions and generate forms"</a></p>
<p><a href="https://academic-moodle-cooperation.org/anleitungen/offline-test-durchfuhren-und-auswerten/?lng=en" target="_blank"><i class="icon fa fa-info-circle"></i>Guide: "Conduct and evaluate offline quiz"</a></p>
<p><a href="https://academic-moodle-cooperation.org/anleitungen/offline-test-anwesenheitslisten-erstellen-und-nutzen/?lng=en" target="_blank"><i class="icon fa fa-info-circle"></i>Guide: "Offline quiz: create and use attendance lists"</a></p>';
$string['modulenameplural'] = 'Offline quizzes';
$string['movecorners'] = 'Change the positions of the corner markings first. Use drag and drop.';
$string['multichoice'] = 'Multiple choice';
$string['name'] = 'Name';
$string['neededcorrection'] = '<strong>Attention: Some of your markings needed manual correction. Have a look at the red squares in the following picture.
<br />This implied manual intervention by a teacher and delayed the publishing of the offline quiz results!</strong>';
$string['newpage'] = 'New page';
$string['noaccess'] = 'You have no access to this attempt.';
$string['noattemptexists'] = 'No result exists';
$string['noattempts'] = 'No results imported!';
$string['noattemptsonly'] = 'Show students with no results only';
$string['nocm'] = 'This offline quiz has no course module entry';
$string['nocourse'] = 'The course with ID {$a->course} that the offline quiz with ID {$a->offlinequiz} belongs to is missing.';
$string['nogradesseelater'] = 'This quiz has not been graded yet for {$a}. Results will be published here.';
$string['nogroups'] = 'No groups created for this offline quiz';
$string['nomcquestions'] = 'There are no multiple choice questions in group {$a}!';
$string['noofflinequiz'] = 'There is no offline quiz with ID {$a}!';
$string['nopage'] = 'No page parameter set';
$string['nopages'] = 'No pages imported';
$string['nopdfscreated'] = 'No documents created!';
$string['noquestions'] = 'Some offline quiz groups are empty. Please add some questions.';
$string['noquestionsfound'] = 'There are no questions in group {$a}!';
$string['noresult'] = 'No result';
$string['noresults'] = 'There are no results.';
$string['noreview'] = 'You are not allowed to review this offline quiz';
$string['noscannedpage'] = 'There is no scanned page with ID {$a}!';
$string['notagselected'] = 'No tag selected';
$string['notavailable'] = 'N/A';
$string['nothingtodo'] = 'Nothing to do!';
$string['notyetgraded'] = 'Not yet graded';
$string['numbergroups'] = 'Number of groups';
$string['numpages'] = '{$a} pages imported';
$string['numquestionsx'] = 'Questions: {$a}';
$string['odsformat'] = 'OpenDocument spreadsheet (ODS)';
$string['offlinequiz:addinstance'] = 'Add an offline quiz';
$string['offlinequiz:attempt'] = 'Attempt quizzes';
$string['offlinequiz:changeevaluationmode'] = 'Make it possible to change the evaluation mode. WARNING: DO NOT USE IN PRODUCTION SYSTEMS!';
$string['offlinequiz:createofflinequiz'] = 'Create offline quiz forms';
$string['offlinequiz:deleteattempts'] = 'Delete offline quiz results';
$string['offlinequiz:grade'] = 'Grade offline quizzes manually';
$string['offlinequiz:manage'] = 'Manage offline quizzes';
$string['offlinequiz:view'] = 'View offline quiz information';
$string['offlinequiz:viewreports'] = 'View offline quiz reports';
$string['offlinequizcloses'] = 'Offline quiz closes';
$string['offlinequizcloseson'] = 'The review for this offline quiz will close {$a}';
$string['offlinequizisclosed'] = 'Offline quiz is closed';
$string['offlinequizisopen'] = 'This offline quiz is open';
$string['offlinequizopenedon'] = 'This offline quiz opened at {$a}';
$string['offlinequizwillopen'] = 'Offline quiz opens on {$a}';
$string['oneclickenrol'] = '1-click enrolment';
$string['oneclickenroldesc'] = 'If this option is activated teachers have the possiblity to enrol users with one click while correcting answer forms (error "User not in course").';
$string['oneclickrole'] = 'Role for 1-click enrolment.';
$string['oneclickroledesc'] = 'Choose the role used for 1-click enrolment. Only roles with archetype "student" can be selected.';
$string['outof'] = '{$a->grade} out of a maximum of {$a->maxgrade}';
$string['outofshort'] = '{$a->grade}/{$a->maxgrade}';
$string['overview'] = 'Quiz information';
$string['page-mod-offlinequiz-edit'] = 'Edit offline quiz page';
$string['page-mod-offlinequiz-x'] = 'Any offline quiz page';
$string['pageevaluationtask'] = 'Answer forms evaluation for the offline quiz plugin';
$string['pageimported'] = 'Forms of participants list imported';
$string['pagenumberimported'] = 'Form {$a} of attendance list imported';
$string['pagenumberupdate'] = 'Page number update';
$string['pagesinprocessing'] = 'In processing: ';
$string['pagesizeparts'] = 'Participants shown per page:';
$string['papergray'] = 'White value of paper';
$string['papergray_help'] = 'If the white parts of your scanned answer forms are very dark you can correct this by setting this value to dark grey.';
$string['partial'] = 'partial';
$string['participants'] = 'Participants';
$string['participants_help'] = '<p>Attendance lists are designed for large offline quizzes with many participants. They help the teacher determine which students participated in the quiz and whether all the results were imported correctly.
You can add users to different attendance lists. Each list could, for instance, contain the participants in a particular room. Or the participants may be members of a specific group. A group registration tool can be used for creating those groups.
Attendance lists may be downloaded as PDF documents, printed and marked with crosses just like the answer forms. Afterwards, they can be uploaded and the marked students will be marked as present in the database.
Please avoid spots on the barcodes as they are used to identify the students.</p>';
$string['participantsinlists'] = 'Participants';
$string['participantslist'] = 'List of participants';
$string['participantsusage'] = 'Record attendance';
$string['participantsusage_help'] = 'This option determines whether you can record the attendance of participants with attendance lists. Attendance lists are designed for large offline quizzes with many participants. They can be used to check which students participated in the quiz and whether all the results were evaluated correctly.';
$string['partimportnew'] = 'Uploading lists of participants';
$string['partimportnew_help'] = '<p>
Here you can upload the filled-out attendance lists. You can upload single scanned image files or several scanned image files in a ZIP-archive. The offline quiz module will process the image files in the background.
File names are not relevant but should not contain special characters such as umlauts. Images should be GIFs, PNGs
or TIFs. A resolution between 200 and 300dpi is recommended.</p>';
$string['pdffont'] = 'Form font';
$string['pdffont_help'] = 'Here you can choose a font for all your PDF forms: answer forms, correction forms, attendance forms. As well as question forms, if you choose a PDF format for it. The choice should also depend on which characters you use in your forms. With DOCX and LATEX format the question forms are not affected by it.';
$string['pdfintro'] = 'Additional information';
$string['pdfintro_help'] = 'This information will be printed on the first page of the question form and should contain general information about how to fill in the answer form.';
$string['pdfintrotext'] = '<b>How do I mark correctly?</b><br />This answer form will be scanned automatically. Please do not fold or spot. Use a black or blue pen to mark the fields. If you want to correct a marking, completely fill in the box with color. This field will be interpreted as an empty box.<br />';
$string['pearlywhite'] = 'Pearly white';
$string['pluginadministration'] = 'Offline quiz administration';
$string['pluginname'] = 'Offline quiz';
$string['point'] = 'point';
$string['preparation'] = '1. Preparation';
$string['present'] = 'Present';
$string['preventsamequestion'] = 'Prevent multiple usage of the same question in different groups';
$string['preview'] = 'Preview';
$string['previewforgroup'] = 'Group {$a}';
$string['previewquestion'] = 'Preview question';
$string['printstudycodefield'] = 'Print study code field on question form';
$string['printstudycodefield_help'] = 'If checked, the study code field will be printed on the first page of the question form.';
$string['privacy:data_folder_name'] = 'Offline quiz data';
$string['privacy:metadata:core_files'] = 'The offline quiz uses the file API to store the generated question, answer and correction forms, as well as the filled out answer forms.';
$string['privacy:metadata:core_question'] = 'The offline quiz uses the question API for saving the questions for the quizzes.';
$string['privacy:metadata:offlinequiz'] = 'The offline quiz table stores all information specific to an offline quiz instance.';
$string['privacy:metadata:offlinequiz:algorithmversion'] = 'The version of the evaluation algorithm';
$string['privacy:metadata:offlinequiz:completionpass'] = 'The ID of the completion element';
$string['privacy:metadata:offlinequiz:course'] = 'The \'course\' column in the offline quiz table stores the course this offline quiz is located in.';
$string['privacy:metadata:offlinequiz:decimalpoints'] = 'The amount of decimal points to calculate for the grades.';
$string['privacy:metadata:offlinequiz:disableimgnewlines'] = 'Should disable new lines before and after images and equations.';
$string['privacy:metadata:offlinequiz:docscreated'] = 'If the documents have been created, this field is set to 1, otherwise to 0.';
$string['privacy:metadata:offlinequiz:experimentalevaluation'] = 'If experimental evaluation is turned on for this offline quiz';
$string['privacy:metadata:offlinequiz:fileformat'] = 'The file format which is used to print the question forms, 0 for pdf, 1 for docx, 2 for LaTeX.';
$string['privacy:metadata:offlinequiz:fontsize'] = 'The size of the font in the questions heets.';
$string['privacy:metadata:offlinequiz:grade'] = 'The grade shows the maximum amount of points it is possible to score in this offline quiz.';
$string['privacy:metadata:offlinequiz:id_digits'] = 'Stores the amount of digits the ID number had when the answer forms were created. This is needed for backward compability if the amount is raised between creation and import of the answer sheets.';
$string['privacy:metadata:offlinequiz:intro'] = 'The intro of this offline quiz';
$string['privacy:metadata:offlinequiz:introformat'] = 'This field is not used.';
$string['privacy:metadata:offlinequiz:name'] = 'The \'name\' column stores the name of the offline quiz.';
$string['privacy:metadata:offlinequiz:numgroups'] = 'The amount of groups this offline quiz has.';
$string['privacy:metadata:offlinequiz:papergray'] = 'The white value of this offline quiz.';
$string['privacy:metadata:offlinequiz:pdffont'] = 'The font that is used to create the offline quiz PDF forms';
$string['privacy:metadata:offlinequiz:pdfintro'] = 'The additional information which is inserted into the question forms in the beginning.';
$string['privacy:metadata:offlinequiz:printstudycodefield'] = 'A preference whether the study code should be printed on the question form. 1 for true, 0 otherwise.';
$string['privacy:metadata:offlinequiz:review'] = 'This column stores information on how the review is done.';
$string['privacy:metadata:offlinequiz:showgrades'] = 'Stores whether the amount of maximum points for a question should be printed on the question form.';
$string['privacy:metadata:offlinequiz:showquestioninfo'] = 'Stores whether certain information about the questions should be displayed, 0 for no, 1 for information about question type, 2 for information about the amount of right answers.';
$string['privacy:metadata:offlinequiz:showtutorial'] = 'Stores whether participants should be asked to do an offline quiz tutorial.';
$string['privacy:metadata:offlinequiz:shufflequestions'] = 'A preference, whether the questions should be shuffled when creating an offline quiz; 1 for shuffling, 0 otherwise.';
$string['privacy:metadata:offlinequiz:time'] = 'The time column stores the date of the offline quiz.';
$string['privacy:metadata:offlinequiz:timeclose'] = 'The timeclose column stores when the offline quiz was/will be closed.';
$string['privacy:metadata:offlinequiz:timecreated'] = 'The timecreated column stores when the offline quiz was created.';
$string['privacy:metadata:offlinequiz:timemodified'] = 'The timemodified column stores the time when the offline quiz was changed the last time.';
$string['privacy:metadata:offlinequiz:timeopen'] = 'The timeopen column stores when an offline quiz was/will be opened.';
$string['privacy:metadata:offlinequiz_choices'] = 'This table holds the information of all the crosses for all the scanned pages. This information is needed to later create results based on the crosses.';
$string['privacy:metadata:offlinequiz_choices:choicenumber'] = 'The number of choices for this question.';
$string['privacy:metadata:offlinequiz_choices:scannedpageid'] = 'The scanned page the choice relates to.';
$string['privacy:metadata:offlinequiz_choices:slotnumber'] = 'The question slot of this choice.';
$string['privacy:metadata:offlinequiz_choices:value'] = 'Whether the choice is considered to be crossed out. 0 for no, 1 for yes, -1 for uncertain.';
$string['privacy:metadata:offlinequiz_group_questions'] = 'This table stores all the questions for every offline quiz group.';
$string['privacy:metadata:offlinequiz_group_questions:maxmark'] = 'The amount of maximum points for this question.';
$string['privacy:metadata:offlinequiz_group_questions:offlinegroupid'] = 'The offline quiz group this group question relates to.';
$string['privacy:metadata:offlinequiz_group_questions:offlinequizid'] = 'The offline quiz ID this group question relates to.';
$string['privacy:metadata:offlinequiz_group_questions:page'] = 'The page on which this question is printed in the answer forms.';
$string['privacy:metadata:offlinequiz_group_questions:position'] = 'The position in this offline quiz.';
$string['privacy:metadata:offlinequiz_group_questions:questionid'] = 'The ID of the selected question.';
$string['privacy:metadata:offlinequiz_group_questions:slot'] = 'The slot of the question in the quiz.';
$string['privacy:metadata:offlinequiz_groups'] = 'Table of the groups that are taking part in offline quizzes.';
$string['privacy:metadata:offlinequiz_groups:answerfilename'] = 'The file name which was used to save the answer file.';
$string['privacy:metadata:offlinequiz_groups:correctionfilename'] = 'The file which was used to save the correction file.';
$string['privacy:metadata:offlinequiz_groups:number'] = 'The group number of this offline quiz, 1 for group A, 2 group B, and so on.';
$string['privacy:metadata:offlinequiz_groups:numberofpages'] = 'The amount of pages needed to print the answer forms on.';
$string['privacy:metadata:offlinequiz_groups:offlinequizid'] = 'The ID of the offline quiz.';
$string['privacy:metadata:offlinequiz_groups:questionfilename'] = 'The file name which was used to save the question file';
$string['privacy:metadata:offlinequiz_groups:sumgrades'] = 'The sum of all grades for all questions in this group.';
$string['privacy:metadata:offlinequiz_groups:templateusageid'] = 'The ID of the template usage, which is used to create a result in the quiz API.';
$string['privacy:metadata:offlinequiz_hotspots'] = 'This table stores all the positions of the check boxes and whether they were evaluated successfully.';
$string['privacy:metadata:offlinequiz_hotspots:blank'] = 'Whether the hotspot is analyzed successfully.';
$string['privacy:metadata:offlinequiz_hotspots:name'] = 'Type of the hotspot, e.g. u%number for user hotspot, a-0-0 for question 1 answer 1, and so on.';
$string['privacy:metadata:offlinequiz_hotspots:scannedpageid'] = 'Scanned page on which the hotspot is.';
$string['privacy:metadata:offlinequiz_hotspots:time'] = 'The last update time for this hotspot.';
$string['privacy:metadata:offlinequiz_hotspots:x'] = 'The x value of the hotspot.';
$string['privacy:metadata:offlinequiz_hotspots:y'] = 'The y value of the hotspot.';
$string['privacy:metadata:offlinequiz_p_choices'] = 'This table stores all the crosses for the attendance lists.';
$string['privacy:metadata:offlinequiz_p_choices:scannedpageid'] = 'The scanned page this choice relates to.';
$string['privacy:metadata:offlinequiz_p_choices:userid'] = 'The user ID this choice relates to.';
$string['privacy:metadata:offlinequiz_p_choices:value'] = 'Whether the cross is filled out or not (0 for not filled out, 1 for filled out, -1 for insecure).';
$string['privacy:metadata:offlinequiz_p_lists'] = 'This table stores information about attendance lists where teachers can record whether a student was there or not.';
$string['privacy:metadata:offlinequiz_p_lists:filename'] = 'The name of the file for the list.';
$string['privacy:metadata:offlinequiz_p_lists:name'] = 'The name of the attendance list.';
$string['privacy:metadata:offlinequiz_p_lists:number'] = 'The number of the attendance list in the offline quiz.';
$string['privacy:metadata:offlinequiz_p_lists:offlinequizid'] = 'The offline quiz this attendance list belongs to.';
$string['privacy:metadata:offlinequiz_page_corners'] = 'This table stores all the corners for every scanned page to evaluate it faster for the next evaluation or correction.';
$string['privacy:metadata:offlinequiz_page_corners:position'] = 'The information whether this corner is at the top or bottom and right or left.';
$string['privacy:metadata:offlinequiz_page_corners:scannedpageid'] = 'The scanned page this corner is on.';
$string['privacy:metadata:offlinequiz_page_corners:x'] = 'The x value of the corner.';
$string['privacy:metadata:offlinequiz_page_corners:y'] = 'The y value of the corner.';
$string['privacy:metadata:offlinequiz_participants'] = 'The participants table stores whether the user was taking part in the offline quiz or not.';
$string['privacy:metadata:offlinequiz_participants:checked'] = 'The information whether this user was checked on the attendance list.';
$string['privacy:metadata:offlinequiz_participants:listid'] = 'The ID of the attendance list this participant is on.';
$string['privacy:metadata:offlinequiz_participants:userid'] = 'The user ID of the user.';
$string['privacy:metadata:offlinequiz_queue'] = 'This table stores a queue of an upload. For every upload there is an own object in this table.';
$string['privacy:metadata:offlinequiz_queue:importuserid'] = 'The user ID of the teacher who imported the files.';
$string['privacy:metadata:offlinequiz_queue:offlinequizid'] = 'The offline quiz ID of the queue.';
$string['privacy:metadata:offlinequiz_queue:status'] = 'The status of the queue which is needed.';
$string['privacy:metadata:offlinequiz_queue:timecreated'] = 'The time the forms of this offline quiz were imported.';
$string['privacy:metadata:offlinequiz_queue:timefinish'] = 'The time the evaluation of the queue was finished.';
$string['privacy:metadata:offlinequiz_queue:timestart'] = 'The time the evaluation of the queue was started.';
$string['privacy:metadata:offlinequiz_queue_data'] = 'This table stores data for the queue as every file in the queue will get a queue data object.';
$string['privacy:metadata:offlinequiz_queue_data:error'] = 'If the status shows an error, there will be a more detailed error message here.';
$string['privacy:metadata:offlinequiz_queue_data:filename'] = 'The file name of the file this queue relates to.';
$string['privacy:metadata:offlinequiz_queue_data:queueid'] = 'The queue this data belongs to.';
$string['privacy:metadata:offlinequiz_queue_data:status'] = 'The status of the queue data.';
$string['privacy:metadata:offlinequiz_results'] = 'This table stores all the result data, which is not storable in the quiz API.';
$string['privacy:metadata:offlinequiz_results:offlinegroupid'] = 'The offline quiz group which this result belongs to.';
$string['privacy:metadata:offlinequiz_results:offlinequizid'] = 'The offline quiz, which this result belongs to.';
$string['privacy:metadata:offlinequiz_results:status'] = 'The status of the result (incomplete or complete).';
$string['privacy:metadata:offlinequiz_results:sumgrades'] = 'The sum of all grades for this result.';
$string['privacy:metadata:offlinequiz_results:teacherid'] = 'The teacher who uploaded the result.';
$string['privacy:metadata:offlinequiz_results:timefinish'] = 'The end time the result was inserted for the first time.';
$string['privacy:metadata:offlinequiz_results:timemodified'] = 'The modify date for the result.';
$string['privacy:metadata:offlinequiz_results:timestart'] = 'The beginning of the time the result was inserted the first time.';
$string['privacy:metadata:offlinequiz_results:usageid'] = 'The template usage ID of the quiz API where this result is saved.';
$string['privacy:metadata:offlinequiz_results:userid'] = 'The user this result belongs to.';
$string['privacy:metadata:offlinequiz_scanned_p_pages'] = 'This table stores attendance pages and their general information.';
$string['privacy:metadata:offlinequiz_scanned_p_pages:error'] = 'The error (if present) this page triggered while processing.';
$string['privacy:metadata:offlinequiz_scanned_p_pages:filename'] = 'The name of the file for the scanned page.';
$string['privacy:metadata:offlinequiz_scanned_p_pages:listnumber'] = 'The number of the list.';
$string['privacy:metadata:offlinequiz_scanned_p_pages:offlinequizid'] = 'The offline quiz this attendance page belongs to.';
$string['privacy:metadata:offlinequiz_scanned_p_pages:status'] = 'The status of this scanned page.';
$string['privacy:metadata:offlinequiz_scanned_p_pages:time'] = 'The time this page was processed.';
$string['privacy:metadata:offlinequiz_scanned_pages'] = 'This table stores information on a scanned page of an offline quiz.';
$string['privacy:metadata:offlinequiz_scanned_pages:error'] = 'The detailed error this page has (if present).';
$string['privacy:metadata:offlinequiz_scanned_pages:filename'] = 'The file name of the scanned page.';
$string['privacy:metadata:offlinequiz_scanned_pages:groupnumber'] = 'The group number of the group this offline quiz belongs to.';
$string['privacy:metadata:offlinequiz_scanned_pages:offlinequizid'] = 'The offline quiz of the scanned page.';
$string['privacy:metadata:offlinequiz_scanned_pages:pagenumber'] = 'The page number of this page.';
$string['privacy:metadata:offlinequiz_scanned_pages:resultid'] = 'The result relating to this page.';
$string['privacy:metadata:offlinequiz_scanned_pages:status'] = 'The status of this page.';
$string['privacy:metadata:offlinequiz_scanned_pages:time'] = 'The time the page was processed.';
$string['privacy:metadata:offlinequiz_scanned_pages:userkey'] = 'The user key (not user ID) of the crossed out user on the page.';
$string['privacy:metadata:offlinequiz_scanned_pages:warningfilename'] = 'The file name of the file which is created when a wrongly filled in answer form is corrected and the user gets a warning about it.';
$string['privacy:metadata:offlinequizpagesize'] = 'Sets the number of entries for the results page.';
$string['qandabehaviourheader'] = 'Question and answer behaviour';
$string['questionanalysis'] = 'Question analysis';
$string['questionandansweranalysis'] = 'Question and answer analysis';
$string['questionforms'] = 'Question forms';
$string['questioninfoanswers'] = 'Number of correct answers';
$string['questioninfocorrectanswer'] = 'correct answer';
$string['questioninfocorrectanswers'] = 'correct answers';
$string['questioninfonone'] = 'Nothing';
$string['questioninfoqtype'] = 'Question type';
$string['questionsheet'] = 'Question form';
$string['questionsheetlatextemplate'] = '% GENERAL FORMATTING
% !TEX encoding = UTF-8 Unicode
\documentclass[{$a->fontsize}pt,a4paper]{article}
\usepackage[english]{babel}
\usepackage[utf8x]{inputenc}
\usepackage[T1]{fontenc}
\usepackage{amsmath} % for \implies etc.
\usepackage{amsfonts} % for \mathbb etc.
\usepackage{graphicx} % for using pictures
\usepackage{enumitem}
\usepackage{ifthen}
\usepackage{xcolor}
\usepackage{ulem}
\usepackage{acronym}
\usepackage[colorlinks=true, urlcolor=blue,linkcolor=black]{hyperref} % for using hyperlinks
\usepackage{lastpage}
\usepackage{fancyhdr}
\textwidth 16truecm
\textheight 23truecm
\setlength{\oddsidemargin}{0cm}
\setlength{\evensidemargin}{0cm}
\setlength{\topmargin}{-1cm}
\parindent 0pt % no indent on the beginning of a section
\pagestyle{fancy}
\renewcommand{\familydefault}{\sfdefault} % Font family
\chead{\sc \Title \Date, Group \Group}
\cfoot{Page \thepage/\pageref{LastPage}}
\makeatletter % disable pagebreaks between answers
\@beginparpenalty=10000
\@itempenalty=10000
\makeatother


% QUESTION FORM OR CORRECTION FORM:
% If second line is commented out -> question form, if first line is commented out -> correction form
\newcommand{\answerIs}[1]{} % Question form (true & false answers are not displayed)
% \newcommand{\answerIs}[1]{[#1]} % Correction form (true & false answers are displayed)



% ===========================================================================================================
% DATE OF THE EXAM
\newcommand{\Title}{{$a->activityname}} % Module name, alternatively use the course name {{$a->coursename}}
\newcommand{\Date}{{$a->date}}
\newcommand{\Group}{{$a->groupname}}

\newcommand{\TestTitle}{
\begin{center}
{\bf \Large Question form}\\\\[3mm]
\fbox{
\begin{tabular}{rl}
\rule{0pt}{25pt}
Name: & $\underline{\hspace*{8cm}}$\rule{20pt}{0pt}\\\\[5mm]
ID number: & $\underline{\hspace*{8cm}}$\\\\[5mm]
\ifthenelse{\equal{true}{{$a->printstudycodefield}}}{\rule{10pt}{0pt} Study code: & $\underline{\hspace*{8cm}}$\\\\[5mm]}{}
\rule[-20pt]{0pt}{20pt}
Signature: & $\underline{\hspace*{8cm}}$
\end{tabular}}
\end{center}
}

\InputIfFileExists{offline_test_extras.tex}{}{} % Input extra user definitions

\begin{document}
% ===========================================================================================================

\TestTitle
% ===========================================================================================================
\bigskip
% ===========================================================================================================

{$a->pdfintrotext}
% ===========================================================================================================

\newpage
% ===========================================================================================================

{$a->latexforquestions}
% ===========================================================================================================

\end{document}';
$string['questionsingroup'] = 'Group';
$string['queueamountofpages'] = 'Amount of included files:';
$string['queuefilecorrectionhovertext'] = 'Correction';
$string['queuefiledownloadhovertext'] = 'Download';
$string['queuefileerror'] = 'Error message:';
$string['queuefilefilename'] = 'Origin file:';
$string['queuefileimportedby'] = 'Imported by:';
$string['queuefilenotstarted'] = 'Evaluation not started yet';
$string['queuefileprocessing'] = 'Evaluation in progress...';
$string['queuefilesactionsheader'] = 'Actions';
$string['queuefilesdetailsheader'] = 'Details';
$string['queuefilesfileheader'] = 'File';
$string['queuefilestatusheader'] = 'Status';
$string['queuefilestatusmessage_error'] = 'Correction necessary';
$string['queuefilestatusmessage_new'] = 'submitted';
$string['queuefilestatusmessage_processed'] = 'OK';
$string['queuefilestatusmessage_processing'] = 'processing';
$string['queuefilestatusmessage_submitted'] = 'submitted';
$string['queuefinishedtime'] = 'Evaluation finished at:';
$string['queueheader'] = 'Uploaded files';
$string['queuenotfinished'] = 'Evaluation not finished.';
$string['queuenotstarted'] = 'Evaluation not started.';
$string['queuestarttime'] = 'Evaluation started at:';
$string['quizdate'] = 'Date of offline quiz';
$string['quizopenclose'] = 'Open and close dates';
$string['quizopenclose_help'] = 'The online review can be restricted to a specific time period. Click on "Show" to change the date and time settings.

**Caution:** If no time period is activated for the online review, the review is unrestricted as long as the offline quiz is visible to the participants.

In all cases, only the options ticked under "Review includes" are displayed.';
$string['qversioncannotupdate'] = 'Question version cannot be updated';
$string['qversionnumbersdiffer'] = 'The number of answers differ between the old and the new version. This would lead to inconsistencies.';
$string['qversionupdated'] = 'Question version updated';
$string['qversionupdatedwarning'] = 'Forms were already created.<br>If results exist they were regraded automatically to the current version of the changed question chosen here. The original version of the question is still shown in the documents.';
$string['qversionupdateerror'] = 'There was an error updating the question version.';
$string['readjust'] = 'Readjust';
$string['reallydeletepdfs'] = 'Do you really want to delete the form files?';
$string['reallydeleteupdatepdf'] = 'Do you really want to delete and update the attendance list?';
$string['recurse'] = 'Include questions from subcategories too';
$string['rediswrong'] = 'wrong cross or missing cross';
$string['reloadquestionlist'] = 'Reload question list';
$string['removepagebreak'] = 'Remove page break';
$string['removeselected'] = 'Remove selected';
$string['repaginate'] = 'Repaginate with {$a} questions per page';
$string['repaginatecommand'] = 'Repaginate';
$string['reportends'] = 'Review of results ends';
$string['reportoverview'] = 'Overview';
$string['reportstarts'] = 'Review of results starts';
$string['result'] = 'Result';
$string['resultimport'] = 'Upload';
$string['resultnotcomplete'] = 'Result is not complete.';
$string['results'] = 'Results';
$string['reviewcloses'] = 'Review closes';
$string['reviewincludes'] = 'Review includes';
$string['reviewofresult'] = 'Review of result';
$string['reviewopens'] = 'Review opens';
$string['reviewoptions'] = 'Review options';
$string['reviewoptions_help'] = 'With these options you can control what the students may see after the results were imported. You can also define start and end time for the results report.

The checkboxes mean:

**The attempt** - The text of the questions and answers will be shown to the students. They will see which answers they chose, but the correct answers will not be displayed.

**Whether correct** - This option can only be activated if the option "The attempt" is activated. If activated, the students can see which of the chosen answers are correct (green background) or incorrect (red background).

**Marks** - The group (e.g. B), scores (achieved grade, total grade for questions, achieved in percent, e.g. 40/80 (50)) and the grade (e.g. 50 out of a maximum of 100) are displayed. Additionally, if "The attempt" is selected, the achieved score and the maximum score are shown for every question.

**Specific feedback** - Feedback that depens on what response the student gave.

**General feedback** - General feedback is displayed to the student after the results were imported. Unlike specific feedback, which depends on the question type and what response the student gave, the same general feedback text is shown to all students. You can use the general feedback to give students a fully worked out answer and perhaps a link to more information they can use if they did not understand the questions.

**Correct answers** - Correct and incorrect answers are displayed. This option is only available if "The attempt" is set.

**Scanned form** - The scanned answer forms are displayed. Checked boxes are marked with green squares.

**Scanned form with grades** - The scanned answer forms are displayed. Checked boxes are marked with green squares. Incorrect and missing marks are highlighted. Additionally, a table displays the maximum grade and the achieved grade for every question.';
$string['reviewoptionsheading'] = 'Review options';
$string['rotate'] = 'Rotate';
$string['rotatingsheet'] = 'Sheet is being rotated...';
$string['save'] = 'Save';
$string['saveandshow'] = 'Save and show changes to student';
$string['savemanualgradingfailed'] = 'Modification not saved. Please check the message below and try again.';
$string['scannedform'] = 'Scanned form';
$string['scanningoptionsheading'] = 'Scanning options';
$string['search:activity'] = 'Offline quiz - activity information';
$string['seequestions'] = 'See questions';
$string['selectagroup'] = 'Select a group';
$string['selectall'] = 'Select all';
$string['selectlist'] = 'Please select a list or try to readjust sheet:';
$string['selectmultipletoolbar'] = 'Select multiple toolbar';
$string['selectnone'] = 'Deselect all';
$string['selectpage'] = 'Please select page number or try to readjust sheet:';
$string['selectquestion'] = 'Select question {$a}';
$string['showallparts'] = 'Show all {$a} participants';
$string['showcopyright'] = 'Show copyright statement';
$string['showcopyrightdesc'] = 'If you enable this option, a copyright statement will be displayed on the student result review page.';
$string['showgrades'] = 'Print question grades';
$string['showgrades_help'] = 'This option controls whether the maximum grades of the offline quiz questions should be printed on the question form.';
$string['showmissingattemptonly'] = 'Show all checked participants without result';
$string['showmissingcheckonly'] = 'Show all unchecked participants with result';
$string['showquestioninfo'] = 'Print info about answers';
$string['showquestioninfo_help'] = 'With this option you can control what additional information about the question is printed on the question form.
You can choose one of these:
<ul>
<li> Nothing
<li> Question type - Depending on question type Single-Choice, Multiple-Choice, All-or-Nothing Multiple-Choice will be printed
<li> Number of correct answers - The number of correct answers will be printed
</ul>';
$string['showstudentview'] = 'Show report preview';
$string['showtutorial'] = 'Show an offline quiz tutorial to students.';
$string['showtutorial_help'] = 'This option determines whether students can see a tutorial about the basics of offline quizzes.
The tutorial provides information about how to use the different types of documents in offline quizzes. In an interactive part students learn how to tick their student ID correctly.<br />
<b>Please note:</b><br />
If you set this option to "Yes" but hide the offline quiz the link to the tutorial will not be visible. In this case you can add a link to the tutorial on the course page.';
$string['showtutorialdescription'] = 'You can add a link to the tutorial to the course page using the following URL:';
$string['shuffleanswers'] = 'Shuffle answers';
$string['shufflequestions'] = 'Shuffle questions';
$string['shufflequestionsanswers'] = 'Shuffle questions and answers';
$string['shufflequestionsselected'] = 'Shuffle questions has been set, so some actions relating to pages are not available. To change the shuffle option, {$a}.';
$string['shufflewithin'] = 'Shuffle within questions';
$string['shufflewithin_help'] = 'If enabled, the parts making up each question will be randomly shuffled each time you press the reload button in the form preview. NOTE: This setting only applies to questions that have the shuffling option activated.';
$string['signature'] = 'Signature';
$string['singlechoice'] = 'Single choice';
$string['standard'] = 'Standard';
$string['statisticsplural'] = 'Statistics';
$string['statisticsviewheader'] = '3. Statistics';
$string['studycode'] = 'Study code';
$string['subplugintype_offlinequiz'] = 'Offline quiz report';
$string['subplugintype_offlinequiz_plural'] = 'Offline quiz reports';
$string['tabattendances'] = 'Attendances';
$string['tabdownloadparticipantsforms'] = 'Forms';
$string['tabeditgroupquestions'] = 'Questions';
$string['tabeditparticipants'] = 'Participants';
$string['tabofflinequizcontent'] = 'Preparation';
$string['tabofflinequizcorrect'] = 'Correction';
$string['tabparticipantlists'] = 'Attendance lists';
$string['tabparticipantscorrect'] = 'Correct';
$string['tabparticipantsupload'] = 'Upload';
$string['tabpreview'] = 'Forms';
$string['tabresults'] = 'Results';
$string['tabresultsoverview'] = 'Results';
$string['tabstatistics'] = 'Statistics';
$string['temporaryfiledeletiontask'] = 'Delete temporary files';
$string['testdate'] = 'Test date';
$string['testsettingsheader'] = 'Test settings';
$string['theattempt'] = 'The attempt';
$string['timesup'] = 'Time is up!';
$string['totalmarksx'] = 'Total of marks: {$a}';
$string['tutorial'] = 'Tutorial for offline quizzes';
$string['tutorial:alt:answerform'] = 'The answer form of the offline quiz';
$string['tutorial:alt:answersimage'] = 'Answers image';
$string['tutorial:alt:checkboxbold'] = 'Boldly marked checkbox';
$string['tutorial:alt:checkboxdeleted'] = 'fully black marked checkbox';
$string['tutorial:alt:checkboxempty'] = 'Empty checkbox';
$string['tutorial:alt:checkboxlight'] = 'Lightly marked checkbox';
$string['tutorial:alt:checkboxmarked'] = 'Marked checkbox';
$string['tutorial:alt:questionaire'] = 'A question form';
$string['tutorial:feedback:1:1'] = 'There are no questions on the answer form. The answer form only contains the boxes for marking your answers in.';
$string['tutorial:feedback:1:2'] = 'The layout of the question form doesn\'t have to look exactly the same as the one in the screenshot. It is only to show you the questions and it is not scanned in after the examination.';
$string['tutorial:feedback:2:1'] = 'This cross is too pale. It is possible that it will not be scanned correctly.';
$string['tutorial:feedback:2:2'] = 'A cross of normal line width will always be interpreted correctly.';
$string['tutorial:feedback:2:3'] = 'A thick cross may be interpreted as having been corrected (filled in completely).';
$string['tutorial:feedback:2:4'] = 'An empty box will never be interpreted as a cross.';
$string['tutorial:feedback:2:5'] = 'A completely filled in box is interpreted exactly the same as an empty box.';
$string['tutorial:feedback:3:1'] = 'Only the crosses in the boxes are scanned. That is why it is so important to mark the right boxes under your identification number.';
$string['tutorial:feedback:3:2'] = 'Only the crosses in the boxes are scanned. That is why it is so important to mark the right boxes under your identification number.';
$string['tutorial:feedback:3:3'] = 'Only the crosses in the boxes are scanned. That is why it is so important to mark the right boxes under your identification number.';
$string['tutorial:feedback:3:4'] = 'Only the crosses in the boxes are scanned. That is why it is so important to mark the right boxes under your identification number.';
$string['tutorial:feedback:4:0'] = 'You have made a mistake. Your identification number is {$a->correctusernumber}, but you marked {$a->selectedusernumber}';
$string['tutorial:feedback:4:1'] = 'You have successfully completed this tutorial.';
$string['tutorial:feedback:correct'] = 'Correct!';
$string['tutorial:feedback:wrong'] = 'Wrong!';
$string['tutorial:generatedusernumberwarning'] = 'This is a generated identification number since your account doesn\'t have one!';
$string['tutorial:header:1'] = '1. Question and answer forms';
$string['tutorial:header:2'] = '2. Crosses and corrections';
$string['tutorial:header:3'] = '3. The answer form';
$string['tutorial:header:4'] = '4. Marking your identification number';
$string['tutorial:header:5'] = '5. Finally...';
$string['tutorial:identification_info'] = 'Your identification number is: {$a}';
$string['tutorial:introduction:1'] = 'In the examination you will receive two forms: one with the questions and one with boxes to mark your answers on. The questions are numbered and so are the boxes on the answer form. Each answer is marked with a letter. After the examination, the answer form is scanned and interpreted by a computer.';
$string['tutorial:introduction:2:1'] = 'The boxes on the answer form are 5 millimetres wide. The boxes belonging to the same question are in one row. The number of the question is on the left hand side and the letter corresponding to the answer item is at the top of the column.';
$string['tutorial:introduction:2:2'] = 'Use a black or blue pen to mark the fields. If you want to correct a mark, fill in the box completely. This field will then be interpreted as an empty box.';
$string['tutorial:introduction:3:1'] = 'The answer form contains a block for your name (A), a block for your identification number (B) and a block for the answers (C). Fill in the boxes for your name, signature and identification number first. Please note that the machine will not try to interpret your handwriting after the examination. These boxes are only for documentation purposes.';
$string['tutorial:introduction:3:2'] = 'Mark the boxes for your identification number carefully as the computer will need these marks to identify your results. Mistakes in the block with your identification number can lead to delays and misinterpretation.';
$string['tutorial:introduction:4'] = 'At the end of this tutorial we offer you a little test where you can learn how to fill in the marks for your identification number correctly. Under the box for your identification number is a matrix of boxes. Each column stands for one digit of your identification number. The rows mark the numbers written on the left and right hand side. Click on the boxes to mark them. Click again to delete your mark. If you want to start again, please <a href="javascript: document.location.reload()">reload the page</a>.';
$string['tutorial:introduction:5'] = 'Please keep in mind, that the answer forms are interpreted by a computer programme. It can\'t read anything you write next to the boxes. To the computer programme, anything outside the boxes is just a spot that prevents the machine from interpreting the form correctly. You are punishing yourself if you don\'t place the marks correctly.';
$string['tutorial:option:1:1'] = 'An answer form';
$string['tutorial:option:1:2'] = ' A question form';
$string['tutorial:option:3:1'] = 'The system reads your name using optical character recognition software.';
$string['tutorial:option:3:2'] = 'Your signature is scanned using software used for finger prints in criminal investigations.';
$string['tutorial:option:3:3'] = 'Only the crosses in the boxes under your identification number are interpreted.';
$string['tutorial:option:3:4'] = 'The system reads your identification number using optical character recognition software.';
$string['tutorial:question:1'] = 'This image shows:';
$string['tutorial:question:2'] = 'Which mark will be interpreted as a cross for sure?';
$string['tutorial:question:3'] = 'How does the computer assign the answer form to the right person?';
$string['tutorial:question:4'] = 'Identification number';
$string['tutorial:question:5'] = 'Good luck!';
$string['tutorial:questionsheet:1'] = '1)&nbsp;&nbsp; How many offline quiz documents will be given to you during an exam?';
$string['tutorial:questionsheet:1:1'] = 'a)&nbsp;&nbsp;0';
$string['tutorial:questionsheet:1:2'] = 'b)&nbsp;&nbsp;1';
$string['tutorial:questionsheet:1:3'] = 'c)&nbsp;&nbsp;2';
$string['tutorial:questionsheet:1:4'] = 'd)&nbsp;&nbsp;3';
$string['tutorial:questionsheet:1:5'] = 'e)&nbsp;&nbsp;4';
$string['tutorial:questionsheet:1:marks'] = '(Points: 1)';
$string['tutorial:questionsheet:2'] = '2)&nbsp;&nbsp; What content is available on a questionnaire of the offline quiz?';
$string['tutorial:questionsheet:2:1'] = 'a)&nbsp;&nbsp;Questions';
$string['tutorial:questionsheet:2:2'] = 'b)&nbsp;&nbsp;Answer options';
$string['tutorial:questionsheet:2:3'] = 'c)&nbsp;&nbsp;Correct answers';
$string['tutorial:questionsheet:2:4'] = 'd)&nbsp;&nbsp;Further information';
$string['tutorial:questionsheet:2:5'] = 'e)&nbsp;&nbsp;None of them';
$string['tutorial:questionsheet:2:marks'] = '(Marks: 1)';
$string['tutorial:start_text'] = 'This tutorial will show you the correct way of filling out the forms of an offline quiz and marking your answers for the automatic evaluation. We highly recommend you do the tutorial at least once, before having your first test or exam with an offline quiz.';
$string['tutorial:starttutorial'] = 'Start tutorial';
$string['tutorial:title'] = 'Tutorial';
$string['tutorial:title:navigation'] = 'Navigation';
$string['tutorialbutton'] = 'Start tutorial';
$string['uncheckparts'] = 'Mark selected participants as absent';
$string['upgradingfilenames'] = 'Upgrading filenames of documents: offline quiz {$a->done}/{$a->outof} (Offline quiz ID {$a->info})';
$string['upload'] = 'Upload';
$string['uploadfurtherfiles'] = 'Upload further files';
$string['uploadpart'] = 'Upload';
$string['userdoesnotexist'] = 'User {$a} does not exist in system';
$string['useridentification'] = 'User identification';
$string['userimported'] = 'User {$a} imported and graded';
$string['userpageimported'] = 'Single page imported for user {$a}';
$string['usetabs'] = 'Use tabs-based navigation';
$string['usetabsdesc'] = 'If enabled, the offline quiz third-level navigation will be displayed using tabs. If disabled, the offline quiz navigation will be displayed using a dropdown menu.';
$string['viewresultbutton'] = 'View result';
$string['white'] = 'White';
$string['wirismathenabled'] = 'Enable WIRIS Math equations';
$string['wirismathenabled_help'] = 'If enabled, WIRIS Math equations can be used in the question text and answers.';

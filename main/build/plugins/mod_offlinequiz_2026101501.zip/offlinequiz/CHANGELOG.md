CHANGELOG
=========
5.2.0
-----------------
* [Feature] 5.2 compatible version
  * IMPORTANT: Since Moodle removed mimetex in 5.2, latex expressions will only work if the tex filter works. You can test it at https//your.moodle.instance/filter/tex/texdebug.php
  * The tex-filter does NOT support '&#36;' as delimiter for latex formulas. Questions using this need to be changed to '&#36;&#36;' in order to work. We are investigating options to use the Mathjax settings.
* [Feature] Changed the order of the offlinequiz activity settings and gave them a proper renaming to be more understandable
* [Feature] The document logo is now changable via filepicker. If you have already set a url it is downloaded during the upgrade. Any changes on the logo have to be done in moodle from now on. [github #267]
* [Feature] Support for the Activity chooser activity enhancements (see https://moodle.atlassian.net/browse/MDL-87117)
* [Bug] Fixed a bug when changing the points of a question to higher than the whole tests points
* [Bug] Changed the order of questions when displaying or downloading the statistics of a group other than A
* [Bug] Fixed a slow privacy provider export
* [Bug] Fixed that Non-editing teachers get an error when viewing the offlinequiz
* [Bug] Fixed the layout and position of the action buttons under the results table
* [Bug] Fixed that super and lower texts added new lines in DOCX documents
* [Bug] Fixed the look of the controls on the result overview
* [Bug] Fixed that the order of questions wasn't correct in the single group view in the statistics overview
* [Bug] Fixed that 'code' and 'pre' tags had a scroll bar [github #289]
* [Bug] Fixed that multiple versions of the same question were addable when they were not in the offlinequiz questionbank
* [Bug] Fixed that no note was displayed, when questions of an offline quiz with only one group where changed afer creating the forms. [github #278]
* [Bug] Removed a lot of unneccesary langstrings


5.1.1
-----------------
* [Security] Fixed a remote code execution with uploading arbitrary files

5.1.0
-----------------
* [Feature] 5.1 compatible version
* [Feature] added a setting to set a default max mark [github #321 @gmanaud]
* [Feature] Display question categories in the question overview
* [Feature] Support for code and pre tags
* [Feature] Support further information in the activity overview
* [Bug] Fontsize was not working for LaTeX forms
* [Bug] Changed that partial results also show the name and user profile picture
* [Bug] Fixed faulty display of questions list for long questions or questions with html
* [Bug] Support underline formatting of tinymce
* [Bug] Fixed PDFs if the logo size can not be calculated for some reason [github #331 @jpahullo]
* [Bug] Fixed PDF upload in attendance lists
* [Bug] Fixed "0" as answer leading to broken docx document generation
* [Bug] Fixed questionnaire box formatting in docx
* [Bug] Fixed that the pdf file name isn't displayed correctly in the list of uploaded files
* [Bug] Fixed that the questions in the tutorial weren't indented properly
* [Bug] Fixed the duplication of multiple offlinequizzes

5.0.6
-----------------
* [Bug] Fixed an error with viewing the full report [github #338]
* [Bug] Fixed an error deleting questions in Group A instead of the requested group when deleting multiple questions

5.0.5
-----------------
* [Bug] removed extra gap between answers in question pdf

5.0.4
-----------------
* [Bug] Fixed broken intro format after duplication or import

5.0.3
-----------------
* [Bug] fixed evaluation mails not being sent under certain conditions
* [Bug] fixed that temporary file evaluation task deleted the cron folder

5.0.2
-----------------
* [Bug] Fixed a bug that evaluations didn't work if offlinequiz was installed with 5.0.0 or later
* [Bug] Fixed that random questions couldn't be added [github #323]
* [Bug] Fixed fail of scheduled task deleting temporary files [github #322]

5.0.1
-----------------
* [Bug] Fixed that it was not possible to use questions from other question banks

5.0.0
-----------------
* [Feature] 5.0 compatible version.
* [Feature] Adding questions is changed to the behaviour like in Quiz 5.0
* [Feature] Introduced a list of all uploaded files to the offline quiz on the "Correction" page.
* [Feature] It is possible to download the original uploaded file now.
* [Feature] Offlinequiz uses adhoc tasks now instead of cronjobs. The old cronjobs are still supported for compatibility reasons.
* [Feature] (Technical) Notifications that an upload has been processed use the moodle notifications API to give users more choice how to use it.  [github PR #308 @juacas]
* [Feature] Now offlinequiz supports wiris math equations. [github PR 305 @juacas]
* [Feature] It is now possible to create prefilled forms for a students attendance list. If you used the subplugin "identified" please uninstall it before upgrading [github pull #299 @juacas]
* [Feature] (Technical) Started supporting easier sub plugin development for offlinequiz. Documentation will come for a later release.
* [Feature] The amount of pages being displayed is now saved for each user [github #265]
* [Feature] Students get more info before they can try the tutorial [github #311, PR #313 @juacas]
* [Feature] Administrators can choose if the navigation is displayed as tab or select [PR #282 @juacas, PR #298, @juacas]
* [Bug] Fixed that uploading large files crashing the webserver by moving the page extraction to adhoc task.
* [Bug] Fixed restoring without user data creates records of scanned pages [#github 301]
* [Bug] Fixed uploading files with special made strange erros.
* [Bug] Deprecated JS function M.core_question_engine.init_form removed [github #297]
* [Bug] Fixed black images extraction [github PR #314 @juacas]
* [Bug] Non editing teachers can't access the activity [github #309/ github PR #310 @juacas]
* [Bug] Rewrote the backup process to fix multiple backup/restore bugs.
* [Bug] Fixed that < breaks docx documents [github #306, PR #305 @juacas]

4.5.3
----------------
* [Bug] Fixed that no change in version was possible after restore
* [Bug] Fixed missing pdffont setting for newer installations
* [Bug] Fixed missing column-definition for pdffont in file install.xml [github #290]
* [Bug] Fixed answers which contain < > characters still break the PDFs in specific situations. [github PR #283 @juacas]
* [Bug] Fixed deprecated use of \qbank_managecategories\question_category_object in addrandom.php [github #296]
* [Bug] Fixed deprecated filter mathjaxloader [github #286/ github PR #287 @mhughes2k]
* [Bug] Fixed JSON parse error with unrecognized token '<' when adding questions [github #294]

4.5.2
-----------------
This version was skipped.

4.5.1
-----------------
* [Bug] Fixed that adding questions was not possible, introduced through moodle core 4.5.2

4.5.0
-----------------
* [Feature] 4.5 compatible version

4.4.0
-----------------
* [Feature] 4.4 compatible version with new logo using the new logo style
* [Feature] Rework on the tutorial so it is translateable in AMOS now
* [Feature] Manual regrading removed, since it's done automatically
* [Feature] New setting for PDF font style. Warning for admins: The default font has changed - from (Free-)Sans - but can be (re-)set in the admin settings.
* [Feature] New admin setting for default font size [github #254]
* [Feature] Students will be sent immediately to either the tutorial or their result depending on the status of the offline quiz
* [Feature] Rework on the activity overview page: attendances now available in new style
* [Feature] Report subplugins can now add themselves to the navigation by implementing a offlinequiz_${pluginname}_report->add_to_tabs() function. [github PR #219 - juacas]
* [Info] You might want to checkout a new subplugin for prefilled forms support: https://github.com/juacas/moodle-offlinequiz_identified. Since this plugin is developed by the community, we cannot provide support for it.
* [Bug] Fixed PHP 8.2 warnings
* [Bug] Fixed bug where a question could be added twice if an older version was already added
* [Bug] Fixed encoding issues concerned with uploaded files
* [Bug] Fixed bug in the document creation after changing the question version

4.3.3
-----------------
[Bug] Fixed a version upgrade path in Offlinequiz 4.1.5 which lead to offlinequiz not working anymore.

4.3.2
-----------------
* [Bug] Fixed some more statistics errors [github #245]
* [Bug] Fixed some bugs regarding the filter for adding questions from question bank
* [Bug] Fixed that the question version selection in restored offlinequizzes was not correct
* [Bug] Fixed that some data was not deleted correctly when deleting a course/offlinequiz activity [github #230]
* [Bug] Fixed that user_get_participants was used in the privacy provider which doesn't exist anymore [github #242]
* [Bug] Fixed deleting offlinequizzes resulted in questions still in use [github #165]

4.3.1
-----------------
* [Bug] Fixed some statistics that weren't displayed correctly
* [Bug] Fixed bug with adding and deleting questions in Group B to F
* [Bug] Fixed bug with adding questions randomly
* [Bug] Fixed some bugs with the filter when adding questions from the question bank

4.3.0
-----------------
* [Feature] Compatible Version for Moodle 4.03
* [Feature] Support questions from global context and use the question add popup like in quiz
* [Feature] Support for up to 10 digits for the user identification [github #213]
* [Feature] User table field "id" and fields with numbers (phone1,phone2) are now officially supported for user identification [github #181 and #204/ github pull request #207/ #208 @mhughes2k]
* [Bug] Fixed wrong amount of tests with errors/results displayed on the overview page
* [Bug] Fixed bug for "<" and ">" in plain text fields [github #221]
* [Bug] Fixed bug to manually mark participants as present/not present [github #173]
* [Bug] Fixed statistics to work with big offlinequizzes with many users even on big moodle instances
* [Bug] Fixed bug with divide by zero error in statistics if nobody chose the answer of a question
* [Bug] Fixed bug with error message when no results where chosen to delete
* [Bug] Fixed image out of bounds error for skew answer sheets
* [Bug] Fixed some filename errors under windows
* [Bug] Fixed that page not displayed in course block Activities if there are offlinequizzes in multiple sections [github #222]
* [Bug] Fixed incorrect overview displayed under oracle databases [github #211]
* [Bug] Fixed statistics under oracle databases [github #146]
* [Bug] Fixed bug in line 155 index.php [github #222]
* [Bug] Fixed bug with url enconding [github pull request #188 @jboulen]
* [Bug] Fixed that deleting groups has no effect in overview
* [Bug] Grades and Gradebook update now correctly after question version is changed

4.2.0
-----------------
**WARNING:** THIS UPDATE MAY TAKE SOME TIME ON LARGE INSTANCES! For more information see https://github.com/academic-moodle-cooperation/moodle-mod_offlinequiz/issues/220

* [Feature] Compatible Version for Moodle 4.02
* [Feature] Regrading now works automatically. It is still possible to regrade on request in case of an error.
* [Feature] Using newer PDFWord version compatible with PHP 8.2+
* [Feature] Better feedback on changing question versions.
* [Bug] Fixed missing question references so you can't delete questions that are still in use.
* [Bug] Fixed some bugs regarding participants lists with multiple pages and multiple groups
* [Bug] Fixed that questions were not randomized even if shuffle questions was turned on.
* [Bug] Fixed a bug that new versions were not added to all groups.
* [Bug] Fixed a bug, that question versions were displayed wrong.
* [Bug] Fixed an error in the preview caused changing question versions

4.1.0
-----------------
* [Feature] Compatible Version for Moodle 4.01
* [Feature] On the overview page you can see the progress of what's done.

4.0.1
-----------------
* [Bug] Fixed that offlinequiz was not compatible with Moodle 4.0.0 to 4.0.3

4.0.0
-----------------
* [Feature] Compatible Version for Moodle 4.0
* [Feature] It is now possible to change the question version, even after the documents are created
* [Feature] New activity overview page when coming in to offlinequiz
* [Feature] changing a question directly in offlinequiz results in a recalculation of all the grades in that group
* [Feature] sub-navigation changed so it fits to the new moodle standard

3.11.4
-----------------
* [Bug] Fix PHP 8.0 incompabilities
* [Bug] Date of test used instead of review start used for calendar
* [Bug] Wrong language string for "group" was used in all questionsheets (pdf, LaTeX and docx)

3.11.3
-----------------
* [Bug] Fixed a bug that special html characters would break docx documents

3.11.2
-----------------
* [Feature] Autocompletion rules from quiz: grade and passing grade as well as view have been added.
* [Bug] Fix privacy provider if there are multiple users in an offlinequiz context. [github pull #157 @micaherne]
* [Bug] Heading consistency: Every page has a heading before the tabs.
* [Feature] Question sheet: Latex question sheet now shows activityname instead of coursename, both variables are still possible.
* [Bug] CLI execution on another server than the cron server is now possible again.
* [Bug] Non-breaking spaces are now possible to use in docx documents.
* [Bug] Removed deprecation message on the statistics page.
* [Bug] The edit page for the questions looks much nicer and without any strange artifacts.

3.11.1
-----------------
* [Feature] Solve version confusion with 3.11.0 and 3.10.1

3.11.0
-----------------
* [Feature] Compatible Version for Moodle 3.11

3.10.1
-----------------
* [Bug] Fix privacy bug for people using integer-idnumber

3.10.0
-----------------
* [Feature] Compatible Version for Moodle 3.10

3.9.0
-----------------
* [Feature] Support for all kinds of special characters in pdf/docx/LaTeX documents.
* [Feature] Deleted table offlinequiz_attempts, which wasn't used since moodle/offlinequiz 2.0.
* [Feature] Support of superscript and subscript in docx documents.
* [Feature] Support of "<" and ">" in LaTeX documents.
* [Bug] Changed css so it doesn't interfere with quiz anymore.
* [Feature] Offlinequiz now recognizes, if there are multiple users with a given idnumber.
          It will choose the one in the course. Otherwise it will throw an error.
* [Feature] Rewrote some of the privacy lang strings to make them more clear.


3.8.2
-----------------
* [Bug] Fixed a long existing bug with offlinequiz not using the right temp folder which leads to errors when setting localcache-directory in config.php.

3.8.1
-----------------
* [Bug] Fixed a bug that not all questions were shown in question statistics

3.8.0
-----------------
* [Feature] Moodle 3.8 compatible Version
* [Feature] Updated PDFWord version to 0.17.0


3.7.0
-----------------
* [Feature] Moodle 3.7 compatible Version
* [Feature] #6046 changed the place of reviewoptions to be more accurate
* [Bug] #6166 deletion of hotspots and old temp-files has not been done, now done by an own task
* [Feature] #6038 export results as printable html for face to face review
* [Feature] #6125 support of the plugin editdates
* [Bug] #6047 question tagging now works properly as in quiz
* [Feature] #4375 extended information about review options in offlinequiz
* [Bug] #6054, github issue #79: fixed that only students could be enroled into courses
* [Bug] #6115, github issue #81: fixed a couple of problems with oracle databases.


3.6.2 (2019-02-28)
-----------------
* added information about imagemagick in the README.md
* fixed broken image links in 'show student view' popup
* fixed a performance bug for upgrading big moodle-instances to 3.6.0. If you already upgraded to 3.6.0 this fix will not affect you at all.
* fixed a spacing issue in the statistics tab for choosing groups
* fixed a missing langstring ('questionpage')

3.6.1 (2019-02-11)
-----------------
* fixed a wrong hardcoded prefix in the offlinequiz plugin
* fixed an upgrade-query not working on certain databases
* added the userlist_provider feature

3.6.0 (2019-01-29)
-----------------
* Moodle 3.6 compatible Version
* added an experimental way to evaluate answer sheets. This is the new way, but don't use it in production systems
* Icon for adding questions was not visible.
* Privacy-API changes for moodle 3.6
* return to default group if chosen in the statistics menu
* fixed an evaluation error for big zip file uploads

3.5.3 (2018-11-29)
------------------
* Bugfix: Questions can not be sorted

3.5.2 (2018-11-29)
------------------
* Fixed a bug, where the update of scanned pages lead to wrong results with "missing pages", even though there is only one page in the test

3.5.1 (2018-11-27)
------------------
* fixed a bug where under certain circumstances at the result download the grade was not correct.

3.5.0 (2018-08-13)
------------------
* Moodle 3.5 compatible version
* introduced privacy API
* partial results are displayed by default in the result table
* added possibility to upload pdf files

3.4.2 (2018-04-10)
------------------
* changed the way how LaTeX-Question sheets work. It should now support almost every question that is written in the moodle editor
* export of results now has the column "letter"
* fixed an error for the calender-plugin where the report-appointment was displayed for all the days

3.4.1 (2018-01-17)
------------------
* fixed an error, where under certain condition the field id_digits was missing.

3.4.0 (2017-11-16)
-------------------
* latex-document supports double-$ as begin-tag for formulas in new line
* latex-document supports underline, bold and italic texts
* new option for alignment of latex-questions in pdf-files

3.3.2 (2017-11-06)
-------------------
* additional index for tables page_corners and scanned_page

3.3.0 (2017-08-03)
------------------
* Moodle 3.3 compatible version
* Official support of boost Theme
* Offlinequizzes are now searchable through the moodle search
* Multiple little bugfixes

3.2.0 (2017-02-01)
------------------

* Moodle 3.2 compatible version

3.1 (2016-07-23)
----------------

* First release for Moodle 3.1


3.0 (2016-05-18)
----------------

* First release for Moodle 3.0


2.9 (2015-11-20)
----------------

* First release for Moodle 2.9


2.8 (2015-06-09)
----------------

* First release for Moodle 2.8


2.7 (2014-09-23)
----------------

* First release for Moodle 2.7


2.6 (2014-03-31)
----------------

* First release for Moodle 2.6

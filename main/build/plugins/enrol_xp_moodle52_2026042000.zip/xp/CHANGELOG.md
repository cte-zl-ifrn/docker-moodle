Changelog
=========

v1.0.7
------

- Compatibility with Moodle 5.2

v1.0.6
------

- Minor coding style and depreciation updates

v1.0.5
------

- Behat tests to confirm behaviour of level enrolment
- Minor coding style and depreciation updates

v1.0.4
------

- Minor coding style and depreciation updates

v1.0.3
------

- Renamed the plugin to Level Up XP Enrolment

v1.0.2
------

- Fix issue when sending enrolment message

v1.0.1
------

- Implement privacy API (GDPR compliance)

v1.0.0
------

- Initial release

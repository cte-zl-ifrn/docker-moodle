<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * File contains the unit tests for the email certificate task.
 *
 * @package    mod_customcert
 * @category   test
 * @copyright  2017 Mark Nelson <markn@moodle.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_customcert;

use completion_info;
use context_module;
use stdClass;
use context_course;
use advanced_testcase;
use mod_customcert\task\email_certificate_task;
use mod_customcert\task\issue_certificates_task;

/**
 * Unit tests for the email certificate task.
 *
 * @package    mod_customcert
 * @category   test
 * @copyright  2017 Mark Nelson <markn@moodle.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @coversDefaultClass \mod_customcert\task\email_certificate_task
 */
final class email_certificate_task_test extends advanced_testcase {
    /**
     * Test set up.
     */
    public function setUp(): void {
        $this->resetAfterTest();

        set_config('certificateexecutionperiod', 0, 'customcert');

        parent::setUp();
    }

    /**
     * Tests the email certificate task when there are no elements.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_no_elements(): void {
        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create a user.
        $user1 = $this->getDataGenerator()->create_user();

        // Create a custom certificate with no elements.
        $this->getDataGenerator()->create_module('customcert', ['course' => $course->id, 'emailstudents' => 1]);

        // Enrol the user as a student.
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Confirm that we did not send any emails because the certificate has no elements.
        $this->assertCount(0, $emails);
    }

    /**
     * Tests the email certificate task for users without a capability to receive a certificate.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_no_cap(): void {
        global $DB;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create some users.
        $user1 = $this->getDataGenerator()->create_user();
        $user2 = $this->getDataGenerator()->create_user();

        // Enrol two of them in the course as students but revoke their right to receive a certificate issue.
        $roleids = $DB->get_records_menu('role', null, '', 'shortname, id');
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);
        $this->getDataGenerator()->enrol_user($user2->id, $course->id);

        unassign_capability('mod/customcert:receiveissue', $roleids['student']);

        // Create a custom certificate.
        $customcert = $this->getDataGenerator()->create_module('customcert', ['course' => $course->id, 'emailstudents' => 1]);

        // Create template object.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);

        // Add a page to this template.
        $pageid = $template->add_page();

        // Add an element to the page.
        $element = new stdClass();
        $element->pageid = $pageid;
        $element->name = 'Image';
        $DB->insert_record('customcert_elements', $element);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Confirm that we did not send any emails.
        $this->assertCount(0, $emails);
    }

    /**
     * Tests the email certificate task for students.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_students(): void {
        global $CFG, $DB;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create some users.
        $user1 = $this->getDataGenerator()->create_user();
        $user2 = $this->getDataGenerator()->create_user();
        $user3 = $this->getDataGenerator()->create_user();
        $user4 = $this->getDataGenerator()->create_user(['firstname' => 'Teacher', 'lastname' => 'One']);

        // Enrol three of them in the course as students.
        $roleids = $DB->get_records_menu('role', null, '', 'shortname, id');
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);
        $this->getDataGenerator()->enrol_user($user2->id, $course->id);
        $this->getDataGenerator()->enrol_user($user3->id, $course->id);

        // Enrol one of the users as a teacher.
        $this->getDataGenerator()->enrol_user($user4->id, $course->id, $roleids['editingteacher']);

        // Suspend one of the users.
        $DB->set_field('user', 'suspended', '1', ['id' => $user3->id]);

        // Create a custom certificate.
        $customcert = $this->getDataGenerator()->create_module('customcert', ['course' => $course->id,
            'emailstudents' => 1]);

        // Create template object.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);

        // Add a page to this template.
        $pageid = $template->add_page();

        // Add an element to the page.
        $element = new stdClass();
        $element->pageid = $pageid;
        $element->name = 'Image';
        $DB->insert_record('customcert_elements', $element);

        // Ok, now issue this to one user.
        \mod_customcert\certificate::issue_certificate($customcert->id, $user1->id);

        // Confirm there is only one entry in this table.
        $this->assertEquals(1, $DB->count_records('customcert_issues'));

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Get the issues from the issues table now.
        $issues = $DB->get_records('customcert_issues');
        $this->assertCount(2, $issues);

        // Confirm that it was marked as emailed and was not issued to the teacher or suspended student.
        foreach ($issues as $issue) {
            $this->assertEquals(1, $issue->emailed);
            $this->assertNotEquals($user3->id, $issue->userid);
            $this->assertNotEquals($user4->id, $issue->userid);
        }

        // Confirm that we sent out emails to the two users.
        $this->assertCount(2, $emails);
        $expectedemails = [$user1->email, $user2->email];

        foreach ($emails as $email) {
            $this->assertEquals($CFG->noreplyaddress, $email->from);
            $this->assertContains($email->to, $expectedemails);
            $expectedemails = array_diff($expectedemails, [$email->to]);
        }

        // Now, run the task again and ensure we did not issue any more certificates.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        $issues = $DB->get_records('customcert_issues');

        $this->assertCount(2, $issues);
        $this->assertCount(0, $emails);
    }

    /**
     * Tests the email certificate task for instance on the site home course.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_sitehome(): void {
        global $CFG, $DB, $SITE;

        // Create some users.
        $user1 = $this->getDataGenerator()->create_user();
        $user2 = $this->getDataGenerator()->create_user();

        // Create a custom certificate.
        $customcert = $this->getDataGenerator()->create_module('customcert', ['course' => $SITE->id,
            'emailstudents' => 1]);

        $role = $DB->get_record('role', ['archetype' => 'user']);
        role_change_permission($role->id, context_module::instance($customcert->cmid), 'mod/customcert:view', CAP_ALLOW);
        role_change_permission($role->id, context_module::instance($customcert->cmid), 'mod/customcert:receiveissue', CAP_ALLOW);

        // Create template object.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($SITE->id)->id;
        $template = new template($template);

        // Add a page to this template.
        $pageid = $template->add_page();

        // Add an element to the page.
        $element = new stdClass();
        $element->pageid = $pageid;
        $element->name = 'Image';
        $DB->insert_record('customcert_elements', $element);

        // Ok, now issue this to one user.
        \mod_customcert\certificate::issue_certificate($customcert->id, $user1->id);

        // Confirm there is only one entry in this table.
        $this->assertEquals(1, $DB->count_records('customcert_issues'));

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Get the issues from the issues table now.
        $issues = $DB->get_records('customcert_issues');
        $this->assertCount(3, $issues);

        // Confirm that it was marked as emailed and was not issued to the teacher.
        foreach ($issues as $issue) {
            $this->assertEquals(1, $issue->emailed);
        }

        // Confirm that we sent out emails to the users. This includes the site admin.
        $this->assertCount(3, $emails);
        $expectedemails = [get_admin()->email, $user1->email, $user2->email];

        foreach ($emails as $email) {
            $this->assertEquals($CFG->noreplyaddress, $email->from);
            $this->assertContains($email->to, $expectedemails);
            $expectedemails = array_diff($expectedemails, [$email->to]);
        }

        // Now, run the task again and ensure we did not issue any more certificates.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        $issues = $DB->get_records('customcert_issues');

        $this->assertCount(3, $issues);
        $this->assertCount(0, $emails);
    }

    /**
     * Tests the email certificate task for teachers.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_teachers(): void {
        global $CFG, $DB;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create some users.
        $user1 = $this->getDataGenerator()->create_user();
        $user2 = $this->getDataGenerator()->create_user();
        $user3 = $this->getDataGenerator()->create_user(['firstname' => 'Teacher', 'lastname' => 'One']);

        // Enrol two of them in the course as students.
        $roleids = $DB->get_records_menu('role', null, '', 'shortname, id');
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);
        $this->getDataGenerator()->enrol_user($user2->id, $course->id);

        // Enrol one of the users as a teacher.
        $this->getDataGenerator()->enrol_user($user3->id, $course->id, $roleids['editingteacher']);

        // Create a custom certificate. Note emailstudents is not set, so certificates must not be
        // manufactured on the students' behalf -- only students who trigger issuance themselves
        // (e.g. by viewing the certificate) should be notified about.
        $customcert = $this->getDataGenerator()->create_module('customcert', ['course' => $course->id,
            'emailteachers' => 1]);

        // Create template object.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);

        // Add a page to this template.
        $pageid = $template->add_page();

        // Add an element to the page.
        $element = new stdClass();
        $element->pageid = $pageid;
        $element->name = 'Image';
        $DB->insert_record('customcert_elements', $element);

        // Both students issue their own certificate (e.g. by viewing it) before the task runs.
        \mod_customcert\certificate::issue_certificate($customcert->id, $user1->id);
        \mod_customcert\certificate::issue_certificate($customcert->id, $user2->id);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Confirm that we only sent out 2 emails, both emails to the teacher for the two students.
        $this->assertCount(2, $emails);

        $this->assertEquals($CFG->noreplyaddress, $emails[0]->from);
        $this->assertEquals($user3->email, $emails[0]->to);

        $this->assertEquals($CFG->noreplyaddress, $emails[1]->from);
        $this->assertEquals($user3->email, $emails[1]->to);
    }

    /**
     * Tests that the email certificate task does not manufacture certificates for students who
     * have never triggered issuance themselves, merely because emailteachers is enabled.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_teachers_does_not_bulk_issue_to_students(): void {
        global $DB;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create and enrol two students; neither will view/issue their own certificate.
        $user1 = $this->getDataGenerator()->create_user();
        $user2 = $this->getDataGenerator()->create_user();
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);
        $this->getDataGenerator()->enrol_user($user2->id, $course->id);

        // Create a certificate that only notifies teachers, not students, with no restrictions.
        $customcert = $this->getDataGenerator()->create_module('customcert', [
            'course' => $course->id,
            'emailteachers' => 1,
        ]);

        // Put the certificate in a valid state by adding a page + element.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);
        $pageid = $template->add_page();
        $DB->insert_record('customcert_elements', (object)['pageid' => $pageid, 'name' => 'E']);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Neither student has viewed the certificate, so no certificates should have been issued.
        $this->assertCount(0, $DB->get_records('customcert_issues'));
        $this->assertCount(0, $emails);
    }

    /**
     * Tests that the email certificate task only notifies teachers about certificates that were
     * actually issued (e.g. by a student viewing them), and not about students who were merely
     * eligible but never triggered issuance themselves.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_teachers_only_notified_for_self_issued_certificates(): void {
        global $DB;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create and enrol two students, plus a teacher.
        $user1 = $this->getDataGenerator()->create_user();
        $user2 = $this->getDataGenerator()->create_user();
        $teacher = $this->getDataGenerator()->create_user(['firstname' => 'Teacher', 'lastname' => 'One']);
        $roleids = $DB->get_records_menu('role', null, '', 'shortname, id');
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);
        $this->getDataGenerator()->enrol_user($user2->id, $course->id);
        $this->getDataGenerator()->enrol_user($teacher->id, $course->id, $roleids['editingteacher']);

        // Create a certificate that only notifies teachers, not students, with no restrictions.
        $customcert = $this->getDataGenerator()->create_module('customcert', [
            'course' => $course->id,
            'emailteachers' => 1,
        ]);

        // Put the certificate in a valid state by adding a page + element.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);
        $pageid = $template->add_page();
        $DB->insert_record('customcert_elements', (object)['pageid' => $pageid, 'name' => 'E']);

        // Only user1 issues their own certificate (e.g. by viewing it); user2 never does.
        \mod_customcert\certificate::issue_certificate($customcert->id, $user1->id);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Only user1's certificate should exist; the task must not have manufactured one for user2.
        $issues = $DB->get_records('customcert_issues');
        $this->assertCount(1, $issues);
        $issue = reset($issues);
        $this->assertEquals($user1->id, (int)$issue->userid);

        // Only one email, to the teacher, about user1's certificate.
        $this->assertCount(1, $emails);
        $this->assertEquals($teacher->email, $emails[0]->to);
    }

    /**
     * Tests the email certificate task for others.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_others(): void {
        global $CFG, $DB;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create some users.
        $user1 = $this->getDataGenerator()->create_user();
        $user2 = $this->getDataGenerator()->create_user();

        // Enrol two of them in the course as students.
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);
        $this->getDataGenerator()->enrol_user($user2->id, $course->id);

        // Create a custom certificate. Note emailstudents is not set, so certificates must not be
        // manufactured on the students' behalf -- only students who trigger issuance themselves
        // (e.g. by viewing the certificate) should be notified about.
        $customcert = $this->getDataGenerator()->create_module('customcert', ['course' => $course->id,
            'emailothers' => 'testcustomcert@example.com, doo@dah']);

        // Create template object.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);

        // Add a page to this template.
        $pageid = $template->add_page();

        // Add an element to the page.
        $element = new stdClass();
        $element->pageid = $pageid;
        $element->name = 'Image';
        $DB->insert_record('customcert_elements', $element);

        // Both students issue their own certificate (e.g. by viewing it) before the task runs.
        \mod_customcert\certificate::issue_certificate($customcert->id, $user1->id);
        \mod_customcert\certificate::issue_certificate($customcert->id, $user2->id);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Confirm that we only sent out 2 emails, both emails to the other address that was valid for the two students.
        $this->assertCount(2, $emails);

        $this->assertEquals($CFG->noreplyaddress, $emails[0]->from);
        $this->assertEquals('testcustomcert@example.com', $emails[0]->to);

        $this->assertEquals($CFG->noreplyaddress, $emails[1]->from);
        $this->assertEquals('testcustomcert@example.com', $emails[1]->to);
    }

    /**
     * Tests that the email certificate task does not manufacture certificates for students who
     * have never triggered issuance themselves, merely because emailothers is enabled.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_others_does_not_bulk_issue_to_students(): void {
        global $DB;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create and enrol two students; neither will view/issue their own certificate.
        $user1 = $this->getDataGenerator()->create_user();
        $user2 = $this->getDataGenerator()->create_user();
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);
        $this->getDataGenerator()->enrol_user($user2->id, $course->id);

        // Create a certificate that only notifies an external address, not students, with no restrictions.
        $customcert = $this->getDataGenerator()->create_module('customcert', [
            'course' => $course->id,
            'emailothers' => 'testcustomcert@example.com',
        ]);

        // Put the certificate in a valid state by adding a page + element.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);
        $pageid = $template->add_page();
        $DB->insert_record('customcert_elements', (object)['pageid' => $pageid, 'name' => 'E']);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Neither student has viewed the certificate, so no certificates should have been issued.
        $this->assertCount(0, $DB->get_records('customcert_issues'));
        $this->assertCount(0, $emails);
    }

    /**
     * Tests the email certificate task when the certificate is not visible.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_students_not_visible(): void {
        global $DB;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create a user.
        $user1 = $this->getDataGenerator()->create_user();

        // Enrol them in the course.
        $roleids = $DB->get_records_menu('role', null, '', 'shortname, id');
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);

        // Create a custom certificate.
        $customcert = $this->getDataGenerator()->create_module('customcert', ['course' => $course->id, 'emailstudents' => 1]);

        // Create template object.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);

        // Add a page to this template.
        $pageid = $template->add_page();

        // Add an element to the page.
        $element = new stdClass();
        $element->pageid = $pageid;
        $element->name = 'Image';
        $DB->insert_record('customcert_elements', $element);

        // Remove the permission for the user to view the certificate.
        assign_capability('mod/customcert:view', CAP_PROHIBIT, $roleids['student'], \context_course::instance($course->id));

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Confirm there are no issues as the user did not have permissions to view it.
        $issues = $DB->get_records('customcert_issues');
        $this->assertCount(0, $issues);

        // Confirm no emails were sent.
        $this->assertCount(0, $emails);
    }

    /**
     * Tests the email certificate task when the student has not met the required time for the course.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_students_havent_met_required_time(): void {
        global $DB;

        // Intentionally avoid enabling the logstore here. get_course_time()
        // returns 0 when no stores are enabled, so the user still fails the
        // required time check without causing teardown DB-write warnings.

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create a user.
        $user1 = $this->getDataGenerator()->create_user();

        // Enrol them in the course.
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);

        // Create a custom certificate.
        $customcert = $this->getDataGenerator()->create_module('customcert', ['course' => $course->id, 'emailstudents' => 1,
            'requiredtime' => '60']);

        // Create template object.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);

        // Add a page to this template.
        $pageid = $template->add_page();

        // Add an element to the page.
        $element = new stdClass();
        $element->pageid = $pageid;
        $element->name = 'Image';
        $DB->insert_record('customcert_elements', $element);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Confirm there are no issues as the user did not meet the required time.
        $issues = $DB->get_records('customcert_issues');
        $this->assertCount(0, $issues);

        // Confirm no emails were sent.
        $this->assertCount(0, $emails);
    }

    /**
     * Tests the email certificate task when the student has not met the completion criteria.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_students_havent_met_required_criteria(): void {
        global $CFG, $DB;

        $CFG->enablecompletion = true;

        // Create a course.
        $course = $this->getDataGenerator()->create_course(['enablecompletion' => 1]);

        // Create a user.
        $user1 = $this->getDataGenerator()->create_user();

        // Enrol them in the course.
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);

        // Create a quiz.
        $quiz = $this->getDataGenerator()->create_module('quiz', ['course' => $course->id]);

        $quizmodule = $DB->get_record('course_modules', ['id' => $quiz->cmid]);

        // Set completion criteria for the quiz.
        $quizmodule->completion = COMPLETION_TRACKING_AUTOMATIC;
        $quizmodule->completionview = 1; // Require view to complete.
        $quizmodule->completionexpected = 0;
        $DB->update_record('course_modules', $quizmodule);

        // Set restrict access to the customcert activity based on the completion of the quiz.
        $customcert = $this->getDataGenerator()->create_module('customcert', [
            'course' => $course->id,
            'emailstudents' => 1,
            'availability' => json_encode(
                [
                    'op' => '&',
                    'c' => [
                        [
                            'type' => 'completion',
                            'cm' => $quiz->cmid,
                            'e' => COMPLETION_COMPLETE, // Ensure the quiz is marked as complete.
                        ],
                    ],
                    'showc' => [
                        false,
                    ],
                ],
            ),
        ]);

        // Create template object.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);

        // Add a page to this template.
        $pageid = $template->add_page();

        // Add an element to the page.
        $element = new stdClass();
        $element->pageid = $pageid;
        $element->name = 'Image';
        $DB->insert_record('customcert_elements', $element);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Confirm there are no issues as the user can not view the certificate.
        $issues = $DB->get_records('customcert_issues');
        $this->assertCount(0, $issues);

        // Confirm no emails were sent.
        $this->assertCount(0, $emails);
    }

    /**
     * Tests the email certificate task when the student has met the completion criteria.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_students_have_met_required_criteria(): void {
        global $CFG, $DB;

        $CFG->enablecompletion = true;

        // Create a course.
        $course = $this->getDataGenerator()->create_course(['enablecompletion' => 1]);

        // Create a user.
        $user1 = $this->getDataGenerator()->create_user();

        // Enrol them in the course.
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);

        // Create a quiz.
        $quiz = $this->getDataGenerator()->create_module('quiz', ['course' => $course->id]);

        $quizmodule = $DB->get_record('course_modules', ['id' => $quiz->cmid]);

        // Set completion criteria for the quiz.
        $quizmodule->completion = COMPLETION_TRACKING_AUTOMATIC;
        $quizmodule->completionview = 1; // Require view to complete.
        $quizmodule->completionexpected = 0;
        $DB->update_record('course_modules', $quizmodule);

        // Mark the quiz as complete for the user.
        $completion = new completion_info($course);
        $completion->update_state($quizmodule, COMPLETION_COMPLETE, $user1->id);

        // Set restrict access to the customcert activity based on the completion of the quiz.
        $customcert = $this->getDataGenerator()->create_module('customcert', [
            'course' => $course->id,
            'emailstudents' => 1,
            'availability' => json_encode(
                [
                    'op' => '&',
                    'c' => [
                        [
                            'type' => 'completion',
                            'cm' => $quiz->cmid,
                            'e' => COMPLETION_COMPLETE, // Ensure the quiz is marked as complete.
                        ],
                    ],
                    'showc' => [
                        false,
                    ],
                ],
            ),
        ]);

        // Create template object.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);

        // Add a page to this template.
        $pageid = $template->add_page();

        // Add an element to the page.
        $element = new stdClass();
        $element->pageid = $pageid;
        $element->name = 'Image';
        $DB->insert_record('customcert_elements', $element);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Confirm there is an issue as the user can view the certificate.
        $issues = $DB->get_records('customcert_issues');
        $this->assertCount(1, $issues);

        // Confirm an email was sent.
        $this->assertCount(1, $emails);
    }

    /**
     * Tests the email certificate task when completion conditions configured on the certificate
     * itself (as distinct from Restrict access) have not been met.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_students_havent_met_own_completion_condition(): void {
        global $CFG, $DB;

        $CFG->enablecompletion = true;

        // Create a course.
        $course = $this->getDataGenerator()->create_course(['enablecompletion' => 1]);

        // Create a user.
        $user1 = $this->getDataGenerator()->create_user();

        // Enrol them in the course.
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);

        // Create a certificate that requires viewing the activity to complete it, with no
        // Restrict access rule configured (completion tracking is the only gating in place).
        $customcert = $this->getDataGenerator()->create_module('customcert', [
            'course' => $course->id,
            'emailstudents' => 1,
            'completion' => COMPLETION_TRACKING_AUTOMATIC,
            'completionview' => 1,
        ]);

        // Create template object.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);

        // Add a page to this template.
        $pageid = $template->add_page();

        // Add an element to the page.
        $element = new stdClass();
        $element->pageid = $pageid;
        $element->name = 'Image';
        $DB->insert_record('customcert_elements', $element);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Confirm there are no issues as the user has not viewed the certificate yet.
        $issues = $DB->get_records('customcert_issues');
        $this->assertCount(0, $issues);

        // Confirm no emails were sent.
        $this->assertCount(0, $emails);
    }

    /**
     * Tests the email certificate task when completion conditions configured on the certificate
     * itself have been met.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_certificates_students_have_met_own_completion_condition(): void {
        global $CFG, $DB;

        $CFG->enablecompletion = true;

        // Create a course.
        $course = $this->getDataGenerator()->create_course(['enablecompletion' => 1]);

        // Create a user.
        $user1 = $this->getDataGenerator()->create_user();

        // Enrol them in the course.
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);

        // Create a certificate that requires viewing the activity to complete it, with no
        // Restrict access rule configured (completion tracking is the only gating in place).
        $customcert = $this->getDataGenerator()->create_module('customcert', [
            'course' => $course->id,
            'emailstudents' => 1,
            'completion' => COMPLETION_TRACKING_AUTOMATIC,
            'completionview' => 1,
        ]);

        // Create template object.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);

        // Add a page to this template.
        $pageid = $template->add_page();

        // Add an element to the page.
        $element = new stdClass();
        $element->pageid = $pageid;
        $element->name = 'Image';
        $DB->insert_record('customcert_elements', $element);

        // Mark the certificate's own completion condition as met for the user by simulating a
        // view, since automatic completion recalculates state from the actual criteria (a bare
        // update_state() call would be recalculated away).
        $cm = $DB->get_record('course_modules', ['id' => $customcert->cmid]);
        $completion = new completion_info($course);
        $completion->set_module_viewed($cm, $user1->id);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Confirm there is an issue as the user has viewed the certificate.
        $issues = $DB->get_records('customcert_issues');
        $this->assertCount(1, $issues);

        // Confirm an email was sent.
        $this->assertCount(1, $emails);
    }

    /**
     * Tests the email certificate task running adhoc.
     *
     * @covers \mod_customcert\task\email_certificate_task
     * @covers \mod_customcert\task\issue_certificates_task
     */
    public function test_email_certificates_adhoc(): void {
        global $CFG, $DB;

        set_config('useadhoc', 1, 'customcert');

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create some users.
        $user1 = $this->getDataGenerator()->create_user();
        $user2 = $this->getDataGenerator()->create_user();
        $user3 = $this->getDataGenerator()->create_user(['firstname' => 'Teacher', 'lastname' => 'One']);

        // Enrol two of them in the course as students.
        $roleids = $DB->get_records_menu('role', null, '', 'shortname, id');
        $this->getDataGenerator()->enrol_user($user1->id, $course->id);
        $this->getDataGenerator()->enrol_user($user2->id, $course->id);

        // Enrol one of the users as a teacher.
        $this->getDataGenerator()->enrol_user($user3->id, $course->id, $roleids['editingteacher']);

        // Create a custom certificate.
        $customcert = $this->getDataGenerator()->create_module('customcert', ['course' => $course->id,
            'emailstudents' => 1]);

        // Create template object.
        $template = new stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'A template';
        $template->contextid = context_course::instance($course->id)->id;
        $template = new template($template);

        // Add a page to this template.
        $pageid = $template->add_page();

        // Add an element to the page.
        $element = new stdClass();
        $element->pageid = $pageid;
        $element->name = 'Image';
        $DB->insert_record('customcert_elements', $element);

        // Ok, now issue this to one user.
        \mod_customcert\certificate::issue_certificate($customcert->id, $user1->id);

        // Confirm there is only one entry in this table.
        $this->assertEquals(1, $DB->count_records('customcert_issues'));

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Get the issues from the issues table now.
        $issues = $DB->get_records('customcert_issues');
        $this->assertCount(2, $issues);

        // Confirm that it wasn't marked as emailed and was not issued to the teacher.
        foreach ($issues as $issue) {
            $this->assertEquals(0, $issue->emailed);
            $this->assertNotEquals($user3->id, $issue->userid);
        }

        // Now we send emails to the two users using the adhoc method.
        $sink = $this->redirectEmails();
        $this->assertCount(0, $emails);
        $issues = array_values($issues);
        $task = new email_certificate_task();
        $task->set_custom_data((object)['issueid' => $issues[0]->id, 'customcertid' => $customcert->id]);
        $task->execute();
        $task->set_custom_data((object)['issueid' => $issues[1]->id, 'customcertid' => $customcert->id]);
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Get the issues from the issues table now.
        $issues = $DB->get_records('customcert_issues');
        // Confirm that it wasn't marked as emailed and was not issued to the teacher.
        foreach ($issues as $issue) {
            $this->assertEquals(1, $issue->emailed);
            $this->assertNotEquals($user3->id, $issue->userid);
        }

        // Confirm that we sent out emails to the two users.
        $this->assertCount(2, $emails);

        $this->assertEquals($CFG->noreplyaddress, $emails[0]->from);
        $this->assertEquals($user1->email, $emails[0]->to);

        $this->assertEquals($CFG->noreplyaddress, $emails[1]->from);
        $this->assertEquals($user2->email, $emails[1]->to);

        // Now, run the task again and ensure we did not issue any more certificates.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        $issues = $DB->get_records('customcert_issues');

        $this->assertCount(2, $issues);
        $this->assertCount(0, $emails);
    }

    /**
     * Tests that we still issue a certificate if there are none when 'certificateexecutionperiod' is set.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     */
    public function test_issue_certificates_task_creates_issue_when_none_exist(): void {
        global $CFG, $DB;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create a student user.
        $student = $this->getDataGenerator()->create_user();

        // Enrol the student in the course.
        $this->getDataGenerator()->enrol_user($student->id, $course->id);

        // Create a custom certificate module with emailing enabled for students.
        $customcert = $this->getDataGenerator()->create_module('customcert', ['course' => $course->id,
            'emailstudents' => 1]);

        // Set up a basic certificate template.
        $template = new \stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'Test Template';
        $template->contextid = \context_course::instance($course->id)->id;
        $template = new template($template);

        // Add a page and an element to put the certificate in a valid state.
        $pageid = $template->add_page();
        $element = new \stdClass();
        $element->pageid = $pageid;
        $element->name = 'Test Element';
        $DB->insert_record('customcert_elements', $element);

        // Verify that no certificate issues exist before task execution.
        $this->assertEmpty(
            $DB->get_records('customcert_issues'),
            'No certificate issues should exist before executing the task.'
        );

        // Redirect emails to a sink so we can capture any outgoing messages.
        $sink = $this->redirectEmails();

        set_config('certificateexecutionperiod', 1, 'customcert');

        // Execute the issue certificates task.
        $task = new \mod_customcert\task\issue_certificates_task();
        $task->execute();

        // After executing the task, verify that a certificate issue record was created.
        $issues = $DB->get_records('customcert_issues');
        $this->assertCount(
            1,
            $issues,
            'A certificate issue record should have been created by the task.'
        );
        $issue = reset($issues);
        $this->assertEquals(
            1,
            $issue->emailed,
            'The certificate issue should be marked as emailed.'
        );

        $emails = $sink->get_messages();
        $sink->close();

        // Verify that an email was sent to the student.
        $this->assertCount(1, $emails, 'An email should have been sent to the student.');
        $this->assertEquals($CFG->noreplyaddress, $emails[0]->from, 'Email sender is incorrect.');
        $this->assertEquals($student->email, $emails[0]->to, 'Email recipient is incorrect.');
    }

    /**
     * The email_certificate_task should no-op (not fatal) when custom data is missing.
     *
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_adhoc_task_ignores_missing_customdata(): void {
        // No setup; call the adhoc task with no custom data.
        $sink = $this->redirectEmails();

        $task = new email_certificate_task();
        // Intentionally DO NOT call set_custom_data().
        $task->execute();

        // Should not throw; should not send any email.
        $emails = $sink->get_messages();
        $this->assertCount(0, $emails);
        $sink->close();
    }

    /**
     * The email_certificate_task should no-op when customcert id is invalid.
     *
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_adhoc_task_invalid_customcertid(): void {
        $sink = $this->redirectEmails();

        $task = new email_certificate_task();

        // Point to bogus ids; both should be integers but not exist.
        $task->set_custom_data((object)['issueid' => 999999, 'customcertid' => 999998]);
        $task->execute();

        $emails = $sink->get_messages();
        $this->assertCount(0, $emails);
        $sink->close();
    }

    /**
     * The email_certificate_task should no-op when issue id is invalid (even if customcert exists).
     *
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_email_adhoc_task_invalid_issueid_with_valid_customcert(): void {
        global $DB;

        // Minimal valid customcert (with one element) so the customcert lookup succeeds.
        $course = $this->getDataGenerator()->create_course();
        $customcert = $this->getDataGenerator()->create_module('customcert', ['course' => $course->id]);

        // Make the template valid.
        $template = new \stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'T';
        $template->contextid = \context_course::instance($course->id)->id;
        $template = new \mod_customcert\template($template);
        $pageid = $template->add_page();
        $DB->insert_record('customcert_elements', (object)['pageid' => $pageid, 'name' => 'E']);

        $sink = $this->redirectEmails();

        $task = new email_certificate_task();

        // Valid customcertid, but bogus issueid.
        $task->set_custom_data((object)['issueid' => 123456789, 'customcertid' => $customcert->id]);
        $task->execute();

        $emails = $sink->get_messages();
        $this->assertCount(0, $emails);
        $sink->close();
    }

    /**
     * Tests that a user with ONLY a teacher/manager role does NOT receive a certificate.
     *
     * This confirms that the patch allowing teachers enrolled as students to receive
     * certificates does not incorrectly allow teachers/managers who are *not* students.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_manager_only_does_not_receive_certificate(): void {
        global $DB;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create users: one student and one manager-only.
        $student = $this->getDataGenerator()->create_user();
        $manager = $this->getDataGenerator()->create_user(['firstname' => 'Manager', 'lastname' => 'Only']);

        // Enrol student normally.
        $this->getDataGenerator()->enrol_user($student->id, $course->id);

        // Enrol manager as editingteacher (manage capability), but NOT as student.
        $roleids = $DB->get_records_menu('role', null, '', 'shortname, id');
        $this->getDataGenerator()->enrol_user($manager->id, $course->id, $roleids['editingteacher']);

        // Create custom certificate.
        $customcert = $this->getDataGenerator()->create_module('customcert', [
            'course' => $course->id,
            'emailstudents' => 1, // Only students should receive.
            'emailteachers' => 1, // Teachers get notified *about* students, but should not receive their own cert.
        ]);

        // Create valid template.
        $template = new \stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'Manager Test Template';
        $template->contextid = \context_course::instance($course->id)->id;
        $template = new template($template);

        $pageid = $template->add_page();
        $DB->insert_record('customcert_elements', (object)[
            'pageid' => $pageid,
            'name' => 'ElementX',
        ]);

        // Run the task.
        $sink = $this->redirectEmails();
        $task = new issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Fetch issues.
        $issues = $DB->get_records('customcert_issues');

        // Exactly 1 issue should exist: for the student only.
        $this->assertCount(1, $issues);
        $issueuserids = array_column($issues, 'userid');
        $this->assertContains($student->id, $issueuserids);
        $this->assertNotContains($manager->id, $issueuserids);

        // Email count:
        // - One email to the student (their certificate)
        // - If emailteachers = 1, teacher receives notifications *about students*,
        // but NOT their own certificate. So total emails = 2.
        $this->assertCount(2, $emails);

        // Email recipients.
        $tos = array_map(fn ($e) => $e->to, $emails);
        $this->assertContains($student->email, $tos);
        $this->assertContains($manager->email, $tos); // Manager receives notifications, not a certificate.

        // Confirm manager did NOT get issued their own certificate.
        foreach ($issues as $issue) {
            $this->assertNotEquals($manager->id, $issue->userid);
        }
    }

    /**
     * Tests that certificate issuing and emailing are controlled solely
     * by the mod/customcert:receiveissue capability.
     *
     * Users who have receiveissue + view should receive a certificate and email.
     * Users who lack receiveissue should NOT receive a certificate or email,
     * even if they have the manage capability.
     *
     * @covers \mod_customcert\task\issue_certificates_task
     * @covers \mod_customcert\task\email_certificate_task
     */
    public function test_receiveissue_capability_based_issuing(): void {
        global $DB, $CFG;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Users -
        // student: normal student, has mod/customcert:receiveissue.
        // teacherstudent: teacher but also student, so still has mod/customcert:receiveissue.
        // manager: has manage but no student role, so NO mod/customcert:receiveissue.
        $student = $this->getDataGenerator()->create_user();
        $teacherstudent = $this->getDataGenerator()->create_user(['firstname' => 'Teacher', 'lastname' => 'Student']);
        $manager = $this->getDataGenerator()->create_user(['firstname' => 'Manager', 'lastname' => 'Only']);

        $roleids = $DB->get_records_menu('role', null, '', 'shortname, id');

        // Enrolments.
        $this->getDataGenerator()->enrol_user($student->id, $course->id);

        // The teacherstudent gets BOTH roles → receives mod/customcert:receiveissue via student role.
        $this->getDataGenerator()->enrol_user($teacherstudent->id, $course->id);
        $this->getDataGenerator()->enrol_user($teacherstudent->id, $course->id, $roleids['editingteacher']);

        // The manager gets ONLY editingteacher → has manage but NO mod/customcert:receiveissue.
        $this->getDataGenerator()->enrol_user($manager->id, $course->id, $roleids['editingteacher']);

        // Create custom certificate.
        $customcert = $this->getDataGenerator()->create_module('customcert', [
            'course' => $course->id,
            'emailstudents' => 1,
        ]);

        // Create valid template (one element).
        $template = new \stdClass();
        $template->id = $customcert->templateid;
        $template->name = 'ReceiveIssue Test Template';
        $template->contextid = \context_course::instance($course->id)->id;
        $template = new template($template);

        $pageid = $template->add_page();
        $DB->insert_record('customcert_elements', (object)[
            'pageid' => $pageid,
            'name' => 'ElementX',
        ]);

        // Run issuing task.
        $sink = $this->redirectEmails();
        $task = new \mod_customcert\task\issue_certificates_task();
        $task->execute();
        $emails = $sink->get_messages();
        $sink->close();

        // Issues table assertions.
        $issues = $DB->get_records('customcert_issues');
        $this->assertCount(2, $issues);

        $uids = array_column($issues, 'userid');

        // Expected.
        $this->assertContains($student->id, $uids);
        $this->assertContains($teacherstudent->id, $uids);
        $this->assertNotContains($manager->id, $uids);

        // Email assertions.
        // Two eligible (student + teacherstudent) so we get two emails.
        $this->assertCount(2, $emails);

        $expected = [$student->email, $teacherstudent->email];

        foreach ($emails as $email) {
            $this->assertEquals($CFG->noreplyaddress, $email->from);
            $this->assertContains($email->to, $expected);
            $expected = array_diff($expected, [$email->to]);
        }
    }
}

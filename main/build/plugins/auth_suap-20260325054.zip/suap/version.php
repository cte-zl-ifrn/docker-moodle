<?php

/**
 * Plugin version and other meta-data are defined here.
 *
 * @package     auth_suap
 * @copyright   2020 Kelson Medeiros <kelsoncm@gmail.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'auth_suap';
$plugin->release = '4.5.054';
$plugin->version = 20260325054;
$plugin->maturity = MATURITY_STABLE;
$plugin->requires = 2023041000;
